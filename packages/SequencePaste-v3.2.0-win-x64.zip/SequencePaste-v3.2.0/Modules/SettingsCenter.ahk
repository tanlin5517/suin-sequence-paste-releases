﻿#Requires AutoHotkey v2.0
class SPPreferences {
    static Defaults := Map("CaptureCopy",1,"CaptureCut",1,"CaptureImages",1,"FormattedText",0,"QueuePaste",1,"ResetEsc",1,"ResetUndo",1,"AutoNumber",1,"TypeDelay",15,"TypingMethod",0,"BatchContinue",0,"AutoAdvance",1)
    static Load(owner) {
        for prefName, fallback in this.Defaults {
            prefValue := IniRead(owner.ConfigPath,"Preferences",prefName,fallback)
            if !RegExMatch(prefValue,"^\d+$") || (prefName="TypeDelay" ? Integer(prefValue)>100 : Integer(prefValue)>1)
                prefValue := fallback
            owner.%prefName% := Integer(prefValue)
        }
    }
    static Validate(values) {
        limits := Map("NumericTypingMaxDigits",[0,1000],"TypeDelay",[0,100],"IdleSeconds",[0,86400],"CollapsedDiameter",[100,300],"ExpandedDiameter",[320,640],"Diameter",[100,640],"Opacity",[35,100])
        for prefName, prefValue in values {
            if prefName="AutoStart"
                continue
            bound := limits.Has(prefName)?limits[prefName]:[0,1]
            if !RegExMatch(prefValue,"^\d+$") || Integer(prefValue)<bound[1] || Integer(prefValue)>bound[2]
                throw Error(this.Label(prefName) "必须在 " bound[1] "～" bound[2] " 之间")
        }
        return true
    }
    static Label(name) {
        labels := Map("NumericTypingMaxDigits","数字位数上限","TypeDelay","逐字间隔","IdleSeconds","闲置秒数","CollapsedDiameter","收起直径","ExpandedDiameter","展开直径","Diameter","固定直径","Opacity","不透明度")
        return labels.Has(name)?labels[name]:name
    }
    static Save(owner, values) {
        this.Validate(values)
        SplitPath(owner.ConfigPath,,&folder)
        DirCreate(folder)
        prefStamp := A_Now "-" Trim(SP.Guid(),"{}")
        temp := owner.ConfigPath ".settings-" prefStamp ".tmp"
        try {
            if FileExist(owner.ConfigPath) {
                DirCreate(folder "\ConfigBackups")
                FileCopy(owner.ConfigPath,folder "\ConfigBackups\Settings-" prefStamp ".ini",1)
                FileCopy(owner.ConfigPath,temp,1)
            } else
                FileAppend("",temp,"UTF-16")
            for prefName, prefValue in values {
                if prefName="AutoStart"
                    continue
                section := "Preferences", key := prefName
                if prefName="NumericTypingMaxDigits"
                    section := "Sequence"
                else if prefName="IdleSeconds"
                    section := "Sequence", key := "TimeoutSeconds"
                else if InStr("|AutoExpand|CollapsedDiameter|ExpandedDiameter|Diameter|Opacity|Visible|","|" prefName "|")
                    section := "Panel"
                IniWrite(Integer(prefValue),temp,section,key)
            }
            FileMove(temp,owner.ConfigPath,1)
        } finally {
            if FileExist(temp)
                FileDelete(temp)
        }
        for prefName, prefValue in values {
            if this.Defaults.Has(prefName) || prefName="NumericTypingMaxDigits"
                owner.%prefName% := Integer(prefValue)
            if prefName="IdleSeconds"
                owner.TimeoutMs := Integer(prefValue)*1000
        }
        if !owner.Shared && values.Has("IdleSeconds") {
            SetTimer(SP.ExpireCallback,0)
            if owner.Queue.Length
                owner.Touch()
        }
        if IsObject(owner.Panel) && values.Has("AutoExpand") {
            panel := owner.Panel
            panel.AutoExpand := !!values["AutoExpand"]
            panel.CollapsedDiameter := Integer(values["CollapsedDiameter"]), panel.ExpandedDiameter := Integer(values["ExpandedDiameter"])
            panel.ApplyAppearance(Integer(values["Diameter"]),Integer(values["Opacity"]))
            if values["Visible"]
                panel.Show()
            else
                panel.Hide()
        }
        return true
    }
    static AutoStart(owner) => SPStartup.Inspect(owner)
    static SetAutoStart(owner, enabled) {
        if (!!enabled)=(!!this.AutoStart(owner))
            return
        SPStartup.Save(owner,enabled)
    }
}

class SPStartup {
    static Root(owner) {
        SplitPath(owner.ConfigPath,,&folder)
        return IniRead(owner.ConfigPath,"Client","InstallRoot",folder)
    }
    static Unified(owner) => FileExist(this.Root(owner) "\顺序粘贴.exe")
    static InspectUnified(owner, directory := "") {
        try {
            FileGetShortcut(this.Link(directory),&target,&work,&args)
            return FileExist(target) && StrLower(target)=StrLower(this.Root(owner) "\顺序粘贴.exe") && args="--background"
                && StrLower(RTrim(work,"\"))=StrLower(RTrim(this.Root(owner),"\"))
        }
        return false
    }
    static Link(directory := "") => (directory!=""?directory:A_Startup) "\SuinSequencePaste.lnk"
    static Inspect(owner, directory := "") {
        if this.Unified(owner)
            return this.InspectUnified(owner,directory)
        link := this.Link(directory)
        if !FileExist(link)
            return false
        try {
            FileGetShortcut(link,&target,&work,&args)
            root := this.Root(owner)
            return FileExist(target) && FileExist(root "\Main.ahk")
                && StrLower(RTrim(work,"\"))=StrLower(RTrim(root,"\"))
                && args='/ErrorStdOut=UTF-8 "' root '\Main.ahk"'
        }
        return false
    }
    static Save(owner, enabled, directory := "", runtime := "") {
        link := this.Link(directory)
        root := this.Root(owner)
        logPath := root "\Logs\background-startup.txt"
        tempLink := ""
        try {
            if !enabled {
                if FileExist(link) {
                    if !this.BelongsTo(owner,link)
                        throw Error("启动项属于另一个项目目录，未移除；请从对应项目关闭登录启动。")
                    this.Backup(root,link)
                    FileDelete(link)
                }
                if FileExist(link)
                    throw Error("无法移除启动项，请检查启动文件夹权限。")
            } else {
                runtime := this.Unified(owner) ? root "\顺序粘贴.exe" : (runtime!=""?runtime:A_AhkPath)
                if !FileExist(runtime)
                    throw Error("当前 AutoHotkey 运行程序不存在，请完整解压后重新启动本工具。")
                if !FileExist(root "\Main.ahk")
                    throw Error("项目目录缺少 Main.ahk，请确认已完整解压更新包。")
                SplitPath(link,,&startupFolder)
                DirCreate(startupFolder)
                tempLink := startupFolder "\SuinSequencePaste-" A_TickCount ".lnk"
                shell := ComObject("WScript.Shell"), shortcut := shell.CreateShortcut(tempLink)
                shortcut.TargetPath := runtime
                shortcut.Arguments := this.Unified(owner) ? "--background" : '/ErrorStdOut=UTF-8 "' root '\Main.ahk"'
                shortcut.WorkingDirectory := root, shortcut.WindowStyle := 7
                shortcut.Description := "顺序剪贴板 · 登录后在后台就绪"
                shortcut.Save()
                verify := shell.CreateShortcut(tempLink)
                if StrLower(verify.TargetPath)!=StrLower(runtime) || verify.Arguments!=shortcut.Arguments || StrLower(verify.WorkingDirectory)!=StrLower(root)
                    throw Error("启动项回读校验失败，原启动项未更改。")
                if FileExist(link)
                    this.Backup(root,link)
                FileMove(tempLink,link,1),tempLink := ""
                if !this.Inspect(owner,directory)
                    throw Error("启动项保存后校验失败，请查看启动诊断。")
            }
            this.WriteLog(logPath,(enabled?"ENABLED":"DISABLED") "`nRuntime=" (enabled?runtime:"") "`nProject=" root "`nShortcut=" link)
            return true
        } catch as err {
            this.WriteLog(logPath,"FAILED`n" err.Message "`nProject=" root "`nShortcut=" link)
            throw Error("本机设置已保存；登录启动失败：" err.Message)
        } finally {
            if tempLink!="" && FileExist(tempLink)
                try FileDelete(tempLink)
        }
    }
    static BelongsTo(owner, link) {
        try {
            FileGetShortcut(link,&target,,&args)
            root := this.Root(owner)
            return this.Unified(owner) ? (StrLower(target)=StrLower(root "\顺序粘贴.exe") && args="--background") : args='/ErrorStdOut=UTF-8 "' root '\Main.ahk"'
        }
        return false
    }
    static Backup(root,link) {
        folder := root "\Backups\Background-" A_Now "-" Trim(SP.Guid(),"{}")
        DirCreate(folder),FileCopy(link,folder "\SuinSequencePaste.lnk",1)
    }
    static WriteLog(path,message) {
        try {
            SplitPath(path,,&folder)
            DirCreate(folder)
            if FileExist(path)
                FileDelete(path)
            FileAppend(A_Now "`n" message "`n",path,"UTF-8")
        }
    }
}

class SPSettingsWindow {
    static Version := "2.3.4"
    __New(owner) {
        this.Owner := owner,this.Page := 1,this.Scale := 1,this.Gui := 0
        this.Controls := Map(),this.Pages := [[],[],[],[],[]],this.Buttons := Map(),this.Nav := []
        this.HoverHwnd := 0,this.Sliding := 0,this.GdipToken := 0,this.GdipLibrary := 0
        this.DrawCallback := ObjBindMethod(this,"Draw"),this.StatusCallback := ObjBindMethod(this,"RefreshStatus")
        this.MouseCallback := ObjBindMethod(this,"Mouse"),this.KeyCallback := ObjBindMethod(this,"Key")
    }
    B(x,y,w,h) => " x" Round(x*this.Scale) " y" Round(y*this.Scale) " w" Round(w*this.Scale) " h" Round(h*this.Scale)
    Text(page,text,x,y,w,h,size:=11,color:="18253D",bold:=false,bg:="FFFFFF") {
        this.Gui.SetFont("s" size*this.Scale " c" color (bold?" Bold":" Norm"),"Microsoft YaHei UI")
        control := this.Gui.AddText(this.B(x,y,w,h) " Background" bg,text)
        if page
            this.Pages[page].Push(control)
        return control
    }
    Surface(page,x,y,w,h,style:="card",bg:="F5F7FB") {
        control := this.Gui.AddText(this.B(x,y,w,h) " +0xD")
        this.Buttons[control.Hwnd] := {Control:control,Style:style,Page:0,Bg:bg}
        if page
            this.Pages[page].Push(control)
        return control
    }
    Button(label,x,y,w,h,handler,style:="secondary",page:=0,bg:="F5F7FB") {
        this.Gui.SetFont("s" 10.5*this.Scale " Norm","Microsoft YaHei UI")
        control := this.Gui.AddButton(this.B(x,y,w,h) " +0xB",label)
        this.Buttons[control.Hwnd] := {Control:control,Style:style,Page:0,Bg:bg,Label:label}
        if IsObject(handler)
            control.OnEvent("Click",handler)
        if page
            this.Pages[page].Push(control)
        return control
    }
    Switch(page,key,label,x,y,w:=64) {
        control := this.Button(label,x,y,w,34,0,"switch",page,"FFFFFF")
        widget := SPToggle(this,control,label)
        this.Controls[key] := widget,this.Buttons[control.Hwnd].Widget := widget
        control.OnEvent("Click",ObjBindMethod(widget,"Toggle"))
        return widget
    }
    RowSwitch(page,key,title,detail,y,shortcut:="") {
        this.Text(page,title,264,y+4,440,25,11,"18253D",true)
        this.Text(page,detail,264,y+32,565,21,9,"69758B")
        if shortcut!=""
            this.Text(page,shortcut,774,y+4,70,23,9,"65738D")
        return this.Switch(page,key,title,890,y+12)
    }
    Section(page,label,x,y) => this.Text(page,label,x,y,380,24,9,"77849B",true,"F5F7FB")
    Choice(page,key,labels,x,y,w) {
        widget := SPChoice(this,labels,x,y,w,page)
        this.Controls[key] := widget
        return widget
    }
    Number(page,key,x,y,w,value,min,max) {
        this.Surface(page,x,y,w,45,"input","FFFFFF")
        this.Gui.SetFont("s" 12*this.Scale " c18253D Norm","Microsoft YaHei UI")
        control := this.Gui.AddEdit(this.B(x+45,y+9,w-90,27) " -E0x200 -Border Center Number BackgroundF3F5FA",value)
        this.Pages[page].Push(control),this.Controls[key] := control
        for item in [["−",-1,x+3],["+",1,x+w-43]]
            this.Button(item[1],item[3],y+3,40,39,ObjBindMethod(this,"Step",control,min,max,item[2]),"step",page,"F3F5FA")
        return control
    }
    Step(control,min,max,amount,*) {
        try control.Value := Max(min,Min(max,Integer(control.Value)+amount))
        catch
            control.Value := min
    }
    Build() {
        owner := this.Owner
        this.Dpi := IsObject(owner.Panel)?owner.Panel.Dpi:A_ScreenDPI
        MonitorGetWorkArea(MonitorGetPrimary(),&left,&top,&right,&bottom)
        this.Scale := Min(1,(right-left-32)*96/this.Dpi/1000,(bottom-top-64)*96/this.Dpi/760)
        this.Gui := Gui("+AlwaysOnTop -MaximizeBox -MinimizeBox","顺序剪贴板 · 设置中心 v" SPSettingsWindow.Version)
        if IsObject(owner.Panel)
            this.Gui.Opt("+Owner" owner.Panel.Gui.Hwnd)
        this.Gui.BackColor := "F5F7FB",this.Gui.MarginX := 0,this.Gui.MarginY := 0
        this.Gui.OnEvent("Close",(*)=>this.Close()),this.Gui.OnEvent("Escape",(*)=>this.Close())
        this.GdipLibrary := DllCall("LoadLibrary","str","gdiplus.dll","ptr")
        input := Buffer(24,0),NumPut("uint",1,input)
        DllCall("gdiplus\GdiplusStartup","ptr*",&token:=0,"ptr",input,"ptr",0),this.GdipToken := token
        OnMessage(0x2B,this.DrawCallback)
        for message in [0x200,0x201,0x202,0x2A3]
            OnMessage(message,this.MouseCallback)
        this.Surface(0,0,0,208,760,"sidebar")
        this.Surface(0,24,30,43,43,"brand","111D32")
        this.Text(0,"顺序剪贴板",80,31,119,27,12,"FFFFFF",true,"111D32")
        this.Text(0,"CLIPBOARD STUDIO",80,61,122,18,7,"9DACC5",false,"111D32")
        this.Text(0,"工作空间",26,117,160,23,8.5,"91A0BB",false,"111D32")
        names := ["采集与粘贴","数字输入","队列规则","浮窗外观","连接与状态"]
        for idx,name in names {
            nav := this.Button(name,16,157+(idx-1)*60,176,49,ObjBindMethod(this,"Navigate",idx),"nav",0,"111D32")
            this.Buttons[nav.Hwnd].Page := idx,this.Nav.Push(nav)
        }
        this.Surface(0,16,626,176,86,"sidebarNote","111D32")
        this.Text(0,"随时接着粘贴",31,644,145,24,10,"E5EEFF",true,"1A2942")
        this.Text(0,"断线也保留普通粘贴",31,675,149,20,8,"A7B7D2",false,"1A2942")
        this.Text(0,"v" SPSettingsWindow.Version "   /   图文混合队列",25,731,176,18,8,"9DACC5",false,"111D32")
        this.Text(0,"偏好设置  /  YOUR WORKFLOW",240,28,470,22,8.5,"78859A",false,"F5F7FB")
        this.Title := this.Text(0,"",238,67,565,43,24,"17243C",true,"F5F7FB")
        this.Subtitle := this.Text(0,"",240,119,715,24,10,"69758B",false,"F5F7FB")
        this.ScopeBadge := this.Surface(0,850,35,126,31,"badge")
        this.Scope := this.Text(0,"仅本机设置",858,42,110,20,8.5,"4A65A5",true,"E8EEFC")
        this.BuildCapture(),this.BuildNumbers(),this.BuildPolicy(),this.BuildAppearance(),this.BuildStatus()
        this.Feedback := this.Text(0,"更改后点击保存，让工作方式适合你。",240,650,736,39,9,"69758B",false,"F5F7FB")
        this.Surface(0,240,696,736,1,"line")
        this.DefaultButton := this.Button("恢复本页默认",240,712,150,37,(*)=>this.Defaults(),"ghost")
        this.CloseButton := this.Button("关闭",686,708,108,44,(*)=>this.Close(),"secondary")
        this.SaveButton := this.Button("保存本机设置",810,708,166,44,(*)=>this.Save(),"primary")
        this.SaveButton.Opt("Default")
        this.Load(),SetTimer(this.StatusCallback,700)
        corner := Buffer(4),NumPut("int",2,corner)
        try DllCall("dwmapi\DwmSetWindowAttribute","ptr",this.Gui.Hwnd,"uint",33,"ptr",corner,"uint",4)
    }
    BuildCapture() {
        this.Section(1,"采集内容",242,168)
        this.Surface(1,240,198,736,246)
        this.RowSwitch(1,"CaptureCopy","复制时加入队列","主动复制的文字和图片，按操作顺序收集。",204,"Ctrl+C")
        this.RowSwitch(1,"CaptureCut","剪切时加入队列","先完成剪切，再采集；失败不会重复剪切。",264,"Ctrl+X")
        this.RowSwitch(1,"CaptureImages","收集图片和截图","同步变化不自动入队；当前截图可用 Ctrl+Alt+C 加入。",324)
        this.RowSwitch(1,"FormattedText","表格与富文本按纯文本排队","开启后只保留文字；关闭则优先按原格式粘贴。",384)
        this.Section(1,"粘贴与快捷操作",242,464)
        this.Surface(1,240,494,736,142)
        this.Choice(1,"QueuePasteMode",["按队列顺序粘贴","始终普通粘贴"],260,510,696)
        this.Text(1,"Esc 清空队列",264,578,180,24,10)
        this.Switch(1,"ResetEsc","Esc 清空队列",488,572,58)
        this.Text(1,"Ctrl+Z 清空队列",608,578,200,24,10)
        this.Switch(1,"ResetUndo","Ctrl+Z 清空队列",890,572,58)
    }
    BuildNumbers() {
        this.Surface(2,240,174,736,116)
        this.Text(2,"让每一位数字保持原样",264,195,540,30,15,"18253D",true)
        this.Text(2,"短数字自动逐字输入，保留前导零、符号、小数与千分位。",264,244,600,23,10,"69758B")
        this.Switch(2,"AutoNumber","短数字自动逐字输入",890,199)
        this.Section(2,"输入节奏",242,314)
        for col in [[240,354,"数字位数上限","超出时直接粘贴；0 关闭自动输入。","NumericTypingMaxDigits",20,0,1000],[612,364,"逐字输入间隔","毫秒；较慢的软件可以适当调大。","TypeDelay",15,0,100]] {
            this.Surface(2,col[1],344,col[2],164)
            this.Text(2,col[3],col[1]+24,365,col[2]-48,28,12,"18253D",true)
            this.Text(2,col[4],col[1]+24,403,col[2]-44,25,9,"69758B")
            this.Number(2,col[5],col[1]+24,446,col[2]-48,col[6],col[7],col[8])
        }
        this.Surface(2,240,526,736,110)
        this.Text(2,"输入方式",264,545,180,25,11,"18253D",true)
        this.Choice(2,"TypingMethodMode",["标准逐字","数字兼容按键"],446,538,506)
        this.Text(2,"Ctrl+Shift+V 手动输入 · Ctrl+Alt+F12 自检",264,604,530,22,9,"69758B")
        this.Button("输入自检",808,590,144,36,(*)=>this.Owner.OpenInputTest(),"soft",2,"FFFFFF")
    }
    BuildPolicy() {
        this.Surface(3,240,174,736,88)
        this.EnabledText := this.Text(3,"",264,192,445,30,14,"18253D",true)
        this.Text(3,this.Owner.Shared?"已连接时，一端切换，两端一起生效。":"本机开启后，按当前队列和偏好工作。",264,232,445,21,9,"69758B")
        this.Button(this.Owner.Shared?"切换两端开关":"切换本机开关",778,196,174,42,(*)=>this.Toggle(),"soft",3,"FFFFFF")
        this.Surface(3,240,282,736,132)
        this.Text(3,"再次复制，怎样接续？",264,300,600,27,12,"18253D",true)
        this.Text(3,"消费后开始新批次，或保留当前进度继续收集。",264,337,630,22,9,"69758B")
        this.Choice(3,"BatchMode",["开始新批次","追加到当前批次"],260,368,696)
        this.Surface(3,240,432,736,132)
        this.Text(3,"粘贴后，怎样前进？",264,450,610,27,12,"18253D",true)
        this.Text(3,"自动以动作发出为准；手动模式点击浮窗“跳过”才推进。",264,487,670,22,9,"69758B")
        this.Choice(3,"AdvanceMode",["动作发出后自动推进","手动跳过推进"],260,518,696)
        this.Surface(3,240,582,736,54)
        this.Text(3,"闲置自动清空",264,598,230,25,10,"18253D",true)
        this.Text(3,"秒 · 0 表示不清空",490,599,223,21,9,"69758B")
        this.Number(3,"IdleSeconds",744,587,210,300,0,86400)
    }
    BuildAppearance() {
        this.Surface(4,240,174,736,106)
        this.Surface(4,265,191,76,76,"preview","FFFFFF")
        this.Text(4,"轻巧一点，留在手边",366,193,500,30,15,"18253D",true)
        this.Text(4,"收起时安静停靠，悬停时展开全部操作。",366,241,520,23,10,"69758B")
        this.Surface(4,240,300,736,122)
        this.RowSwitch(4,"AutoExpand","悬停展开，移开收起","按使用状态自动切换浮窗大小。",305)
        this.Text(4,"显示队列浮窗",264,385,460,24,11,"18253D",true)
        this.Switch(4,"Visible","显示队列浮窗",890,378)
        this.Surface(4,240,440,736,196)
        this.SliderLabels := Map()
        for row in [["CollapsedDiameter","收起直径",456,100,300,120],["ExpandedDiameter","展开直径",500,320,640,420],["Diameter","固定直径",544,100,640,460],["Opacity","不透明度",588,35,100,95]] {
            this.SliderLabels[row[1]] := this.Text(4,"",264,row[3]+6,232,23,10)
            slider := this.Button(row[2],510,row[3],442,32,0,"slider",4,"FFFFFF")
            widget := SPSlider(this,slider,row[4],row[5],row[6])
            this.Controls[row[1]] := widget,this.Buttons[slider.Hwnd].Widget := widget
            widget.OnEvent("Change",(*)=>this.AppearanceLabels())
        }
        this.Controls["AutoExpand"].OnEvent("Click",(*)=>this.AppearanceLabels())
    }
    BuildStatus() {
        this.ConnectionCard := this.Surface(5,240,174,736,126,"connection")
        this.ConnectionIcon := this.Surface(5,265,199,55,55,"connectionIcon","EAF6F3")
        this.ConnectionText := this.Text(5,"",342,198,586,35,17,"176854",true,"EAF6F3")
        this.QueueText := this.Text(5,"",342,251,586,25,10,"4E756A",false,"EAF6F3")
        this.Section(5,"启动与保护",242,326)
        this.Surface(5,240,356,736,128)
        this.Text(5,"登录 Windows 后自动就绪",264,375,576,29,13,"18253D",true)
        this.Text(5,"每台设置一次。关闭顺序增强时，后台组件仍会保留。",264,420,600,24,9,"69758B")
        this.Switch(5,"AutoStart","登录后在后台启动",890,376)
        this.StartupStatus := this.Text(5,"",264,456,640,21,9,"69758B")
        this.Surface(5,240,502,736,70)
        this.Text(5,"断线保护  ·  始终开启",264,517,630,25,11,"18253D",true)
        this.Text(5,"未连接时 Ctrl+V 普通粘贴；恢复连接不会自动补贴。",264,548,650,21,9,"69758B")
        this.Surface(5,240,590,736,46)
        this.Text(5,"配置与启动诊断",264,604,263,24,10,"69758B")
        this.Button("打开项目文件夹",595,597,174,31,(*)=>this.OpenFolder(),"ghost",5,"FFFFFF")
        this.Button("启动诊断",787,597,165,31,(*)=>this.OpenLog(),"soft",5,"FFFFFF")
    }
    OpenFolder() {
        SplitPath(this.Owner.ConfigPath,,&folder)
        Run('explorer.exe "' folder '"')
    }
    OpenLog() {
        SplitPath(this.Owner.ConfigPath,,&folder)
        path := folder "\Logs\background-startup.txt"
        if FileExist(path)
            Run('notepad.exe "' path '"')
        else
            this.Message("还没有启动诊断记录。保存登录启动后会自动生成。")
    }
    Load() {
        owner := this.Owner
        for prefName, fallback in SPPreferences.Defaults
            if this.Controls.Has(prefName)
                this.Controls[prefName].Value := owner.%prefName%
        this.Controls["NumericTypingMaxDigits"].Value := owner.NumericTypingMaxDigits
        this.Controls["QueuePasteMode"].Choose(owner.QueuePaste?1:2)
        this.Controls["TypingMethodMode"].Choose(owner.TypingMethod+1)
        this.LoadPolicy()
        for prefName, fallback in Map("AutoExpand",1,"CollapsedDiameter",120,"ExpandedDiameter",420,"Diameter",460,"Opacity",95,"Visible",1) {
            val := IniRead(owner.ConfigPath,"Panel",prefName,fallback)
            if IsObject(owner.Panel)
                val := prefName="Diameter"?owner.Panel.FixedDiameter:(prefName="Visible"?owner.Panel.Visible:owner.Panel.%prefName%)
            this.Controls[prefName].Value := val
        }
        this.Controls["AutoStart"].Value := SPPreferences.AutoStart(owner)
        this.AppearanceLabels(),this.RefreshStatus()
    }
    LoadPolicy() {
        if this.Owner.Shared {
            SQ.Poll()
            this.Controls["BatchMode"].Choose(SQ.BatchContinue?2:1)
            this.Controls["AdvanceMode"].Choose(SQ.AutoAdvance?1:2)
            this.Controls["IdleSeconds"].Value := SQ.IdleSeconds
        } else {
            this.Controls["BatchMode"].Choose(this.Owner.BatchContinue?2:1)
            this.Controls["AdvanceMode"].Choose(this.Owner.AutoAdvance?1:2)
            this.Controls["IdleSeconds"].Value := this.Owner.TimeoutMs//1000
        }
    }
    AppearanceLabels() {
        for name,label in this.SliderLabels
            label.Text := SPPreferences.Label(name) "   " this.Controls[name].Value (name="Opacity"?"%":"")
        this.Controls["Diameter"].Enabled := !this.Controls["AutoExpand"].Value
        this.Controls["CollapsedDiameter"].Enabled := !!this.Controls["AutoExpand"].Value
        this.Controls["ExpandedDiameter"].Enabled := !!this.Controls["AutoExpand"].Value
    }
    Navigate(page,*) => this.Show(page)
    Show(page:=1) {
        if !IsObject(this.Gui)
            this.Build()
        this.Page := Max(1,Min(5,page))
        for idx,controls in this.Pages
            for control in controls
                control.Visible := idx=this.Page
        titles := ["采集与粘贴","数字输入","队列规则","浮窗外观","连接与状态"]
        subtitles := ["把每一次明确操作，排成井然有序的下一步。","准确保留每一位，也照顾目标软件的输入节奏。","选择适合你的接续方式，让两台设备步调一致。","少一点打扰，多一点恰到好处。","随时就绪，在设备之间自然接续。"]
        shared := this.Page=3 && this.Owner.Shared
        this.Title.Text := titles[this.Page],this.Subtitle.Text := subtitles[this.Page]
        this.Scope.Text := shared?"两端共享规则":"仅本机设置"
        this.SaveButton.Text := shared?"同步两端规则":"保存本机设置"
        this.Buttons[this.SaveButton.Hwnd].Label := this.SaveButton.Text
        this.DefaultButton.Visible := this.Page!=5
        this.Message(this.Page=2?SPInputDiagnostics.Summary(this.Owner):"更改后点击保存，让工作方式适合你。")
        this.RefreshStatus(),this.PaintButtons()
        this.Gui.Show("w" Round(1000*this.Scale) " h" Round(760*this.Scale))
    }
    PaintButtons() {
        for hwnd,item in this.Buttons {
            if item.Control.Type!="Button"
                continue
            ControlSetStyle((ControlGetStyle(hwnd)&~0xF)|0xB,hwnd)
            DllCall("uxtheme\SetWindowTheme","ptr",hwnd,"str","","str","")
            this.Redraw(hwnd)
        }
    }
    Redraw(hwnd) => DllCall("InvalidateRect","ptr",hwnd,"ptr",0,"int",true)
    RefreshStatus() {
        owner := this.Owner
        this.EnabledText.Text := owner.Enabled?"顺序增强已开启":"顺序增强已关闭"
        this.ConnectionText.Text := owner.Shared?(SQ.Connected?"两台已连接":"等待另一台连接"):"本机独立模式"
        this.QueueText.Text := "当前队列 " owner.Queue.Length " 条    ·    下一条 " owner.Index "    ·    断线仍可普通粘贴"
        this.StartupStatus.Text := SPPreferences.AutoStart(owner)?"已验证启动项 · 下次登录自动运行":"尚未启用 · 开启后点击保存"
        mode := owner.Shared?(SQ.Connected?"connected":"waiting"):"local"
        if !this.HasOwnProp("ConnectionMode") || this.ConnectionMode!=mode {
            this.ConnectionMode := mode
            tint := mode="connected"?"EAF6F3":mode="waiting"?"FFF4DE":"EDF2FF"
            ink := mode="connected"?"176854":mode="waiting"?"8A631B":"355AC6"
            this.Buttons[this.ConnectionCard.Hwnd].Fill := tint
            this.Buttons[this.ConnectionIcon.Hwnd].Bg := tint
            this.ConnectionText.Opt("Background" tint),this.QueueText.Opt("Background" tint)
            this.ConnectionText.SetFont("c" ink),this.QueueText.SetFont("c" ink)
            this.Redraw(this.ConnectionCard.Hwnd),this.Redraw(this.ConnectionIcon.Hwnd)
        }
    }
    Message(text,error:=false) {
        this.Feedback.Text := text
        this.Feedback.SetFont(error?"cB83B46":"c536A89")
    }
    Toggle() {
        this.Owner.Toggle(),this.RefreshStatus()
        this.Message(this.Owner.Shared && !SQ.Connected?"未连接，无法确认两端开关状态。":"增强开关已操作；其他规则请点击保存。")
    }
    Values() {
        values := Map()
        for name in ["CaptureCopy","CaptureCut","CaptureImages","FormattedText","ResetEsc","ResetUndo","AutoNumber","NumericTypingMaxDigits","TypeDelay","AutoExpand","CollapsedDiameter","ExpandedDiameter","Diameter","Opacity","Visible","AutoStart"]
            values[name] := this.Controls[name].Value
        values["QueuePaste"] := this.Controls["QueuePasteMode"].Value=1?1:0
        values["TypingMethod"] := this.Controls["TypingMethodMode"].Value-1
        return values
    }
    Save() {
        if this.Owner.Busy {
            this.Message("当前操作尚未结束，请稍后保存。",true)
            return
        }
        this.SaveButton.Enabled := false
        try {
            if this.Page=3 {
                policy := Map("BatchContinue",this.Controls["BatchMode"].Value=2?1:0,"AutoAdvance",this.Controls["AdvanceMode"].Value=1?1:0,"IdleSeconds",this.Controls["IdleSeconds"].Value)
                SPPreferences.Validate(policy)
                if this.Owner.Shared {
                    if !SQ.SetPolicy(policy)
                        throw Error(this.Owner.LastError!=""?this.Owner.LastError:"两端规则未确认，请连接后重试")
                    this.LoadPolicy()
                } else
                    SPPreferences.Save(this.Owner,policy)
                this.Message(this.Owner.Shared?"两端规则已同步，并已保存。":"队列规则已保存。")
            } else {
                values := this.Values()
                SPPreferences.Save(this.Owner,values)
                SPPreferences.SetAutoStart(this.Owner,values["AutoStart"])
                this.Message(this.Page=5?"本机设置已保存，登录启动状态已校验。":"本机设置已保存，即刻按你的偏好工作。")
            }
        } catch as err {
            this.Controls["AutoStart"].Value := SPPreferences.AutoStart(this.Owner)
            this.Message(err.Message,true)
        } finally {
            this.RefreshStatus(),this.SaveButton.Enabled := true,this.PaintButtons()
        }
    }
    Defaults() {
        keys := this.Page=1?["CaptureCopy","CaptureCut","CaptureImages","FormattedText","ResetEsc","ResetUndo"]:this.Page=2?["AutoNumber","TypeDelay"]:[]
        for name in keys
            this.Controls[name].Value := SPPreferences.Defaults[name]
        if this.Page=1
            this.Controls["QueuePasteMode"].Choose(1)
        if this.Page=2
            this.Controls["NumericTypingMaxDigits"].Value := 20,this.Controls["TypingMethodMode"].Choose(1)
        if this.Page=3
            this.Controls["BatchMode"].Choose(1),this.Controls["AdvanceMode"].Choose(1),this.Controls["IdleSeconds"].Value := 300
        if this.Page=4 {
            for name,value in Map("AutoExpand",1,"CollapsedDiameter",120,"ExpandedDiameter",420,"Diameter",460,"Opacity",95,"Visible",1)
                this.Controls[name].Value := value
            this.AppearanceLabels()
        }
        this.Message("已恢复本页默认值，点击保存后生效。")
    }
    Mouse(wParam,lParam,msg,hwnd) {
        if IsObject(this.Sliding) {
            if msg=0x200 || msg=0x202
                this.Sliding.SetFromPointer()
            if msg=0x202 {
                this.Sliding := 0,DllCall("ReleaseCapture")
                return 0
            }
            if msg=0x200
                return 0
        }
        if msg=0x2A3 || !this.Buttons.Has(hwnd) || this.Buttons[hwnd].Control.Type!="Button" {
            if this.HoverHwnd {
                old := this.HoverHwnd,this.HoverHwnd := 0,this.Redraw(old)
            }
            return
        }
        item := this.Buttons[hwnd]
        if msg=0x200 {
            track := Buffer(A_PtrSize=8?24:16,0)
            NumPut("uint",track.Size,"uint",2,"ptr",hwnd,track)
            DllCall("TrackMouseEvent","ptr",track)
            if this.HoverHwnd!=hwnd {
                old := this.HoverHwnd,this.HoverHwnd := hwnd
                if old
                    this.Redraw(old)
                this.Redraw(hwnd)
            }
            DllCall("SetCursor","ptr",DllCall("LoadCursor","ptr",0,"ptr",32649,"ptr"))
        }
        if msg=0x201 && item.Style="slider" && item.Control.Enabled {
            this.Sliding := item.Widget,DllCall("SetFocus","ptr",hwnd),DllCall("SetCapture","ptr",hwnd)
            item.Widget.SetFromPointer()
            return 0
        }
    }
    Key(wParam,lParam,msg,hwnd) {
        if !this.Buttons.Has(hwnd)
            return
        item := this.Buttons[hwnd]
        if item.Style="slider" && item.Control.Enabled {
            if msg=0x87
                return 0x2021
            widget := item.Widget
            if wParam=0x25 || wParam=0x28 || wParam=0x27 || wParam=0x26 || wParam=0x24 || wParam=0x23 {
                widget.Value := wParam=0x24?widget.Min:wParam=0x23?widget.Max:widget.Value+((wParam=0x25 || wParam=0x28)?-1:1)
                widget.Change()
                return 0
            }
        }
    }
    Draw(wParam,data,*) {
        hwnd := NumGet(data,A_PtrSize=8?24:20,"ptr")
        if !this.Buttons.Has(hwnd)
            return
        item := this.Buttons[hwnd],dc := NumGet(data,A_PtrSize=8?32:24,"ptr"),state := NumGet(data,16,"uint")
        rect := data+(A_PtrSize=8?40:28),w := NumGet(rect,8,"int")-NumGet(rect,0,"int"),h := NumGet(rect,12,"int")-NumGet(rect,4,"int")
        u := this.Scale*this.Dpi/96
        bg := item.Bg
        clearBrush := DllCall("CreateSolidBrush","uint",this.BGR(bg),"ptr")
        DllCall("FillRect","ptr",dc,"ptr",rect,"ptr",clearBrush),DllCall("DeleteObject","ptr",clearBrush)
        DllCall("gdiplus\GdipCreateFromHDC","ptr",dc,"ptr*",&g:=0)
        DllCall("gdiplus\GdipSetSmoothingMode","ptr",g,"int",4)
        style := item.Style,hover := this.HoverHwnd=hwnd,pressed := state&1,disabled := !item.Control.Enabled
        ink := "18253D",left := 0,right := w,align := 1
        switch style {
            case "sidebar": this.Fill(g,"111D32",0,0,w,h)
            case "card":
                this.Round(g,"E8EDF5",0,1*u,w,h-1*u,15*u)
                this.Round(g,"FFFFFF",1*u,0,w-2*u,h-2*u,15*u)
            case "input": this.Round(g,"F3F5FA",0,0,w,h,10*u)
            case "sidebarNote": this.Round(g,"1A2942",0,0,w,h,13*u)
            case "tip": this.Round(g,"EDF2FF",0,0,w,h,15*u)
            case "connection": this.Round(g,item.HasOwnProp("Fill")?item.Fill:"EAF6F3",0,0,w,h,15*u)
            case "badge": this.Round(g,"E8EEFC",0,0,w,h,15*u)
            case "line": this.Fill(g,"E2E8F1",0,0,w,h)
            case "brand":
                this.Round(g,"3873FF",0,0,w,h,12*u)
                this.Round(g,"FFFFFF",12*u,10*u,16*u,21*u,4*u)
                this.Round(g,"C4D6FF",18*u,15*u,14*u,18*u,4*u)
            case "preview":
                this.Round(g,"EDF2FF",0,0,w,h,20*u)
                this.Circle(g,"3E72ED",w*.16,h*.16,w*.68,h*.68)
                this.Circle(g,"FFFFFF",w*.23,h*.23,w*.54,h*.54)
                this.Circle(g,"E6EEFF",w*.32,h*.32,w*.36,h*.36)
            case "connectionIcon":
                this.Round(g,"D4ECE5",0,0,w,h,16*u)
                this.Round(g,"218268",11*u,14*u,22*u,17*u,4*u)
                this.Round(g,"EAF6F3",14*u,17*u,16*u,11*u,2*u)
                this.Round(g,"218268",24*u,26*u,20*u,16*u,4*u)
                this.Round(g,"EAF6F3",27*u,29*u,14*u,10*u,2*u)
            case "switch":
                on := item.Widget.Value
                this.Round(g,disabled?"DCE2ED":on?(pressed?"2653C2":hover?"417FFF":"316BF1"):hover?"B7C5DD":"D0D9E7",2*u,3*u,w-4*u,h-6*u,14*u)
                knob := h-12*u
                this.Circle(g,"FFFFFF",on?w-knob-6*u:6*u,6*u,knob,knob)
            case "slider":
                widget := item.Widget,pct := (widget.Value-widget.Min)/(widget.Max-widget.Min)
                this.Round(g,"E5EAF2",12*u,h/2-3*u,w-24*u,6*u,3*u)
                this.Round(g,disabled?"BFCADA":"3873F5",12*u,h/2-3*u,Max(6*u,(w-24*u)*pct),6*u,3*u)
                knobX := 12*u+(w-24*u)*pct
                this.Circle(g,disabled?"CDD6E4":"E1E9FC",knobX-11*u,h/2-11*u,22*u,22*u)
                this.Circle(g,disabled?"99A9C1":"316BF1",knobX-7*u,h/2-7*u,14*u,14*u)
            case "nav":
                active := item.Page=this.Page
                if active || hover
                    this.Round(g,active?"2F66E8":"1D2E49",0,0,w,h,12*u)
                ink := active?"FFFFFF":"ABBBD5",align := 0,left := 49*u
                this.NavIcon(g,item.Page,17*u,(h-20*u)/2,20*u,active?"FFFFFF":"8DA4C8")
            case "choice":
                selected := item.Widget.Value=item.Choice
                this.Round(g,"F0F3F9",0,0,w,h,9*u)
                if selected
                    this.Round(g,"DCE7FF",2*u,2*u,w-4*u,h-4*u,8*u)
                ink := selected?"285AC4":"6B7891"
            default:
                fill := style="primary"?(pressed?"2554C2":hover?"477FFF":"316BF1"):style="soft"?(hover?"DDE7FF":"EDF2FF"):style="step"?(hover?"E0E7F4":"F3F5FA"):style="ghost"?(hover?"E8EEFA":bg):(hover?"E8EEF9":"FFFFFF")
                this.Round(g,disabled?"DDE4F0":fill,0,0,w,h,11*u)
                ink := disabled?"8593AA":style="primary"?"FFFFFF":style="soft"?"315FCB":style="ghost"?"6E7E98":"334563"
        }
        if item.Control.Type="Button" && state&16
            this.Round(g,"A7C2FF",2*u,2*u,w-4*u,h-4*u,10*u,true)
        DllCall("gdiplus\GdipDeleteGraphics","ptr",g)
        if item.Control.Type="Button" && style!="switch" && style!="slider" {
            font := SendMessage(0x31,0,0,item.Control.Hwnd)
            oldFont := font?DllCall("SelectObject","ptr",dc,"ptr",font,"ptr"):0
            DllCall("SetBkMode","ptr",dc,"int",1),DllCall("SetTextColor","ptr",dc,"uint",this.BGR(ink))
            labelRect := Buffer(16,0),NumPut("int",Round(left),"int",0,"int",Round(right),"int",h,labelRect)
            label := item.HasOwnProp("Label")?item.Label:item.Control.Text
            if style="choice" && item.Widget.Value=item.Choice
                label := "✓  " label
            DllCall("DrawTextW","ptr",dc,"str",label,"int",-1,"ptr",labelRect,"uint",0x24|align)
            if oldFont
                DllCall("SelectObject","ptr",dc,"ptr",oldFont)
        }
        return true
    }
    BGR(hex) {
        rgb := Integer("0x" hex)
        return ((rgb&255)<<16)|(rgb&0xFF00)|((rgb>>16)&255)
    }
    Fill(g,hex,x,y,w,h) {
        DllCall("gdiplus\GdipCreateSolidFill","uint",Integer("0xFF" hex),"ptr*",&brush:=0)
        DllCall("gdiplus\GdipFillRectangle","ptr",g,"ptr",brush,"float",x,"float",y,"float",w,"float",h)
        DllCall("gdiplus\GdipDeleteBrush","ptr",brush)
    }
    Circle(g,hex,x,y,w,h) {
        DllCall("gdiplus\GdipCreateSolidFill","uint",Integer("0xFF" hex),"ptr*",&brush:=0)
        DllCall("gdiplus\GdipFillEllipse","ptr",g,"ptr",brush,"float",x,"float",y,"float",w,"float",h)
        DllCall("gdiplus\GdipDeleteBrush","ptr",brush)
    }
    Round(g,hex,x,y,w,h,r,outline:=false) {
        r := Min(r,w/2,h/2),d := Max(1,r*2)
        DllCall("gdiplus\GdipCreatePath","int",0,"ptr*",&path:=0)
        for arc in [[x,y,180],[x+w-d,y,270],[x+w-d,y+h-d,0],[x,y+h-d,90]]
            DllCall("gdiplus\GdipAddPathArc","ptr",path,"float",arc[1],"float",arc[2],"float",d,"float",d,"float",arc[3],"float",90)
        DllCall("gdiplus\GdipClosePathFigure","ptr",path)
        if outline {
            DllCall("gdiplus\GdipCreatePen1","uint",Integer("0xFF" hex),"float",2,"int",2,"ptr*",&pen:=0)
            DllCall("gdiplus\GdipDrawPath","ptr",g,"ptr",pen,"ptr",path)
            DllCall("gdiplus\GdipDeletePen","ptr",pen)
        } else {
            DllCall("gdiplus\GdipCreateSolidFill","uint",Integer("0xFF" hex),"ptr*",&brush:=0)
            DllCall("gdiplus\GdipFillPath","ptr",g,"ptr",brush,"ptr",path)
            DllCall("gdiplus\GdipDeleteBrush","ptr",brush)
        }
        DllCall("gdiplus\GdipDeletePath","ptr",path)
    }
    NavIcon(g,index,x,y,s,ink) {
        if index=1 {
            this.Round(g,ink,x,y,s*.7,s*.85,s*.14),this.Round(g,"244575",x+s*.14,y+s*.17,s*.42,s*.12,s*.06)
            this.Round(g,ink,x+s*.47,y+s*.42,s*.52,s*.59,s*.14)
        } else if index=2 {
            for row in [0,1]
                for col in [0,1,2]
                    this.Round(g,ink,x+col*s*.36,y+row*s*.57,s*.25,s*.34,s*.06)
        } else if index=3 {
            for row in [0,1,2] {
                this.Circle(g,ink,x,y+row*s*.39,s*.16,s*.16)
                this.Round(g,ink,x+s*.3,y+row*s*.39,s*.68,s*.13,s*.06)
            }
        } else if index=4 {
            this.Circle(g,ink,x,y,s,s),this.Circle(g,"254575",x+s*.23,y+s*.23,s*.54,s*.54)
        } else {
            this.Round(g,ink,x,y+s*.18,s*.72,s*.52,s*.12)
            this.Round(g,ink,x+s*.48,y+s*.52,s*.5,s*.4,s*.1)
        }
    }
    Close(*) {
        if !IsObject(this.Gui)
            return
        SetTimer(this.StatusCallback,0),OnMessage(0x2B,this.DrawCallback,0)
        for message in [0x200,0x201,0x202,0x2A3]
            OnMessage(message,this.MouseCallback,0)
        if IsObject(this.Sliding)
            DllCall("ReleaseCapture")
        for hwnd,item in this.Buttons
            if item.Style="slider"
                item.Widget.Dispose()
        this.Owner.SettingsWindow := 0
        closingGui := this.Gui,this.Gui := 0
        closingGui.Destroy()
        if this.GdipToken
            DllCall("gdiplus\GdiplusShutdown","ptr",this.GdipToken),this.GdipToken := 0
        if this.GdipLibrary
            DllCall("FreeLibrary","ptr",this.GdipLibrary),this.GdipLibrary := 0
        this.Buttons.Clear(),this.Controls.Clear(),this.Pages := [],this.Nav := []
        this.DrawCallback := 0,this.StatusCallback := 0,this.MouseCallback := 0,this.KeyCallback := 0
        this.Sliding := 0,this.Owner := 0
    }
}

class SPToggle {
    __New(owner,control,label) {
        this.Owner := owner,this.Control := control,this.Label := label,this.Checked := false,this.Callbacks := []
    }
    Value {
        get => this.Checked?1:0
        set {
            this.Checked := !!value
            this.Control.Text := this.Label (value?"（已开启）":"（已关闭）")
            this.Owner.Redraw(this.Control.Hwnd)
        }
    }
    Enabled {
        get => this.Control.Enabled
        set => this.Control.Enabled := value
    }
    Toggle(*) {
        this.Value := !this.Value
        for handler in this.Callbacks
            handler(this)
    }
    OnEvent(name,handler) => this.Callbacks.Push(handler)
}
class SPChoice {
    __New(owner,labels,x,y,w,page) {
        this.Owner := owner,this.Selected := 1,this.Buttons := [],this.Labels := labels
        for idx,label in labels {
            control := owner.Button(label,x+(idx-1)*(w/labels.Length+2),y,w/labels.Length-2,36,ObjBindMethod(this,"Select",idx),"choice",page,"FFFFFF")
            owner.Buttons[control.Hwnd].Widget := this,owner.Buttons[control.Hwnd].Choice := idx
            this.Buttons.Push(control)
        }
    }
    Value {
        get => this.Selected
        set => this.Choose(value)
    }
    Choose(index) {
        this.Selected := Max(1,Min(this.Buttons.Length,Integer(index)))
        for idx,control in this.Buttons {
            control.Text := this.Labels[idx] (idx=this.Selected?"（已选择）":"")
            this.Owner.Redraw(control.Hwnd)
        }
    }
    Select(index,*) => this.Choose(index)
}
class SPSlider {
    __New(owner,control,min,max,value) {
        this.Owner := owner,this.Control := control,this.Label := control.Text,this.Min := min,this.Max := max,this.Current := value,this.Callbacks := []
        this.NativeCallback := CallbackCreate(ObjBindMethod(this,"WndProc"),"Fast",6)
        if !DllCall("comctl32\SetWindowSubclass","ptr",control.Hwnd,"ptr",this.NativeCallback,"uptr",1,"uptr",0)
            throw Error("无法初始化滑条键盘交互")
    }
    Value {
        get => this.Current
        set {
            this.Current := Max(this.Min,Min(this.Max,Round(value)))
            this.Control.Text := this.Label "：" this.Current
            this.Owner.Redraw(this.Control.Hwnd)
        }
    }
    Enabled {
        get => this.Control.Enabled
        set {
            this.Control.Enabled := value
            this.Owner.Redraw(this.Control.Hwnd)
        }
    }
    OnEvent(name,handler) => this.Callbacks.Push(handler)
    Change() {
        for handler in this.Callbacks
            handler(this)
    }
    WndProc(hwnd,msg,wParam,lParam,id,ref) {
        if msg=0x87
            return 0x2021
        if msg=0x100 && this.Control.Enabled && (wParam=0x25 || wParam=0x26 || wParam=0x27 || wParam=0x28 || wParam=0x24 || wParam=0x23)
            return this.Owner.Key(wParam,lParam,msg,hwnd)
        return DllCall("comctl32\DefSubclassProc","ptr",hwnd,"uint",msg,"uptr",wParam,"ptr",lParam,"ptr")
    }
    Dispose() {
        if this.NativeCallback {
            DllCall("comctl32\RemoveWindowSubclass","ptr",this.Control.Hwnd,"ptr",this.NativeCallback,"uptr",1)
            CallbackFree(this.NativeCallback),this.NativeCallback := 0
        }
    }
    SetFromPointer() {
        point := Buffer(8),DllCall("GetCursorPos","ptr",point),DllCall("ScreenToClient","ptr",this.Control.Hwnd,"ptr",point)
        WinGetClientPos(,,&width,,this.Control.Hwnd)
        inset := 12*this.Owner.Scale*this.Owner.Dpi/96
        this.Value := this.Min+(this.Max-this.Min)*(NumGet(point,0,"int")-inset)/(width-2*inset)
        this.Change()
    }
}
