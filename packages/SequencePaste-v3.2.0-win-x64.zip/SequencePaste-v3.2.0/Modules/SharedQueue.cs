﻿// Shared queue v2. Durable, single-coordinator state; never replays desktop output.
using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Web.Script.Serialization;

public sealed class SQCursor {
    public long Sequence;
    public string Fingerprint = "", Result = "";
}
public sealed class SQState {
    public List<int> ImageIndexes = new List<int>();
    public bool LastImage, LeaseImage;
    public bool Enabled = true, NativeMode;
    public bool BatchContinue, AutoAdvance = true;
    public int IdleSeconds = -1;
    public string Epoch = Guid.NewGuid().ToString("D"), Batch = Guid.NewGuid().ToString("D");
    public long Revision = 1, Activity = DateTime.UtcNow.Ticks;
    public List<string> Items = new List<string>();
    public int Index = 1, LastIndex, LeaseIndex;
    public string LastText = "", LeaseToken = "", LeaseOwner = "", LeaseKind = "", LeaseText = "";
    public bool LastTyped, LeaseTyped;
    public Dictionary<string, SQCursor> Clients = new Dictionary<string, SQCursor>();
}
public sealed class SQCommand {
    public long Sequence, Revision, Deadline;
    public string Kind, Epoch, Batch, Token, Text, Raw;
    public bool Typed;
    public static SQCommand Parse(string raw) {
        if (raw == null || raw.Length > 600000) throw new InvalidDataException("Command size");
        string[] f = raw.Replace("\r", "").Split('\n');
        long sequence, revision, deadline;
        if (f.Length != 10 || f[0] != "SQCMD5" || !long.TryParse(f[1], out sequence) || sequence < 0
            || !long.TryParse(f[5], out revision) || revision < 0 || !long.TryParse(f[9], out deadline)
            || (f[7] != "0" && f[7] != "1") || f[2].Length > 16)
            throw new InvalidDataException("Command header");
        string text = SQEngine.Decode(f[8]);
        if (text.Length > 100000 || text.IndexOf('\0') >= 0) throw new InvalidDataException("Command text");
        if (sequence == 0 && f[2] != "POLL") throw new InvalidDataException("Sequence zero");
        return new SQCommand {Sequence=sequence, Kind=f[2], Epoch=f[3], Batch=f[4], Revision=revision,
            Token=f[6], Typed=f[7]=="1", Text=text, Deadline=deadline, Raw=raw};
    }
}
public sealed class SQEngine {
    readonly string path;

    readonly object gate = new object();
    readonly JavaScriptSerializer json = new JavaScriptSerializer {MaxJsonLength=16000000, RecursionLimit=32};
    SQState state;
    string cachedSnapshot="", cachedEpoch="";
    long cachedRevision=-1;
    public SQEngine(string path, int timeoutSeconds) {
        this.path = path;
        // Corrupt state fails closed. Never silently replace a pending output with an empty queue.
        if(File.Exists(path)) {
            string[] saved=File.ReadAllText(path,Encoding.UTF8).Split(new[]{'\n'},3);
            if(saved.Length!=3 || (saved[0]!="SQDB2" && saved[0]!="SQDB3" && saved[0]!="SQDB4" && saved[0]!="SQDB5") || saved[1]!=SuinQueueBridge.Digest(saved[2]))
                throw new InvalidDataException("Shared state checksum / format mismatch; restore backup");
            state=json.Deserialize<SQState>(saved[2]);
        } else state=new SQState();
        if(state.IdleSeconds == -1) state.IdleSeconds=Math.Min(86400,Math.Max(0,timeoutSeconds));
        ValidateState();
        Save();
    }
    void ValidateState() {
        Guid g;
        if (state == null || !Guid.TryParse(state.Epoch, out g) || !Guid.TryParse(state.Batch, out g)
            || state.Items == null || state.Clients == null || state.Items.Count > 500 || state.Clients.Count > 8
            || state.IdleSeconds<0 || state.IdleSeconds>86400
            || state.Index < 1 || state.Index > state.Items.Count + 1 || state.Revision < 1
            || state.Items.Any(t => t == null || t.Length == 0 || t.Length > 100000 || t.IndexOf('\0') >= 0)
            || state.Items.Sum(t => t.Length) > 500000
            || (state.LeaseToken != "" && (state.LeaseText == "" || state.LeaseOwner == "")))
            throw new InvalidDataException("Shared coordinator state is invalid; restore backup");
        if(state.ImageIndexes==null || state.ImageIndexes.Distinct().Count()!=state.ImageIndexes.Count
            || state.ImageIndexes.Any(i=>i<1 || i>state.Items.Count || !SQAssets.ValidReference(state.Items[i-1]))
            || state.ImageIndexes.Count>100 || state.ImageIndexes.Sum(i=>SQAssets.ReferenceSize(state.Items[i-1]))>128L*1024*1024
            || (state.LastImage && !SQAssets.ValidReference(state.LastText)) || (state.LeaseImage && !SQAssets.ValidReference(state.LeaseText)))
            throw new InvalidDataException("Image item metadata invalid");
    }
    void Save() {
        string body=json.Serialize(state);
        SuinQueueBridge.AtomicWrite(path,"SQDB5\n"+SuinQueueBridge.Digest(body)+"\n"+body);
    }
    public static string Encode(string text) { return Convert.ToBase64String(Encoding.UTF8.GetBytes(text ?? "")); }
    public static string Decode(string text) { return new UTF8Encoding(false, true).GetString(Convert.FromBase64String(text)); }
    string SnapshotUnsafe() {
        if(cachedEpoch==state.Epoch && cachedRevision==state.Revision) return cachedSnapshot;
        var f = new List<string> {"SQSTATE5", state.Epoch, state.Revision.ToString(), state.Batch,
            state.Index.ToString(), state.Items.Count.ToString(), state.LastIndex.ToString(), state.LastTyped?"1":"0",
            Encode(state.LastText), state.LeaseToken, state.LeaseOwner, state.LeaseKind, state.LeaseIndex.ToString(),
            state.LeaseTyped?"1":"0", Encode(state.LeaseText)};
        foreach (string item in state.Items) f.Add(Encode(item));
        f.Add(Encode(String.Join(",",state.ImageIndexes.Select(i=>i.ToString()).ToArray())+";"+(state.LastImage?"1":"0")+";"+(state.LeaseImage?"1":"0")+";"+(state.BatchContinue?"1":"0")+";"+(state.AutoAdvance?"1":"0")+";"+state.IdleSeconds));
        f.Add(state.Enabled?"1":"0"); f.Add(state.NativeMode?"1":"0");
        cachedEpoch=state.Epoch;cachedRevision=state.Revision;
        return cachedSnapshot=String.Join("\n", f.ToArray());
    }
    public string Snapshot() { lock(gate) return SnapshotUnsafe(); }
    string Reply(long sequence, string code) {
        return "SQRES5\n" + sequence + "\n" + code + "\n" + Encode(SnapshotUnsafe());
    }
    void Changed() { state.Revision++; state.Activity=DateTime.UtcNow.Ticks; }
    void Clear() {
        state.Items.Clear(); state.Index=1; state.LastIndex=0; state.LastText=""; state.LastTyped=false;
        state.Batch=Guid.NewGuid().ToString("D");
        state.NativeMode=false;
        state.ImageIndexes.Clear();state.LastImage=false;
    }
    void Release() {
        state.LeaseToken=""; state.LeaseOwner=""; state.LeaseKind=""; state.LeaseText="";
        state.LeaseIndex=0; state.LeaseTyped=false;
        state.LeaseImage=false;
    }
    void Complete(bool typed) {
        if (state.LeaseKind != "replay") {
            state.LastIndex=state.LeaseIndex; state.LastText=state.LeaseText; state.LastTyped=typed;
            state.LastImage=state.LeaseImage;
            if(state.AutoAdvance) state.Index=state.LeaseIndex+1;
        }
        Release(); Changed();
    }
    public string Handle(string node, string raw, bool online) { return Handle(node,raw,online,null); }
    public string Handle(string node, string raw, bool online, bool? originExpired) {
        Guid parsed;
        if (!Guid.TryParse(node, out parsed)) throw new InvalidDataException("Node ID");
        var c=SQCommand.Parse(raw);
        lock(gate) {
            bool expired=state.IdleSeconds>0 && state.Items.Count>0 && state.LeaseToken==""
                && new TimeSpan(DateTime.UtcNow.Ticks-state.Activity).TotalSeconds>=state.IdleSeconds;
            if(c.Kind=="POLL" && !expired) {
                // Idle polling carries only a revision acknowledgement, not the
                // entire (potentially 500,000-character) queue every 80 ms.
                if(c.Epoch==state.Epoch && c.Revision==state.Revision)
                    return "SQRES5\n"+c.Sequence+"\nUNCHANGED\n";
                return Reply(c.Sequence,"STATE");
            }
            string before=json.Serialize(state);
            try {
                if (expired) {
                    Clear(); Changed(); Save();
                }
                if (c.Kind=="POLL") return Reply(c.Sequence,"STATE");
                SQCursor prior;
                string fingerprint=SuinQueueBridge.Digest(raw);
                if (state.Clients.TryGetValue(node,out prior)) {
                    if (c.Sequence<prior.Sequence) return Reply(c.Sequence,"OLD_OPERATION");
                    if (c.Sequence==prior.Sequence)
                        return Reply(c.Sequence, prior.Fingerprint==fingerprint ? prior.Result : "SEQUENCE_REUSE");
                } else if (state.Clients.Count>=8) return Reply(c.Sequence,"DEVICE_LIMIT");
                string code;
                if (c.Epoch!="" && c.Epoch!=state.Epoch) code="EPOCH_CHANGED";
                else if (originExpired ?? (c.Deadline>0 && DateTimeOffset.UtcNow.ToUnixTimeSeconds()>c.Deadline)) code="EXPIRED";
                else code=Execute(node,c,online);
                // Busy/offline copies stay in the sender's durable ordered outbox.
                if (code=="WAIT_COPY") return Reply(c.Sequence,code);
                state.Clients[node]=new SQCursor {Sequence=c.Sequence,Fingerprint=fingerprint,Result=code};
                Save(); // Durable before any success / output permission leaves this process.
                return Reply(c.Sequence,code);
            } catch {
                state=json.Deserialize<SQState>(before);
                cachedRevision=-1;
                throw;
            }
        }
    }
    string Execute(string node,SQCommand c,bool online) {
        if (c.Kind=="COMMIT" || c.Kind=="ABORT" || c.Kind=="RESOLVE") {
            if (state.LeaseToken=="" || state.LeaseToken!=c.Token || state.LeaseOwner!=node) return "NOT_OWNER";
            if (c.Kind=="COMMIT" || (c.Kind=="RESOLVE" && c.Text=="yes")) Complete(c.Typed);
            else if (c.Kind=="ABORT" || (c.Kind=="RESOLVE" && c.Text=="no")) {Release(); Changed();}
            else return "INVALID";
            return "OK";
        }
        if (!online) return (c.Kind=="APPEND" || c.Kind=="APPEND_IMAGE" || c.Kind=="NATIVE") ? "WAIT_COPY" : "OFFLINE";
        // A global pause never cancels an in-flight output reservation. Its
        // original owner can still COMMIT/RESOLVE it through the branch above.
        if (c.Kind=="ENABLE") {
            if(c.Text!="on" && c.Text!="off") return "INVALID";
            state.Enabled=c.Text=="on"; state.NativeMode=true; Changed(); return "OK";
        }
        if (c.Kind=="NATIVE") {state.NativeMode=true; Changed(); return "OK";}
        if(c.Kind=="SETTINGS") {
            if(state.LeaseToken!="")return "BUSY";
            if(c.Epoch!=state.Epoch || c.Batch!=state.Batch || c.Revision!=state.Revision)return "STALE";
            string[] settings=c.Text.Split(';');int idle;
            if(settings.Length!=3 || (settings[0]!="0" && settings[0]!="1") || (settings[1]!="0" && settings[1]!="1")
                || !Int32.TryParse(settings[2],out idle) || idle<0 || idle>86400)return "INVALID";
            state.BatchContinue=settings[0]=="1";state.AutoAdvance=settings[1]=="1";state.IdleSeconds=idle;
            Changed();return "OK";
        }
        if (!state.Enabled) return "DISABLED";
        if (state.LeaseToken!="") return (c.Kind=="APPEND" || c.Kind=="APPEND_IMAGE")
            ? (state.LeaseOwner==node ? "OWNER_OUTPUT_PENDING" : "WAIT_COPY") : "BUSY";
        if (c.Kind=="APPEND" || c.Kind=="APPEND_IMAGE") {
            bool image=c.Kind=="APPEND_IMAGE";
            if(image && !SQAssets.ValidReference(c.Text)) return "INVALID_IMAGE";
            if (c.Text.Length==0) return "EMPTY_TEXT";
            bool fresh=state.NativeMode || (!state.BatchContinue && (state.Index>1 || (!state.AutoAdvance && state.LastIndex>0))) || state.Items.Count==0;
            if (!fresh && (state.Items.Count>=500 || state.Items.Sum(t=>t.Length)+c.Text.Length>500000)) return "QUEUE_LIMIT";
            if(image && !fresh && (state.ImageIndexes.Count>=100 || state.ImageIndexes.Sum(i=>SQAssets.ReferenceSize(state.Items[i-1]))+SQAssets.ReferenceSize(c.Text)>128L*1024*1024)) return "QUEUE_LIMIT";
            if (fresh) Clear();
            state.Items.Add(c.Text);
            if(image)state.ImageIndexes.Add(state.Items.Count);
            Changed(); return "OK";
        }
        if (c.Epoch!=state.Epoch || c.Batch!=state.Batch || c.Revision!=state.Revision) return "STALE";
        switch(c.Kind) {
            case "CLAIM":
                bool replay=c.Text=="replay";
                if (c.Text!="paste" && c.Text!="type" && !replay) return "INVALID";
                if (state.NativeMode && !replay) return "NATIVE";
                if (replay ? state.LastText=="" : state.Index>state.Items.Count) return "EMPTY";
                bool imageItem=replay?state.LastImage:state.ImageIndexes.Contains(state.Index);
                if(c.Text=="type" && imageItem) return "IMAGE_NOT_TEXT";
                state.LeaseToken=Guid.NewGuid().ToString("D"); state.LeaseOwner=node; state.LeaseKind=c.Text;
                state.LeaseIndex=replay?state.LastIndex:state.Index;
                state.LeaseText=replay?state.LastText:state.Items[state.Index-1];
                state.LeaseImage=imageItem;
                state.LeaseTyped=replay?state.LastTyped:c.Text=="type";
                Changed(); return "GRANTED";
            case "BACK": if(state.Index>1) {state.Index--;Changed();} return "OK";
            case "SKIP": if(state.Index<=state.Items.Count) {state.Index++;Changed();} return "OK";
            case "REWIND": if(state.Items.Count>0) {state.Index=1;Changed();} return "OK";
            case "CLEAR": Clear();Changed();return "OK";
            default: return "INVALID";
        }
    }
}

public sealed class SuinSharedBridge {
    readonly string root, role, bind, node;
    string host;
    readonly int port;
    readonly SuinQueueBridge transport;
    readonly Func<bool> alive;
    readonly SQEngine engine;
    DateTime lastPeer=DateTime.MinValue;
    string lastStatus="", lastView="", viewEpoch="", viewRevision="0", viewBatch="";
    public SuinSharedBridge(string root,string role,string host,string bind,int port,SuinQueueBridge transport,Func<bool> alive,int timeout) {
        this.root=root;this.role=role;this.host=host;this.bind=bind;this.port=port;this.transport=transport;this.alive=alive;
        foreach(string dir in new[]{"shared-requests","shared-results","shared-rejected"}) Directory.CreateDirectory(Path.Combine(root,dir));
        string idPath=Path.Combine(root,"shared-node.txt");
        if(!File.Exists(idPath)) SuinQueueBridge.AtomicWrite(idPath,Guid.NewGuid().ToString("D"));
        node=File.ReadAllText(idPath,Encoding.UTF8).Trim();
        Guid id;if(!Guid.TryParse(node,out id)) throw new InvalidDataException("Invalid saved node ID");
        if(role=="receiver") engine=new SQEngine(Path.Combine(root,"shared-coordinator.json"),timeout);
    }
    void Status(string value) {
        if(value==lastStatus) return;
        SuinQueueBridge.AtomicWrite(Path.Combine(root,"bridge-status.txt"),value);lastStatus=value;
    }
    string PollCommand() { return "SQCMD5\n0\nPOLL\n"+viewEpoch+"\n"+viewBatch+"\n"+viewRevision+"\n\n0\n\n0"; }
    void View(string snapshot) {
        if(snapshot==lastView) return;
        string[] header=snapshot.Split(new[]{'\n'},5);
        if(header.Length<5 || header[0]!="SQSTATE5") throw new InvalidDataException("Shared view header");
        SuinQueueBridge.AtomicWrite(Path.Combine(root,"shared-view.txt"),snapshot);lastView=snapshot;
        viewEpoch=header[1];viewRevision=header[2];viewBatch=header[3];
    }
    string Exchange(string command,bool expired) {
        string nonce=Guid.NewGuid().ToString("D");
        using(var client=new TcpClient()) {
            var pending=client.BeginConnect(host,port,null,null);
            using(pending.AsyncWaitHandle) {
                if(!pending.AsyncWaitHandle.WaitOne(800)) throw new TimeoutException();
                client.EndConnect(pending);
            }
            client.ReceiveTimeout=1800;client.SendTimeout=1800;
            using(var stream=client.GetStream()) {
                transport.Send(stream,"SQWIRE5\n"+node+"\n"+nonce+"\n"+(expired?"1":"0")+"\n"+SQEngine.Encode(command));
                string[] reply=transport.Receive(stream).Split('\n');
                if(reply.Length!=3 || reply[0]!="SQWIRE5" || reply[1]!=nonce) throw new InvalidDataException("VERSION_MISMATCH");
                return SQEngine.Decode(reply[2]);
            }
        }
    }
    string BlobExchange(string verb,string reference,int offset,byte[] data) {
        string nonce=Guid.NewGuid().ToString("D");
        using(var client=new TcpClient()) {
            var pending=client.BeginConnect(host,port,null,null);
            using(pending.AsyncWaitHandle){if(!pending.AsyncWaitHandle.WaitOne(800))throw new TimeoutException();client.EndConnect(pending);}
            client.ReceiveTimeout=1800;client.SendTimeout=1800;
            using(var stream=client.GetStream()) {
                transport.Send(stream,"SQBLOB5\n"+node+"\n"+nonce+"\n"+verb+"\n"+reference+"\n"+offset+"\n"+(data==null?"":Convert.ToBase64String(data)));
                string[] reply=transport.Receive(stream).Split('\n');
                if(reply.Length!=4 || reply[0]!="SQBLOB5" || reply[1]!=nonce || reply[2]=="ERROR")throw new InvalidDataException("Image transfer response");
                if(verb=="GET" && reply[2]!="DATA")throw new InvalidDataException("Remote image missing");
                if(reply[2]=="FULL")throw new IOException("IMAGE_CACHE_FULL: clean unused images on receiving PC");
                return reply[2]=="DATA"?reply[3]:reply[2];
            }
        }
    }
    void Upload(string reference) {
        if(!SQAssets.Ready(root,reference))throw new InvalidDataException("Local image missing");
        if(BlobExchange("HAS",reference,0,null)=="DONE")return;
        for(int offset=0;offset<SQAssets.ReferenceSize(reference);offset+=SQAssets.Chunk)
            BlobExchange("PUT",reference,offset,SQAssets.Get(root,reference,offset));
    }
    void PrepareImage(SQCommand command) {
        if(command.Kind=="APPEND_IMAGE") {
            if(role=="sender")Upload(command.Text);
            else if(!SQAssets.Ready(root,command.Text))throw new InvalidDataException("Local image missing");
        }
        if(command.Kind!="CLAIM" || lastView=="")return;
        string snapshot=role=="receiver"?engine.Snapshot():lastView;
        string[] f=snapshot.Split('\n');int count=Int32.Parse(f[5]),index=Int32.Parse(f[4]);
        string[] meta=SQEngine.Decode(f[count+15]).Split(';');
        bool replay=command.Text=="replay";
        bool image=replay?meta[1]=="1":meta[0].Split(',').Contains(index.ToString());
        if(!image || (!replay && index>count))return;
        string reference=SQEngine.Decode(replay?f[8]:f[index+14]);
        if(SQAssets.Ready(root,reference))return;
        if(role=="receiver")throw new InvalidDataException("Coordinator image missing");
        // Download before CLAIM. A slow transfer may expire a keypress, but it
        // must never grant an invisible output reservation while synchronizing.
        for(int offset=0;offset<SQAssets.ReferenceSize(reference);offset+=SQAssets.Chunk) {
            byte[] chunk=Convert.FromBase64String(BlobExchange("GET",reference,offset,null));
            SQAssets.Put(root,reference,offset,chunk);
        }
    }
    void Accept(TcpListener listener) {
        using(SQAssets.Lock(root)) {
        using(var client=listener.AcceptTcpClient()) {
            client.ReceiveTimeout=1800;client.SendTimeout=1800;
            using(var stream=client.GetStream()) {
                string request=transport.Receive(stream);
                string[] f=request.Split('\n');Guid parsed;
                if(f.Length==7 && f[0]=="SQBLOB5" && Guid.TryParse(f[1],out parsed) && f[1]!=node && Guid.TryParse(f[2],out parsed)) {
                    string response="ERROR",data="";int offset;
                    if(SQAssets.ValidReference(f[4]) && Int32.TryParse(f[5],out offset)) {
                        if(f[3]=="HAS")response=SQAssets.Ready(root,f[4])?"DONE":"MISSING";
                        else if(f[3]=="PUT"){
                            try{SQAssets.Put(root,f[4],offset,Convert.FromBase64String(f[6]));response="OK";}
                            catch(IOException e){if(!e.Message.StartsWith("IMAGE_CACHE_FULL"))throw;response="FULL";}
                        }
                        else if(f[3]=="GET"){
                            if(!SQAssets.Ready(root,f[4]))response="MISSING";
                            else{data=Convert.ToBase64String(SQAssets.Get(root,f[4],offset));response="DATA";}
                        }
                    }
                    lastPeer=DateTime.UtcNow;
                    transport.Send(stream,"SQBLOB5\n"+f[2]+"\n"+response+"\n"+data);return;
                }
                if(f.Length!=5 || f[0]!="SQWIRE5" || !Guid.TryParse(f[1],out parsed) || !Guid.TryParse(f[2],out parsed)
                    || (f[3]!="0" && f[3]!="1")) {
                    transport.Send(stream,"SQVERSION5");Status("VERSION_MISMATCH: update both PCs to v2.3");return;
                }
                if(f[1]==node) throw new InvalidDataException("DUPLICATE_DEVICE_ID");
                lastPeer=DateTime.UtcNow;
                string incoming=SQEngine.Decode(f[4]);var command=SQCommand.Parse(incoming);
                if(command.Kind=="APPEND_IMAGE" && !SQAssets.Ready(root,command.Text))throw new InvalidDataException("Uploaded image missing");
                string result=engine.Handle(f[1],incoming,true,f[3]=="1");
                transport.Send(stream,"SQWIRE5\n"+f[2]+"\n"+SQEngine.Encode(result));
                View(engine.Snapshot());Status("CONNECTED shared queue v5");
            }
        }
    }
    }
    void LocalWork(bool online) {
        using(SQAssets.Lock(root)) {
        if(role=="sender" && lastView=="") {
            string[] initial=Exchange(PollCommand(),false).Split('\n');
            if(initial.Length!=4 || initial[2]!="STATE")throw new InvalidDataException("Initial shared state");
            View(SQEngine.Decode(initial[3]));
        }
        string path=Directory.GetFiles(Path.Combine(root,"shared-requests"),"*.req").OrderBy(p=>p,StringComparer.Ordinal).FirstOrDefault();
        string command=path==null?PollCommand():File.ReadAllText(path,Encoding.UTF8);
        SQCommand parsed;
        try { parsed=SQCommand.Parse(command); }
        catch {
            if(path!=null) File.Move(path,Path.Combine(root,"shared-rejected",Path.GetFileName(path)+".invalid-"+Guid.NewGuid().ToString("N")));
            throw;
        }
        // Deadline is evaluated on the originating PC, never against the peer's clock.
        bool expired=parsed.Deadline>0 && DateTimeOffset.UtcNow.ToUnixTimeSeconds()>parsed.Deadline;
        if(!expired) {
            try {PrepareImage(parsed);}
            catch(InvalidDataException e) {
                if(path==null || e.Message=="VERSION_MISMATCH" || e.Message=="Image transfer response")throw;
                string code=parsed.Kind=="APPEND_IMAGE"?"INVALID_IMAGE":"IMAGE_UNAVAILABLE";
                File.Copy(path,Path.Combine(root,"shared-rejected",Path.GetFileName(path)),true);
                SuinQueueBridge.AtomicWrite(Path.Combine(root,"shared-results",Path.GetFileNameWithoutExtension(path)+".res"),"SQRES5\n"+parsed.Sequence+"\n"+code+"\n"+SQEngine.Encode(lastView));
                File.Delete(path);return;
            }
        }
        string reply=role=="receiver"?engine.Handle(node,command,online,expired):Exchange(command,expired);
        string[] fields=reply.Split('\n');
        if(fields.Length!=4 || fields[0]!="SQRES5" || fields[1]!=parsed.Sequence.ToString()) throw new InvalidDataException("Invalid shared reply");
        if(fields[2]!="UNCHANGED") View(SQEngine.Decode(fields[3]));
        if(role=="sender") Status("CONNECTED shared queue v5");
        if(path!=null && fields[2]!="WAIT_COPY") {
            if((parsed.Kind=="APPEND" || parsed.Kind=="APPEND_IMAGE") && fields[2]!="OK")
                File.Copy(path,Path.Combine(root,"shared-rejected",Path.GetFileName(path)),true);
            SuinQueueBridge.AtomicWrite(Path.Combine(root,"shared-results",Path.GetFileNameWithoutExtension(path)+".res"),reply);
            File.Delete(path);
        }
    }
    }
    public void Run() {
        TcpListener listener=null;
        if(role=="receiver") {
            listener=new TcpListener(IPAddress.Parse(bind),port);listener.Start(4);
            View(engine.Snapshot());Status("LISTENING shared queue v5");
        }
        try {
            while(alive()) {
                try {
                    // Only signed discovery in the client may update this file.
                    // Refresh between requests; never replay or restart an output.
                    string hostFile=Path.Combine(root,"peer-host.txt");
                    if(role=="sender" && File.Exists(hostFile)) {
                        string next=File.ReadAllText(hostFile).Trim();IPAddress parsed;
                        if(IPAddress.TryParse(next,out parsed) && parsed.AddressFamily==AddressFamily.InterNetwork)host=next;
                    }
                    if(listener!=null) {
                        if(listener.Pending()) Accept(listener);
                        bool online=(DateTime.UtcNow-lastPeer).TotalSeconds<3;
                        LocalWork(online);
                        if(!online && !lastStatus.StartsWith("VERSION_MISMATCH")) Status("WAIT_PEER shared queue v5");
                    } else if(String.IsNullOrWhiteSpace(host)) Status("NOT_CONFIGURED: set PeerHost");
                    else LocalWork(true);
                } catch(System.Security.Cryptography.CryptographicException) {Status("AUTH_FAILED: pairing key mismatch");}
                catch(EndOfStreamException) {Status("VERSION_OR_CONNECTION: update peer to v2.3 / check connection");}
                catch(InvalidDataException e) {Status("PROTOCOL_ERROR: "+e.Message);}
                catch(Exception e) {Status(e.Message.StartsWith("IMAGE_CACHE_FULL")?e.Message:"RETRY: "+e.GetType().Name);}
                Thread.Sleep(80);
            }
        } finally {if(listener!=null) listener.Stop();}
    }
}

public static class SQAssets {
    static readonly Dictionary<string,long> verified=new Dictionary<string,long>();
    public static IDisposable Lock(string root) { string dir=Path.Combine(root,"images");Directory.CreateDirectory(dir);return new FileStream(Path.Combine(dir,"store.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None); }
    public const int MaxImage=32*1024*1024, Chunk=256*1024;
    public static bool ValidReference(string reference) {
        if(reference==null || !System.Text.RegularExpressions.Regex.IsMatch(reference,"\\A[0-9a-f]{64}:[0-9]{1,9}\\z"))return false;
        long n;return Int64.TryParse(reference.Split(':')[1],out n) && n>=16 && n<=MaxImage;
    }
    public static long ReferenceSize(string reference){if(!ValidReference(reference))throw new InvalidDataException("Image reference");return Int64.Parse(reference.Split(':')[1]);}
    public static string Hash(byte[] data){using(var sha=System.Security.Cryptography.SHA256.Create())return BitConverter.ToString(sha.ComputeHash(data)).Replace("-","").ToLowerInvariant();}
    public static string PathFor(string root,string reference){if(!ValidReference(reference))throw new InvalidDataException("Image reference");return Path.Combine(root,"images",reference.Split(':')[0]+".img");}
    public static void Validate(byte[] data) {
        if(data.Length<16 || data.Length>MaxImage || BitConverter.ToUInt32(data,0)!=0x344D4953)throw new InvalidDataException("Image container");
        int count=BitConverter.ToInt32(data,4),offset=8;var seen=new HashSet<int>();
        if(count<1 || count>3)throw new InvalidDataException("Image format count");
        for(int i=0;i<count;i++) {
            if(offset+8>data.Length)throw new InvalidDataException("Image header truncated");
            int format=BitConverter.ToInt32(data,offset),size=BitConverter.ToInt32(data,offset+4);offset+=8;
            if(!seen.Add(format) || (format!=0 && format!=8 && format!=17) || size<8 || size>data.Length-offset)throw new InvalidDataException("Image payload length/format");
            if(format==0) {
                byte[] png={137,80,78,71,13,10,26,10};
                if(size<24 || !data.Skip(offset).Take(8).SequenceEqual(png))throw new InvalidDataException("PNG header");
            } else {
                if(size<40)throw new InvalidDataException("DIB header");
                uint header=BitConverter.ToUInt32(data,offset);
                long width=BitConverter.ToInt32(data,offset+4),height=BitConverter.ToInt32(data,offset+8);
                int bits=BitConverter.ToUInt16(data,offset+14);uint compression=BitConverter.ToUInt32(data,offset+16);
                if(header<40 || header>size || width<1 || width>32768 || height==0 || Math.Abs(height)>32768 || width*Math.Abs(height)>150000000
                    || !new[]{1,4,8,16,24,32}.Contains(bits) || (compression!=0 && compression!=3 && compression!=6))throw new InvalidDataException("DIB dimensions/encoding");
                long row=((width*bits+31)/32)*4;
                if(header+row*Math.Abs(height)>size)throw new InvalidDataException("DIB pixels truncated");
            }
            offset+=size;
        }
        if(offset!=data.Length)throw new InvalidDataException("Image trailing data");
    }
    public static bool Ready(string root,string reference) {
        string path=PathFor(root,reference);if(!File.Exists(path))return false;
        var info=new FileInfo(path);long stamp=info.LastWriteTimeUtc.Ticks^info.Length;
        lock(verified){long prior;if(verified.TryGetValue(path,out prior) && prior==stamp)return true;}
        byte[] data=File.ReadAllBytes(path);
        try {
            if(data.LongLength!=ReferenceSize(reference) || Hash(data)!=reference.Split(':')[0])throw new InvalidDataException("Image checksum");
            Validate(data);
        } catch(InvalidDataException) {File.Move(path,path+".bad-"+Guid.NewGuid().ToString("N"));return false;}
        lock(verified)verified[path]=stamp;return true;
    }
    static void Space(string root,long extra) {
        string dir=Path.Combine(root,"images");Directory.CreateDirectory(dir);
        if(Directory.GetFiles(dir).Sum(p=>new FileInfo(p).Length)+extra>256L*1024*1024)throw new IOException("IMAGE_CACHE_FULL: clean unused image cache");
    }
    public static void Put(string root,string reference,int offset,byte[] chunk) {
        string path=PathFor(root,reference);long total=ReferenceSize(reference);
        if(offset<0 || offset%Chunk!=0 || chunk.Length<1 || chunk.Length>Chunk || (long)offset+chunk.Length>total)throw new InvalidDataException("Image chunk bounds");
        if(Ready(root,reference))return;
        string part=path+".part";
        if(!File.Exists(part))Space(root,total);
        else Space(root,Math.Max(0,(long)offset+chunk.Length-new FileInfo(part).Length));
        using(var file=new FileStream(part,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)) {
            if(file.Length<offset)throw new InvalidDataException("Image chunk gap");
            if(file.Length>offset){file.Position=offset;byte[] prior=new byte[chunk.Length];int read=file.Read(prior,0,prior.Length);if(read==chunk.Length && prior.SequenceEqual(chunk) && offset+chunk.Length!=total)return;file.SetLength(offset);}
            file.Position=offset;file.Write(chunk,0,chunk.Length);file.Flush(true);
        }
        if(new FileInfo(part).Length==total) {
            byte[] data=File.ReadAllBytes(part);
            if(Hash(data)!=reference.Split(':')[0]){File.Delete(part);throw new InvalidDataException("Image checksum");}
            Validate(data);File.Move(part,path);
        }
    }
    public static byte[] Get(string root,string reference,int offset) {
        string path=PathFor(root,reference);long total=ReferenceSize(reference);
        if(offset<0 || offset%Chunk!=0 || offset>=total || !Ready(root,reference))throw new InvalidDataException("Image unavailable/range");
        using(var f=File.OpenRead(path)){f.Position=offset;byte[] b=new byte[Math.Min(Chunk,(int)(total-offset))];if(f.Read(b,0,b.Length)!=b.Length)throw new EndOfStreamException();return b;}
    }
}
