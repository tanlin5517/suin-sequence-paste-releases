﻿// Windows PowerShell 5.1 / .NET Framework compatible. No third-party dependencies.
// Wire format: bounded length prefix, random IV, AES-256-CBC ciphertext, HMAC-SHA256.
// The authenticated digest covers IV + ciphertext; decrypt only after authentication.
using System;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Threading;
using System.Security.Cryptography;
using System.Collections.Generic;

public sealed class SuinQueueBridge {
    const int MaxFrame = 8 * 1024 * 1024;
    static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
    readonly string root, role, host, bind;
    readonly int port, parent;
    readonly long parentTicks;
    readonly byte[] encKey, macKey;
    readonly Dictionary<string, long> seen = new Dictionary<string, long>();
    string lastStatus = "";
    public SuinQueueBridge(string stateDir, string role, string host, string bind, int port, string secret, int parent) {
        if (secret == null || !System.Text.RegularExpressions.Regex.IsMatch(secret, "\\A[0-9a-fA-F]{64}\\z"))
            throw new ArgumentException("SharedKey must contain 64 hexadecimal characters");
        if (port < 1024 || port > 65535) throw new ArgumentException("Invalid port");
        this.root = stateDir; this.role = role; this.host = host; this.bind = bind;
        this.port = port; this.parent = parent;
        this.parentTicks = parent > 0 ? Process.GetProcessById(parent).StartTime.ToUniversalTime().Ticks : 0;
        using (var sha = SHA256.Create()) {
            encKey = sha.ComputeHash(Utf8.GetBytes(secret.ToLowerInvariant() + "/SuinQueue/encryption/v1"));
            macKey = sha.ComputeHash(Utf8.GetBytes(secret.ToLowerInvariant() + "/SuinQueue/authentication/v1"));
        }
        Directory.CreateDirectory(root);
    }
    bool Alive() {
        if (parent <= 0) return true;
        try { using (var p = Process.GetProcessById(parent)) {
            return !p.HasExited && p.StartTime.ToUniversalTime().Ticks == parentTicks;
        }} catch { return false; }
    }
    public static void AtomicWrite(string path, string value) {
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try {
            File.WriteAllText(temp, value, Utf8);
            if (File.Exists(path)) File.Replace(temp, path, null);
            else File.Move(temp, path);
        } finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    void Status(string message) {
        if (message == lastStatus) return;
        AtomicWrite(Path.Combine(root, "bridge-status.txt"), message);
        lastStatus = message;
    }
    string ReadOptional(string name) {
        try { return File.ReadAllText(Path.Combine(root, name), Utf8); }
        catch (IOException) { return ""; }
    }
    static byte[] ReadExact(Stream stream, int count) {
        byte[] result = new byte[count]; int offset = 0;
        while (offset < count) {
            int n = stream.Read(result, offset, count - offset);
            if (n == 0) throw new EndOfStreamException();
            offset += n;
        }
        return result;
    }
    public byte[] Protect(string text) {
        byte[] iv = new byte[16], encrypted;
        using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(iv);
        using (var aes = Aes.Create()) {
            aes.Key = encKey; aes.IV = iv; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
            using (var transform = aes.CreateEncryptor()) {
                byte[] plain = Utf8.GetBytes(text);
                encrypted = transform.TransformFinalBlock(plain, 0, plain.Length);
            }
        }
        byte[] result = new byte[16 + encrypted.Length + 32];
        Buffer.BlockCopy(iv, 0, result, 0, 16);
        Buffer.BlockCopy(encrypted, 0, result, 16, encrypted.Length);
        using (var hmac = new HMACSHA256(macKey)) {
            byte[] tag = hmac.ComputeHash(result, 0, result.Length - 32);
            Buffer.BlockCopy(tag, 0, result, result.Length - 32, 32);
        }
        return result;
    }
    public string Unprotect(byte[] data) {
        if (data.Length < 64 || data.Length > MaxFrame || (data.Length - 48) % 16 != 0)
            throw new InvalidDataException("Invalid encrypted frame");
        int mismatch = 0;
        using (var hmac = new HMACSHA256(macKey)) {
            byte[] expected = hmac.ComputeHash(data, 0, data.Length - 32);
            for (int i = 0; i < 32; i++) mismatch |= expected[i] ^ data[data.Length - 32 + i];
        }
        if (mismatch != 0) throw new CryptographicException("Authentication failed");
        byte[] iv = new byte[16]; Buffer.BlockCopy(data, 0, iv, 0, 16);
        using (var aes = Aes.Create()) {
            aes.Key = encKey; aes.IV = iv; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
            using (var transform = aes.CreateDecryptor())
                return Utf8.GetString(transform.TransformFinalBlock(data, 16, data.Length - 48));
        }
    }
    public void Send(Stream stream, string text) {
        byte[] data = Protect(text);
        if (data.Length > MaxFrame) throw new InvalidDataException("Frame too large");
        byte[] size = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(data.Length));
        stream.Write(size, 0, size.Length); stream.Write(data, 0, data.Length); stream.Flush();
    }
    public string Receive(Stream stream) {
        int count = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(ReadExact(stream, 4), 0));
        if (count < 64 || count > MaxFrame) throw new InvalidDataException("Frame too large or invalid");
        return Unprotect(ReadExact(stream, count));
    }
    public static string[] Validate(string snapshot) {
        if (snapshot.Length > 4000000) throw new InvalidDataException("Queue too large");
        string[] f = snapshot.TrimEnd('\r', '\n').Replace("\r", "").Split('\n');
        long rev; int count; Guid parsed;
        if (f.Length < 6 || f[0] != "SPQ1" || !Guid.TryParse(f[1], out parsed)
            || !long.TryParse(f[2], out rev) || rev < 1 || !Guid.TryParse(f[3], out parsed)
            || (f[4] != "SET" && f[4] != "CLEAR") || !int.TryParse(f[5], out count)
            || count < 0 || count > 500 || f.Length != count + 6 || (f[4] == "CLEAR" && count != 0))
            throw new InvalidDataException("Invalid queue header");
        int total = 0;
        for (int i = 6; i < f.Length; i++) {
            string text = Utf8.GetString(Convert.FromBase64String(f[i]));
            total += text.Length;
            if (text.Length == 0 || text.Length > 100000 || text.IndexOf('\0') >= 0 || total > 500000)
                throw new InvalidDataException("Invalid queue text");
        }
        return f;
    }
    public static string Digest(string value) {
        using (var sha = SHA256.Create()) return Convert.ToBase64String(sha.ComputeHash(Utf8.GetBytes(value)));
    }
    public void Run(int timeoutSeconds = 300) {
        new SuinSharedBridge(root, role, host, bind, port, this, Alive, timeoutSeconds).Run();
    }
}