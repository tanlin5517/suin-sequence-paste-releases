﻿#Requires AutoHotkey v2.0
#Include %A_LineFile%\..\SharedQueue.ahk
#Include %A_LineFile%\..\ClipboardRouting.ahk
#Include %A_LineFile%\..\ImageClipboard.ahk
#Include %A_LineFile%\..\SettingsCenter.ahk
#Include %A_LineFile%\..\InputDispatch.ahk
global SP_TestMode := IsSet(SP_TestMode) ? SP_TestMode : false
if !SP_TestMode
    SP.Init()
#HotIf !SP_TestMode && SP.ResetUndo && !SP.IsSettingsActive()
~^z::SP.Reset("撤销操作", true)
#HotIf !SP_TestMode && !SP.IsSettingsActive()
~Esc::SP.EscapePressed()
#HotIf !SP_TestMode
~#v::SP.HistoryBypass := true
#HotIf
class SP {
    static Enabled := true, Busy := false, Queue := [], Index := 1
    static Session := "", Batch := "", Revision := 0, AppliedRevision := 0
    static RemoteSession := "", RemoteBatch := "", LastInbox := ""
    static Role := "local", Mode := "Clipboard", TimeoutMs := 300000
    static NumericTypingMaxDigits := 20
    static StateDir := "", ConfigPath := "", BridgePid := 0, BridgeHandle := 0, HistoryBypass := false
    static LastError := "", PendingSnapshot := "", KeysRegistered := false
    static LastOutput := 0, Panel := 0, Shared := false
    static NativeSequence := -1, ClipboardDirty := false
    static ImageIndexes := Map(), LastImageSequence := -1, LastImageReference := "", FailedImageSequence := -1
    static CaptureCopy := true, CaptureCut := true, CaptureImages := true, FormattedText := false
    static QueuePaste := true, ResetEsc := true, ResetUndo := true, AutoNumber := true, TypeDelay := 15
    static StopTyping := false, ExpectedTypingTarget := 0
    static TypingMethod := 0, LastInput := 0, InputTestWindow := 0
    static BatchContinue := false, AutoAdvance := true, SettingsWindow := 0
    static ClipboardTimer := (*) => SP.ObserveClipboard()
    static ExpireCallback := () => SP.Expire(), TipCallback := () => SP.HideTip()
    static Init() {
        this.ConfigPath := EnvGet("SUIN_SEQUENCE_CONFIG") != "" ? EnvGet("SUIN_SEQUENCE_CONFIG") : A_ScriptDir "\SequencePaste.ini"
        this.Role := StrLower(IniRead(this.ConfigPath, "Sequence", "Role", "local"))
        if !InStr("|local|sender|receiver|", "|" this.Role "|")
            throw Error("Role 只能是 local、sender 或 receiver")
        this.Shared := this.Role != "local"
        ; Only short scalar numbers type automatically; legacy Text mode is ignored.
        this.Mode := "Clipboard"
        this.NumericTypingMaxDigits := Integer(IniRead(this.ConfigPath, "Sequence", "NumericTypingMaxDigits", "20"))
        if this.NumericTypingMaxDigits < 0 || this.NumericTypingMaxDigits > 1000
            throw Error("NumericTypingMaxDigits 必须在 0～1000 之间；0 表示关闭自动数字输入")
        this.TimeoutMs := Max(0, Integer(IniRead(this.ConfigPath, "Sequence", "TimeoutSeconds", "300"))) * 1000
        SPPreferences.Load(this)
        this.Session := this.Guid()
        if !SP_TestMode
            this.RegisterKeys()
        stateId := RegExReplace(A_ScriptDir, "[^a-zA-Z0-9]", "_")
        this.StateDir := EnvGet("LOCALAPPDATA") "\SuinSequencePaste\" SubStr(stateId, -150)
        if EnvGet("SUIN_SEQUENCE_STATE") != ""
            this.StateDir := EnvGet("SUIN_SEQUENCE_STATE")
        DirCreate(this.StateDir)
        for name in ["outbox.txt", "peer-receipt.txt", "bridge-status.txt", "bridge-error.txt"] {
            try FileDelete(this.StateDir "\" name)
        }
        if this.Shared
            SQ.Init(this)
        else if this.Role = "receiver"
            this.RestoreReceiver()
        OnExit(ObjBindMethod(this, "Shutdown"))
        if !SP_TestMode
            OnClipboardChange(ObjBindMethod(this, "ClipboardChanged"))
        if this.Role != "local" {
            secret := IniRead(this.ConfigPath, "Network", "SharedKey", "")
            if !RegExMatch(secret, "i)^[0-9a-f]{64}$")
                throw Error("SharedKey 无效，请先运行配置双机.cmd")
            this.StartBridge()
            SetTimer(ObjBindMethod(this, "Poll"), 200)
        }
        A_TrayMenu.Add()
        A_TrayMenu.Add("顺序粘贴：查看状态", ObjBindMethod(this, "ShowStatus"))
        A_TrayMenu.Add("设置中心", (*) => SP.OpenSettings())
        A_TrayMenu.Add("输入自检（Ctrl+Alt+F12）", (*) => SP.OpenInputTest())
        A_TrayMenu.Add("将当前截图 / 图片加入队列（Ctrl+Alt+C）", (*) => SP.AddCurrentImage())
        A_TrayMenu.Add("清理闲置图片缓存", (*) => SP.CleanImages())
        A_TrayMenu.Add(this.Shared ? "顺序粘贴：两端统一开关" : "顺序粘贴：开关", ObjBindMethod(this, "Toggle"))
        if this.Shared
            A_TrayMenu.Add("共享队列：确认未完成的粘贴…", ObjBindMethod(SQ, "Resolve"))
        A_TrayMenu.Add("顺序粘贴：从头重贴", ObjBindMethod(this, "Rewind"))
        A_TrayMenu.Add("顺序粘贴：显示 / 隐藏队列浮窗", ObjBindMethod(this, "TogglePanel"))
        A_TrayMenu.Add("顺序粘贴：浮窗外观", (*) => SP.OpenSettings(4))
        if !SP_TestMode
            this.Panel := SPPanel(this)
        if EnvGet("SUIN_SEQUENCE_PARENT") != ""
            SetTimer(ObjBindMethod(this, "ClientCommand"), 300)
        this.Tip("顺序粘贴就绪：" (this.Shared ? "双向共享队列" : this.Role) " / Ctrl+Alt+I 查看状态")
    }
    static ClientCommand() {
        parent := EnvGet("SUIN_SEQUENCE_PARENT")
        if parent != "" && !ProcessExist(Integer(parent)) {
            if !this.Busy
                ExitApp()
            return
        }
        path := this.StateDir "\client-command.txt"
        if !FileExist(path) || this.Busy
            return
        try command := Trim(FileRead(path, "UTF-8"))
        catch
            return
        try FileDelete(path)
        try {
            if command = "exit" {
                this.AtomicWrite(this.StateDir "\client-receipt.txt", "exit:OK")
                ExitApp()
            } else if command = "settings"
                this.OpenSettings()
            else if command = "input"
                this.OpenInputTest()
            else if command = "panel"
                this.TogglePanel()
            else if command = "close-panels" {
                if IsObject(this.SettingsWindow)
                    this.SettingsWindow.Close()
                if IsObject(this.InputTestWindow)
                    this.InputTestWindow.Close()
            }
            else
                throw Error("未知的客户端操作")
            receipt := command ":OK"
            if command = "settings"
                receipt .= ":visible=" DllCall("IsWindowVisible", "ptr", this.SettingsWindow.Gui.Hwnd, "int")
            if command = "input"
                receipt .= ":visible=" DllCall("IsWindowVisible", "ptr", this.InputTestWindow.Gui.Hwnd, "int")
            this.AtomicWrite(this.StateDir "\client-receipt.txt", receipt)
        } catch as err {
            this.AtomicWrite(this.StateDir "\client-receipt.txt", command ":ERROR:" err.Message)
        }
    }
    static Guid() {
        guid := Buffer(16), chars := Buffer(78)
        DllCall("ole32\CoCreateGuid", "ptr", guid)
        DllCall("ole32\StringFromGUID2", "ptr", guid, "ptr", chars, "int", 39)
        return StrGet(chars)
    }
    static RegisterKeys() {
        ; RegisterHotKey variants have no $ / #HotIf: MWB's low-level routing runs first.
        ; This avoids source-side interception while the keyboard controls the other PC.
        HotIf()
        Hotkey("^c", (*) => SP.Copy())
        Hotkey("^x", (*) => SP.Cut())
        Hotkey("^v", (*) => SP.Paste())
        Hotkey("^+v", (*) => SP.Type())
        Hotkey("^!v", (*) => SP.NativePaste())
        Hotkey("^!s", (*) => SP.Toggle())
        Hotkey("^!c", (*) => SP.AddCurrentImage())
        Hotkey("^!z", (*) => SP.Reset("手动清空", true))
        Hotkey("^!i", (*) => SP.ShowStatus())
        Hotkey("^!r", (*) => SP.Rewind())
        try Hotkey("^!F12", (*) => SP.OpenInputTest())
        catch
            this.Tip("输入自检快捷键被占用；可从托盘或设置中心打开。")
        this.KeysRegistered := true
    }
    static SendNative(key) {
        ; Temporarily unregister only our own shortcut while sending its native action.
        if this.KeysRegistered
            Hotkey("^" key, "Off")
        ; MWB forwards logical Ctrl without a local physical key-down. Normal Send
        ; may release it after the first shortcut. Blind preserves the held Ctrl;
        ; exclude Alt/Shift/Win so Ctrl+Alt+V still forwards an ordinary Ctrl+V.
        try SendEvent("{Blind!+#}^" key)
        finally {
            if this.KeysRegistered
                Hotkey("^" key, "On")
        }
    }
    static Tip(text, duration := 1800) {
        if SP_TestMode
            return
        ToolTip(text, , , 12)
        SetTimer(SP.TipCallback, -duration)
    }
    static HideTip() => ToolTip(, , , 12)
    static Touch() {
        if this.Shared
            return ; shared inactivity is measured by the coordinator
        if this.TimeoutMs > 0
            SetTimer(SP.ExpireCallback, -this.TimeoutMs)
    }
    static Expire() {
        if SP.Busy
            SetTimer(SP.ExpireCallback, -250)
        else
            SP.Reset("闲置超时", false)
    }
    static Reset(reason := "重置", publish := false) {
        if this.Shared
            return publish ? SQ.Control("CLEAR") : false
        if this.Busy
            return
        hadItems := this.Queue.Length > 0
        this.Queue := [], this.Index := 1, this.HistoryBypass := false, this.LastOutput := 0
        this.ImageIndexes := Map()
        SetTimer(SP.ExpireCallback, 0)
        ; Source inactivity must not clear a receiver which is still being used.
        if publish && this.Role = "sender" {
            this.Batch := this.Guid()
            this.Publish("CLEAR")
        } else if this.Role = "sender" {
            this.PendingSnapshot := ""
            try FileDelete(this.StateDir "\outbox.txt")
        }
        this.WriteReceipt("cleared")
        if this.Role = "receiver"
            this.EraseInbox()
        if hadItems
            this.Tip("队列已清空：" reason)
    }
    static Toggle(*) {
        if this.Busy
            return
        if this.Shared
            return SQ.SetEnabled()
        this.Enabled := !this.Enabled
        if !this.Enabled && !this.Shared
            this.Reset("已关闭", true)
        this.WriteReceipt(this.Enabled ? "ready" : "disabled")
        this.Tip(this.Enabled ? "顺序粘贴：开启" : "顺序粘贴：关闭")
    }
    static Rewind(*) {
        if this.Shared
            return this.Enabled ? SQ.Control("REWIND") : false
        if !this.Enabled || this.Busy || this.Queue.Length = 0
            return
        this.Index := 1
        this.Touch(), this.WriteReceipt()
        this.Tip("已回到第一条，共 " this.Queue.Length " 条")
    }
    static CurrentBatchKey() => this.Shared ? SQ.Epoch "|" this.Batch : this.Role = "receiver"
        ? this.RemoteSession "|" this.RemoteBatch : this.Session "|" this.Batch
    static RecordOutput(text, typed, itemIndex, image := false) {
        if text != ""
            this.LastOutput := {Text: text, Typed: typed, Image:image, ItemIndex: itemIndex, BatchKey: this.CurrentBatchKey()}
    }
    static CanReplay() => this.Enabled && !this.Busy && IsObject(this.LastOutput)
        && this.LastOutput.BatchKey = this.CurrentBatchKey()
    static ProgressState() => this.Index > this.Queue.Length ? "finished" : "ready"
    static BackOne(*) {
        if this.Shared
            return this.Enabled ? SQ.Control("BACK") : false
        if !this.Enabled || this.Busy || this.Queue.Length = 0 || this.Index <= 1
            return false
        this.Index--
        this.Touch(), this.WriteReceipt(this.ProgressState())
        this.Tip("已回退，下一条为第 " this.Index " 条；请自行处理目标框中的旧内容")
        return true
    }
    static SkipOne(*) {
        if this.Shared
            return this.Enabled ? SQ.Control("SKIP") : false
        if this.Busy || !this.HasPending()
            return false
        skipped := this.Index
        this.Index++
        this.Touch(), this.WriteReceipt(this.ProgressState())
        this.Tip("已跳过第 " skipped " 条" (this.Index > this.Queue.Length ? "，本批处理完成" : ""))
        return true
    }
    static ReplayLast(*) {
        if this.Shared
            return this.Enabled ? SQ.Output("replay") : false
        if !this.CanReplay()
            return false
        this.Busy := true
        try {
            savedOutput := this.LastOutput
            if savedOutput.HasOwnProp("Image") && savedOutput.Image {
                this.StageImage(this.PrepareImage(savedOutput.Text))
                this.SendImagePaste(savedOutput.Text)
            } else if savedOutput.Typed {
                this.AutoTypeNumber(savedOutput.Text)
            } else {
                this.ClipboardPaste(savedOutput.Text)
            }
            ; Replay never advances or rewinds the current queue pointer.
            this.Touch(), this.WriteReceipt(this.ProgressState())
            this.Tip("已重贴上次实际输出的第 " savedOutput.ItemIndex " 条，当前进度不变")
            return true
        } catch as err {
            this.LastError := err.Message
            this.Tip("重贴未确认完成，请检查目标内容：" err.Message, 5000)
            return false
        } finally {
            this.Busy := false
        }
    }
    static NewBatch(*) {
        if this.Shared
            return SQ.Control("CLEAR")
        if this.Busy
            return false
        this.Reset("开始新批次", true)
        this.Tip(this.Role = "receiver" ? "已清空本机接收队列，等待发送端的新批次"
            : "已开始新批次，请连续复制新内容")
        return true
    }
    static TogglePanel(*) {
        if IsObject(this.Panel)
            this.Panel.Toggle()
    }
    static Cut() => this.Copy("x")
    static Copy(key := "c") {
        if !this.Enabled || this.IsSettingsActive() || (this.Role = "receiver" && !this.Shared) {
            this.SendNative(key)
            return
        }
        if this.Busy {
            this.SendNative(key)
            return
        }
        this.Busy := true
        try {
            beforeSeq := this.ClipSequence()
            this.SendNative(key)
            started := A_TickCount
            while this.ClipSequence() = beforeSeq && A_TickCount - started < 1500
                Sleep(10)
            if this.ClipSequence() = beforeSeq {
                this.Tip(key="x"?"未检测到剪切结果，未入队；不会重复剪切":"未检测到新复制，剪贴板保持原样")
                return
            }
            info := this.ClipboardInfo()
            if (key="c" ? !this.CaptureCopy : !this.CaptureCut) {
                this.MarkNative(info)
                this.Tip("本次按普通" (key="x"?"剪切":"复制") "处理；旧队列暂停")
                return
            }
            if info.Kind = "image" {
                if this.CaptureImages
                    this.QueueCurrentImage()
                else
                    this.MarkNative(info)
                return
            }
            if info.Kind != "text" && info.Kind != "queue" && !(this.FormattedText && (info.Kind="rich" || info.Kind="table")) {
                this.MarkNative(info)
                this.Tip("已保留原始格式，Ctrl+V 普通粘贴；旧文本队列暂停")
                return
            }
            original := this.ReadClipboardText(), text := FBACleaner_CleanText(original)
            if text = ""
                return
            if this.Shared {
                if text != original
                    this.SetClipboardText(text)
                SQ.CopyText(text)
                return
            }
            newBatch := !this.BatchContinue && (this.Index > 1 || (!this.AutoAdvance && IsObject(this.LastOutput)) || this.RemoteHasStarted()) || this.Queue.Length = 0
            total := StrLen(text)
            if !newBatch {
                for item in this.Queue
                    total += StrLen(item)
            }
            if StrLen(text) > 100000 || total > 500000 || (!newBatch && this.Queue.Length >= 500)
                throw Error("超过限制：每条 10 万字符、每批 50 万字符 / 500 条")
            if text != original
                this.SetClipboardText(text)
            if newBatch
                this.Queue := [], this.Index := 1, this.Batch := this.Guid(), this.LastOutput := 0
            if newBatch
                this.ImageIndexes := Map()
            this.Queue.Push(text)
            this.Touch()
            if this.Role = "sender"
                this.Publish()
            this.Tip("已入队 " this.Queue.Length " 条：" SubStr(StrReplace(text, "`n", " "), 1, 25))
        } catch as err {
            this.LastError := err.Message
            if IsSet(info) && info.Kind = "image"
                this.FailedImageSequence := this.ClipSequence()
            this.Tip((key="x" ? "剪切已执行一次，未入队：" : "复制未入队：") err.Message, 4000)
        } finally {
            this.Busy := false
        }
    }
    static RemoteHasStarted() {
        if this.Role != "sender" || this.Batch = "" || this.StateDir = ""
            return false
        try {
            f := StrSplit(Trim(FileRead(this.StateDir "\peer-receipt.txt", "UTF-8"), "`r`n"), "`n", "`r")
            return f.Length >= 7 && f[1] = "SPRECEIPT1" && f[2] = this.Session
                && f[3] = this.Batch && (Integer(f[5]) > 1 || f[7] = "cleared" || f[7] = "disabled")
        }
        return false
    }
    static AdvancesAutomatically() => this.Shared ? SQ.AutoAdvance : this.AutoAdvance
    static HasPending() => this.Enabled && (!this.Shared || !SQ.NativeMode) && this.Queue.Length > 0 && this.Index <= this.Queue.Length
    static ShouldSequence() => this.HasPending() && this.Queue.Length >= 2
    static IsShortNumber(text) {
        ; Match the ENTIRE single-line value; never parse to a machine number or trim it.
        ; Count digits only; preserve signs, decimal point, commas and leading/trailing zeros.
        if !this.AutoNumber || this.NumericTypingMaxDigits = 0
            return false
        if !RegExMatch(text, "\A[+-]?(?:(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?|\.[0-9]+)\z")
            return false
        return StrLen(RegExReplace(text, "[^0-9]")) <= this.NumericTypingMaxDigits
    }
    static AutoTypeNumber(text) {
        this.StopTyping := false
        prior := this.ExpectedTypingTarget
        if !IsObject(prior) && !SP_TestMode
            this.ExpectedTypingTarget := SPInput.Capture()
        try {
            this.WaitTypingKeys()
            this.EmitText(text)
        } finally this.ExpectedTypingTarget := prior
    }
    static Paste() {
        if this.Busy
            return
        if !this.QueuePaste || this.IsSettingsActive() {
            this.HistoryBypass := false
            this.NativePaste()
            return
        }
        if this.HistoryBypass {
            this.HistoryBypass := false
            this.NativePaste()
            return
        }
        if !this.Shared && this.Enabled && this.PreferNativeClipboard() {
            this.NativePaste()
            return
        }
        if this.Shared && this.Enabled
            return SQ.Output("paste")
        if !this.ShouldSequence() {
            if this.HasPending() && this.IsImage(this.Index)
                return this.PasteLocalImage()
            this.Busy := true
            try {
                text := this.Enabled ? this.ReadClipboardText() : ""
                typed := this.Enabled && this.IsShortNumber(text)
                if typed
                    this.AutoTypeNumber(text)
                else
                    this.NativePaste()
                ; End an ordinary copy/paste without letting a receive timer change its batch.
                if this.HasPending() && this.Queue.Length = 1 {
                    this.RecordOutput(text, typed, 1)
                    if this.AutoAdvance
                        this.Index := 2
                    this.Touch(), this.WriteReceipt("finished")
                }
            } catch as err {
                this.LastError := err.Message
                this.Tip("普通粘贴未确认完成：" err.Message, 4000)
            } finally {
                this.Busy := false
            }
            return
        }
        this.Busy := true
        try {
            text := this.Queue[this.Index]
            if text = ""
                return
            image := this.IsImage(this.Index), typed := !image && this.IsShortNumber(text)
            if image {
                this.StageImage(this.PrepareImage(text))
                this.SendImagePaste(text)
            } else if typed
                this.AutoTypeNumber(text)
            else
                this.ClipboardPaste(text)
            this.RecordOutput(text, typed, this.Index, image)
            if this.AutoAdvance
                this.Index++
            this.Touch()
            this.WriteReceipt(this.Index > this.Queue.Length ? "finished" : "ready")
            this.Tip("已发送第 " this.LastOutput.ItemIndex "/" this.Queue.Length " 条"
                (this.Index > this.Queue.Length ? "（队列完成）" : ""))
        } catch as err {
            this.LastError := err.Message
            this.Tip("进度未推进，请检查目标内容：" err.Message, 5000)
        } finally {
            this.Busy := false
        }
    }
    static ReadClipboardText() => A_Clipboard
    static SetClipboardText(text) => A_Clipboard := text
    static IsSettingsActive() => this.IsSettingsWindow(WinExist("A"))
    static WindowHandle(window) {
        ; Hotkey conditions also run during Gui.Destroy and timer callbacks.
        ; Capture once; a destroyed Gui can throw even though it is still an object.
        try {
            windowGui := window.Gui
            return windowGui is Gui ? windowGui.Hwnd : 0
        } catch
            return 0
    }
    static IsSettingsWindow(hwnd) => hwnd && (hwnd=this.WindowHandle(this.SettingsWindow) || hwnd=this.WindowHandle(this.InputTestWindow))
    static OpenSettings(page := 1) {
        if !IsObject(this.SettingsWindow)
            this.SettingsWindow := SPSettingsWindow(this)
        this.SettingsWindow.Show(page)
    }
    static IsImage(index) => this.ImageIndexes.Has(index)
    static PrepareImage(reference) => ImageClipboard.Read(this.StateDir, reference)
    static StageImage(data) => ImageClipboard.Publish(data)
    static SendImagePaste(reference) => this.NativePaste()
    static CurrentImage() {
        seq := this.ClipSequence()
        if seq = this.LastImageSequence && this.LastImageReference != "" && FileExist(ImageClipboard.Path(this.StateDir,this.LastImageReference))
            return {Reference:this.LastImageReference, Sequence:seq}
        captured := ImageClipboard.Capture(this.StateDir)
        this.LastImageSequence := captured.Sequence, this.LastImageReference := captured.Reference
        return captured
    }
    static QueueCurrentImage() {
        captured := this.CurrentImage()
        if this.Shared
            SQ.CopyImage(captured.Reference)
        else {
            if (!this.BatchContinue && (this.Index > 1 || (!this.AutoAdvance && IsObject(this.LastOutput)))) || this.Queue.Length = 0
                this.Queue := [], this.ImageIndexes := Map(), this.Index := 1, this.Batch := this.Guid(), this.LastOutput := 0
            if this.Queue.Length >= 500
                throw Error("队列条目已满")
            imageBytes := Integer(StrSplit(captured.Reference,":")[2])
            for index, item in this.Queue
                if this.IsImage(index)
                    imageBytes += Integer(StrSplit(item,":")[2])
            if this.ImageIndexes.Count >= 100 || imageBytes > 128 * 1024 * 1024
                throw Error("每批最多 100 张图片 / 128MB，请开始新批次")
            this.Queue.Push(captured.Reference), this.ImageIndexes[this.Queue.Length] := true
            this.Touch()
        }
        this.Tip("图片已采集，正在加入混合队列；同步变化不会重复入队")
        this.FailedImageSequence := -1
    }
    static AddCurrentImage(*) {
        if this.Busy
            return
        if !this.Enabled || !this.CaptureImages {
            this.Tip("请先开启顺序增强，再加入图片")
            return
        }
        this.Busy := true
        try {
            if this.ClipboardInfo().Kind != "image"
                throw Error("当前剪贴板不是图片；先截图并复制，再加入队列")
            this.QueueCurrentImage()
        } catch as err {
            this.LastError := err.Message
            this.FailedImageSequence := this.ClipSequence()
            this.Tip("图片未入队：" err.Message,5000)
        } finally this.Busy := false
    }
    static PasteLocalImage() {
        this.Busy := true
        try {
            text := this.Queue[this.Index]
            this.StageImage(this.PrepareImage(text)), this.SendImagePaste(text)
            this.RecordOutput(text,false,this.Index,true)
            if this.AutoAdvance
                this.Index++
            this.Touch()
        } catch as err {
            this.LastError := err.Message
            this.Tip("图片未发送：" err.Message,5000)
        } finally this.Busy := false
    }
    static CleanImages(*) {
        if this.Busy
            return
        DirCreate(this.StateDir "\images")
        gate := DllCall("CreateFileW","str",this.StateDir "\images\store.lock","uint",0xC0000000,"uint",0,"ptr",0,"uint",4,"uint",0x80,"ptr",0,"ptr")
        if gate = -1 {
            this.Tip("图片正在同步，请稍后清理")
            return
        }
        try {
        if this.Shared
            SQ.Poll()
        keep := Map(), deleted := 0
        for index, text in this.Queue
            if this.IsImage(index)
                keep[StrSplit(text,":")[1]] := true
        if IsObject(this.LastOutput) && this.LastOutput.HasOwnProp("Image") && this.LastOutput.Image
            keep[StrSplit(this.LastOutput.Text,":")[1]] := true
        if this.Shared && SQ.LeaseImage && SQ.LeaseText != ""
            keep[StrSplit(SQ.LeaseText,":")[1]] := true
        Loop Files this.StateDir "\shared-requests\*.req" {
            f := StrSplit(FileRead(A_LoopFileFullPath,"UTF-8"),"`n","`r")
            if f.Length = 10 && f[3] = "APPEND_IMAGE"
                keep[StrSplit(this.Decode(f[9]),":")[1]] := true
        }
        Loop Files this.StateDir "\images\*.img*" {
            if !keep.Has(SubStr(A_LoopFileName,1,64)) && DateDiff(A_Now,A_LoopFileTimeModified,"Seconds") > 600 {
                try FileDelete(A_LoopFileFullPath), deleted++
            }
        }
        this.Tip("已清理 " deleted " 份闲置图片；队列和待同步图片保留")
        } finally DllCall("CloseHandle","ptr",gate)
    }
    static ClipboardInfo() => SP_TestMode ? {Kind: "queue", Text: "", Sequence: -1} : ClipboardRouting.Inspect()
    static MarkNative(info) {
        if info.Sequence = -1 || info.Sequence = this.NativeSequence
            return false
        try {
            if this.Shared
                SQ.Submit("NATIVE")
            else
                this.Queue := [], this.Index := 1, this.LastOutput := 0
            this.NativeSequence := info.Sequence
            return true
        } catch as err {
            ; A notification failure must never block the native paste itself.
            this.LastError := "原格式优先状态尚未同步：" err.Message
            return false
        }
    }
    static ClipboardChanged(*) {
        this.ClipboardDirty := true
        SetTimer(this.ClipboardTimer, -80)
    }
    static ObserveClipboard() {
        if this.Busy {
            SetTimer(this.ClipboardTimer, -100)
            return
        }
        if !this.ClipboardDirty
            return
        try {
            info := this.ClipboardInfo()
            if info.Kind = "unknown" {
                SetTimer(this.ClipboardTimer, -150)
                return
            }
            ; Image changes from WeChat/MWB are NEVER capture triggers or native
            ; boundaries. Only Ctrl+C or the explicit screenshot action enqueues.
            if info.Kind != "text" && info.Kind != "queue" && info.Kind != "image" && !(this.FormattedText && (info.Kind="rich" || info.Kind="table"))
                this.MarkNative(info)
            this.ClipboardDirty := false
        } catch as err {
            this.LastError := "剪贴板格式观察失败：" err.Message
        }
    }
    static PreferNativeClipboard() {
        info := this.ClipboardInfo()
        if this.FormattedText && (info.Kind="rich" || info.Kind="table")
            info := {Kind:"text", Text:info.Text, Sequence:info.Sequence}
        if info.Kind = "queue"
            return false
        if info.Kind = "image" {
            if info.Sequence = this.FailedImageSequence {
                this.MarkNative(info)
                return true
            }
            ; Synchronizers can re-encode the same pixels (DIB vs PNG). During
            ; an explicitly built mixed batch, clipboard byte equality is not
            ; an acknowledgement or a reason to override that batch.
            if (this.ImageIndexes.Count && this.HasPending()) || (this.Shared && SQ.PendingImages.Count)
                return false
            if this.ImageIndexes.Count {
            try {
                reference := this.CurrentImage().Reference
                for index, item in this.Queue
                    if this.IsImage(index) && item == reference
                        return false
                if this.Shared && SQ.PendingImages.Has(reference)
                    return false
            }
            }
        }
        if info.Kind != "text" {
            if info.Kind != "unknown"
                this.MarkNative(info)
            return true
        }
        ; A new menu/history/remote copy outside this batch must not be replaced
        ; with an old queue item. Pending explicit copies are synchronized first.
        if this.Queue.Length && (!this.Shared || SQ.PendingCopies = 0) {
            for item in this.Queue
                if item == info.Text
                    return false
            this.MarkNative(info)
            return true
        }
        return false
    }
    static Type() {
        if this.IsSettingsActive() {
            this.NativePaste()
            return
        }
        if this.Shared && this.Enabled
            return SQ.Output("type")
        if this.Busy
            return
        this.Busy := true
        try {
            useQueue := !this.PreferNativeClipboard() && this.HasPending()
            if useQueue && this.IsImage(this.Index) {
                this.Tip("下一条是图片，请用 Ctrl+V；图片不能逐字输入")
                return
            }
            text := useQueue ? this.Queue[this.Index] : this.ReadClipboardText()
            if text = "" {
                this.Tip("没有可逐字输入的文本")
                return
            }
            this.AutoTypeNumber(text)
            if useQueue {
                this.RecordOutput(text, true, this.Index)
                if this.AutoAdvance
                    this.Index++
                this.Touch()
                this.WriteReceipt(this.Index > this.Queue.Length ? "finished" : "ready")
            }
            this.Tip("原文逐字输入"
                . (useQueue ? "：第 " this.LastOutput.ItemIndex "/" this.Queue.Length " 条" : "：当前剪贴板"))
        } catch as err {
            this.LastError := err.Message
            this.Tip("逐字输入未确认完成，请检查目标内容：" err.Message, 5000)
        } finally {
            this.Busy := false
        }
    }
    static WaitTypingKeys() {
        ; Logical state works for forwarded keys too. Do not type while modifiers are held.
        for key in ["Ctrl", "Alt", "Shift", "LWin", "RWin", "v"] {
            if !KeyWait(key, "L T3")
                throw Error("请松开快捷键后再试；未推进队列")
        }
    }
    static EscapePressed() {
        if this.Busy
            this.StopTyping := true
        else if this.ResetEsc
            this.Reset("Esc 中断",true)
    }
    static OpenInputTest(*) {
        if this.Busy {
            this.Tip("请等待当前输出结束，再运行输入自检。")
            return
        }
        if this.WindowHandle(this.InputTestWindow)
            this.InputTestWindow.Gui.Show()
        else
            this.InputTestWindow := SPInputTest(this)
    }
    static EmitText(text) {
        if !IsObject(this.ExpectedTypingTarget)
            this.StopTyping := false
        try {
            this.LastInput := SPInput.Send(text,this.TypingMethod,this.TypeDelay,()=>!this.StopTyping,this.ExpectedTypingTarget)
            this.SaveInputReport(this.LastInput)
            return this.LastInput
        } catch as err {
            if err is SPInputFailure {
                this.LastInput := err
                this.SaveInputReport(err)
            }
            throw err
        }
    }
    static SaveInputReport(report) {
        if this.StateDir=""
            return
        try this.AtomicWrite(this.StateDir "\input-status.txt","SPINPUT1`n" report.Code "`n" report.Completed "`n" report.AcceptedEvents "`n" this.TypingMethod "`n" (report.HasProp("SystemError")?report.SystemError:0))
    }
    static ClipboardPaste(text) {
        saved := ClipboardAll(), ownedSeq := -1
        try {
            Loop 3 {
                A_Clipboard := text
                ownedSeq := this.ClipSequence()
                Sleep(80)
                if this.ClipSequence() = ownedSeq
                    break
                ownedSeq := -1
            }
            if ownedSeq = -1
                throw Error("剪贴板持续被同步软件改写；本次未粘贴，请稍后重试")
            this.PasteClipboardPayload()
            Sleep(250)
        } finally {
            ; Never overwrite an intervening external clipboard update with old data.
            if ownedSeq != -1 && this.ClipSequence() = ownedSeq
                A_Clipboard := saved
        }
    }
    static PasteClipboardPayload() {
        ; Progress means the user-requested action was dispatched, not that the
        ; target application accepted, displayed, or saved its clipboard data.
        this.NativePaste()
    }
    static ClipSequence() => DllCall("GetClipboardSequenceNumber", "uint")
    static NativePaste() => this.SendNative("v")
    static Encode(text) {
        count := StrPut(text, "UTF-8") - 1
        if count = 0
            return ""
        bytes := Buffer(count + 1), chars := 0
        StrPut(text, bytes, "UTF-8")
        if !DllCall("crypt32\CryptBinaryToStringW", "ptr", bytes, "uint", count, "uint", 0x40000001, "ptr", 0, "uint*", &chars)
            throw Error("文本编码失败")
        result := Buffer(chars * 2)
        if !DllCall("crypt32\CryptBinaryToStringW", "ptr", bytes, "uint", count, "uint", 0x40000001, "ptr", result, "uint*", &chars)
            throw Error("文本编码失败")
        return StrGet(result)
    }
    static Decode(text) {
        bytes := 0
        if !DllCall("crypt32\CryptStringToBinaryW", "str", text, "uint", 0, "uint", 1, "ptr", 0, "uint*", &bytes, "ptr", 0, "ptr", 0)
            throw Error("队列编码无效")
        result := Buffer(bytes + 1, 0)
        if !DllCall("crypt32\CryptStringToBinaryW", "str", text, "uint", 0, "uint", 1, "ptr", result, "uint*", &bytes, "ptr", 0, "ptr", 0)
            throw Error("队列编码无效")
        return StrGet(result, bytes, "UTF-8")
    }
    static AtomicWrite(path, text) {
        temp := path "." DllCall("GetCurrentProcessId", "uint") ".tmp"
        try {
            stream := FileOpen(temp, "w", "UTF-8-RAW")
            stream.Write(text), stream.Close()
            FileMove(temp, path, 1)
        } finally {
            if FileExist(temp)
                FileDelete(temp)
        }
    }
    static Publish(action := "SET") {
        this.Revision++
        snapshot := "SPQ1`n" this.Session "`n" this.Revision "`n" this.Batch "`n" action "`n" this.Queue.Length
        for text in this.Queue
            snapshot .= "`n" this.Encode(text)
        this.PendingSnapshot := snapshot
        this.FlushPublish()
    }
    static FlushPublish() {
        if this.PendingSnapshot = ""
            return
        try {
            this.AtomicWrite(this.StateDir "\outbox.txt", this.PendingSnapshot)
            this.PendingSnapshot := ""
        }
        catch as err {
            this.LastError := "本机已入队，但发送文件写入失败：" err.Message
            this.Tip(this.LastError, 5000)
        }
    }
    static ParseSnapshot(snapshot) {
        lines := StrSplit(Trim(snapshot, "`r`n"), "`n", "`r")
        if lines.Length < 6 || lines[1] != "SPQ1" || !RegExMatch(lines[2], "^\{[0-9A-Fa-f-]{36}\}$")
            || !RegExMatch(lines[4], "^\{[0-9A-Fa-f-]{36}\}$") || !RegExMatch(lines[3], "^\d+$")
            || !RegExMatch(lines[6], "^\d+$") || (lines[5] != "SET" && lines[5] != "CLEAR")
            throw Error("队列格式无效")
        count := Integer(lines[6]), revision := Integer(lines[3])
        if revision < 1 || count > 500 || lines.Length != count + 6 || (lines[5] = "CLEAR" && count != 0)
            throw Error("队列条数无效")
        queue := [], total := 0
        Loop count {
            text := this.Decode(lines[A_Index + 6])
            if text = "" || StrLen(text) > 100000
                throw Error("队列条目无效")
            total += StrLen(text)
            if total > 500000
                throw Error("队列过大")
            queue.Push(text)
        }
        return {Session: lines[2], Revision: revision, Batch: lines[4], Action: lines[5], Queue: queue}
    }
    static ApplySnapshot(snapshot) {
        data := this.ParseSnapshot(snapshot)
        if data.Session = this.RemoteSession && data.Revision <= this.AppliedRevision
            return false
        sameBatch := data.Session = this.RemoteSession && data.Batch = this.RemoteBatch
        if sameBatch && data.Action = "SET" {
            if data.Queue.Length < this.Queue.Length
                throw Error("同批队列不得缩短")
            for i, item in this.Queue {
                if item !== data.Queue[i]
                    throw Error("同批队列已有内容不得改变")
            }
        }
        this.RemoteSession := data.Session, this.RemoteBatch := data.Batch
        this.AppliedRevision := data.Revision
        if !sameBatch || data.Action = "CLEAR"
            this.LastOutput := 0
        if !this.Enabled {
            this.Queue := [], this.Index := 1
            this.WriteReceipt("disabled")
            this.EraseInbox()
            return true
        }
        if !sameBatch || data.Action = "CLEAR"
            this.Index := 1
        this.Queue := data.Queue
        if data.Action = "CLEAR"
            SetTimer(SP.ExpireCallback, 0)
        else
            this.Touch()
        this.WriteReceipt(data.Action = "CLEAR" ? "cleared" : "ready")
        this.Tip(data.Action = "CLEAR" ? "发送端已清空队列" : "已接收 " this.Queue.Length " 条，下一条 " this.Index)
        return true
    }
    static WriteReceipt(state := "ready") {
        if this.Shared
            return
        if this.Role != "receiver" || this.StateDir = "" || this.RemoteSession = ""
            return
        try this.AtomicWrite(this.StateDir "\receipt.txt", "SPRECEIPT1`n" this.RemoteSession "`n"
            . this.RemoteBatch "`n" this.AppliedRevision "`n" this.Index "`n" this.Queue.Length "`n" state)
        catch as err {
            this.LastError := "进度回执未写入，重启前请检查：" err.Message
            this.Tip(this.LastError, 5000)
        }
    }
    static EraseInbox() {
        if this.RemoteSession = "" || this.StateDir = ""
            return
        sanitized := "SPQ1`n" this.RemoteSession "`n" this.AppliedRevision "`n" this.RemoteBatch "`nCLEAR`n0"
        try {
            this.AtomicWrite(this.StateDir "\inbox.txt", sanitized)
            this.LastInbox := sanitized
        } catch as err {
            this.LastError := "清除接收暂存文件失败：" err.Message
        }
    }
    static Poll() {
        if this.Busy
            return
        if this.Shared
            return SQ.Poll()
        if this.Role = "sender" {
            this.FlushPublish()
            return
        }
        if this.Role != "receiver"
            return
        try {
            path := this.StateDir "\inbox.txt"
            if !FileExist(path)
                return
            snapshot := FileRead(path, "UTF-8")
            if snapshot == this.LastInbox
                return
            this.ApplySnapshot(snapshot)
            if this.Queue.Length = 0
                this.EraseInbox()
            else
                this.LastInbox := snapshot
        } catch as err {
            this.LastError := "接收队列：" err.Message
        }
    }
    static RestoreReceiver() {
        try {
            snapshot := FileRead(this.StateDir "\inbox.txt", "UTF-8")
            receiptPath := this.StateDir "\receipt.txt"
            fields := StrSplit(Trim(FileRead(receiptPath, "UTF-8"), "`r`n"), "`n", "`r")
            data := this.ParseSnapshot(snapshot)
            if fields.Length < 7 || fields[1] != "SPRECEIPT1" || fields[2] != data.Session
                || fields[3] != data.Batch || Integer(fields[4]) != data.Revision
                return
            this.RemoteSession := data.Session, this.RemoteBatch := data.Batch
            this.AppliedRevision := data.Revision, this.LastInbox := snapshot
            expired := this.TimeoutMs > 0 && DateDiff(A_Now, FileGetTime(receiptPath), "Seconds") >= this.TimeoutMs // 1000
            if !expired && (fields[7] = "ready" || fields[7] = "finished")
                && Integer(fields[6]) = data.Queue.Length && Integer(fields[5]) >= 1
                && Integer(fields[5]) <= data.Queue.Length + 1 {
                this.Queue := data.Queue, this.Index := Integer(fields[5])
                this.Touch()
            }
            if fields[7] = "disabled"
                this.Enabled := false
            if this.Queue.Length = 0
                this.EraseInbox()
        } catch {
            ; Invalid/missing saved state is never automatically pasted or executed.
        }
    }
    static StartBridge() {
        ps := A_WinDir "\System32\WindowsPowerShell\v1.0\powershell.exe"
        command := '"' ps '" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'
            . A_ScriptDir '\Modules\SequenceBridge.ps1" -ConfigPath "' this.ConfigPath '" -StateDir "'
            . this.StateDir '" -ParentPid ' DllCall("GetCurrentProcessId", "uint")
        Run(command, A_ScriptDir, "Hide", &pid)
        this.BridgePid := pid
        this.BridgeHandle := DllCall("OpenProcess", "uint", 0x100001, "int", false, "uint", pid, "ptr")
    }
    static ShowStatus(*) {
        status := "本地模式", peer := ""
        if this.Role != "local" {
            try status := FileRead(this.StateDir "\bridge-status.txt", "UTF-8")
            catch
                status := "连接助手启动中或未能启动"
            if !ProcessExist(this.BridgePid)
                status := "连接助手已退出，请检查状态目录的 bridge-error.txt，修正后重启"
        }
        if this.Role = "sender" && !this.Shared {
            try {
                f := StrSplit(Trim(FileRead(this.StateDir "\peer-receipt.txt", "UTF-8"), "`r`n"), "`n", "`r")
                if f.Length >= 7 && f[2] = this.Session && f[3] = this.Batch
                    peer := "`n对端已处理版本：" f[4] "；下一条：" f[5] "/" f[6] "；" f[7]
            }
        }
        MsgBox("模式：" (this.Shared ? "双向共享队列" : this.Role) "`n功能：" (this.Enabled ? "开启" : "关闭") "`nCtrl+V：普通 / 顺序粘贴；两条起启用队列"
            "`n图文混合队列；Ctrl+Alt+C：将当前截图加入队列`n默认进度：动作正常发出即推进，可在设置中切换手动推进"
            "`n本机队列：" this.Queue.Length " 条；下一条：" this.Index "`n网络：" status peer
            "`n最近错误：" this.LastError "`n`n配置：" this.ConfigPath "`n状态目录：" this.StateDir
            "`n自动逐字输入数字位数上限：" this.NumericTypingMaxDigits
            . "`n`nCtrl+Alt+V：强制普通粘贴；Ctrl+Shift+V：原文逐字输入"
            . "`nCtrl+Alt+R：从头重贴；Ctrl+Alt+Z：清空", "双机顺序粘贴状态 v2.3.4")
    }
    static Shutdown(*) {
        if IsObject(this.InputTestWindow)
            this.InputTestWindow.Close()
        if IsObject(this.SettingsWindow)
            this.SettingsWindow.Close()
        SetTimer(SP.ExpireCallback, 0)
        if IsObject(this.Panel)
            this.Panel.Dispose()
        if this.BridgeHandle {
            if DllCall("WaitForSingleObject", "ptr", this.BridgeHandle, "uint", 0, "uint") = 258
                DllCall("TerminateProcess", "ptr", this.BridgeHandle, "uint", 0)
            DllCall("CloseHandle", "ptr", this.BridgeHandle)
            this.BridgeHandle := 0
        }
        if this.StateDir != "" {
            ; Receiver inbox/receipt retain progress across a clean restart (subject to timeout).
            for name in ["outbox.txt", "peer-receipt.txt"] {
                try FileDelete(this.StateDir "\" name)
            }
        }
    }
}


; A native, non-activating queue panel. It never changes the clipboard by refreshing.
class SPPanel {
    __New(owner) {
        this.Owner := owner
        this.Visible := false
        this.LastTarget := 0, this.LastControl := 0, this.LastStatus := ""
        roleName := owner.Shared ? "共享队列" : (owner.Role = "receiver" ? "接收端" : (owner.Role = "sender" ? "发送端" : "本机"))
        this.Settings := 0, this.Disposed := false
        this.Connected := false, this.TooltipText := ""
        this.TooltipCallback := ObjBindMethod(this, "ClearTooltip")
        this.FixedDiameter := this.ReadSetting("Diameter", 460, 100, 640)
        this.AutoExpand := this.ReadSetting("AutoExpand", 1, 0, 1)
        this.CollapsedDiameter := this.ReadSetting("CollapsedDiameter", 120, 100, 300)
        this.ExpandedDiameter := this.ReadSetting("ExpandedDiameter", 420, 320, 640)
        this.Expanded := false, this.Dragging := false, this.Resizing := false, this.HoverOrigin := 0
        this.PointerSince := 0, this.LeaveSince := 0, this.EnvironmentDirty := true
        this.AnchorReady := false, this.AnchorX := 0, this.AnchorY := 0
        this.LastEnvironmentCheck := 0, this.EnvironmentKey := ""
        this.Dpi := A_ScreenDPI
        this.Diameter := this.AutoExpand ? this.CollapsedDiameter : this.FixedDiameter
        this.Opacity := this.ReadSetting("Opacity", 95, 35, 100)
        this.Sectors := [], this.HoverHwnd := 0, this.LastProgress := -1, this.LayoutBusy := false
        this.GdipToken := 0
        startup := Buffer(A_PtrSize = 8 ? 24 : 16, 0)
        NumPut("uint", 1, startup)
        this.GdipLibrary := DllCall("LoadLibrary", "str", "gdiplus.dll", "ptr")
        if DllCall("gdiplus\GdiplusStartup", "ptr*", &token := 0, "ptr", startup, "ptr", 0)
            throw Error("无法初始化浮窗绘图")
        this.GdipToken := token
        this.Gui := Gui("+AlwaysOnTop +ToolWindow -Caption -Border -DPIScale +E0x08000000", "顺序粘贴 · " roleName " v2.3.4")
        this.Dpi := DllCall("GetDpiForWindow", "ptr", this.Gui.Hwnd, "uint")
        if !this.Dpi
            this.Dpi := A_ScreenDPI
        this.Gui.BackColor := "F0F6FF"
        this.Gui.MarginX := 12, this.Gui.MarginY := 10
        this.Gui.SetFont("s9", "Microsoft YaHei UI")
        this.Title := this.Gui.AddText("Center BackgroundTrans c45618A", "顺序粘贴 · " roleName)
        this.Connection := this.Gui.AddText("Center BackgroundTrans c64748B", "正在读取连接状态…")
        this.Gui.SetFont("s11 Bold", "Microsoft YaHei UI")
        this.Position := this.Gui.AddText("Center BackgroundTrans c172B4D", "等待复制内容")
        this.Bar := this.Gui.AddProgress("xm y+3 w360 h5 c3974D8 BackgroundE4E9F1 Range0-100", 0)
        this.Gui.SetFont("s9 Norm", "Microsoft YaHei UI")
        this.Mode := this.Gui.AddText("Center BackgroundTrans c365B8C", "")
        this.Preview := this.Gui.AddText("Center BackgroundTrans c334155", "")
        this.Last := this.Gui.AddText("Center BackgroundTrans c64748B", "")
        this.CenterLabel := this.Gui.AddText("Center BackgroundTrans c64748B", owner.Role = "receiver" ? "接收队列" : "本机队列")
        this.Back := this.Gui.AddButton("xm y+8 w116 h30 -TabStop +0xB", "回退一条")
        this.Replay := this.Gui.AddButton("x+6 yp w116 h30 -TabStop +0xB", "重贴上一条")
        this.Skip := this.Gui.AddButton("x+6 yp w116 h30 -TabStop +0xB", "跳过当前条")
        this.New := this.Gui.AddButton("xm y+6 w238 h30 -TabStop +0xB", "开始新批次")
        this.Type := this.Gui.AddButton("-TabStop +0xB", "逐字输入")
        this.HideButton := this.Gui.AddButton("-TabStop +0xB", "收起")
        this.Appearance := this.Gui.AddButton("-TabStop +0xB", "外观")
        this.SubclassCallback := ObjBindMethod(this, "SectorMessage")
        this.SubclassProc := CallbackCreate(this.SubclassCallback, , 6)
        for button in [this.Back, this.Replay, this.Skip, this.New, this.Type, this.Appearance, this.HideButton]
            DllCall("comctl32\SetWindowSubclass", "ptr", button.Hwnd, "ptr", this.SubclassProc, "uptr", 1, "uptr", 0)
        for button in [this.Back, this.Replay, this.Skip, this.New, this.Type, this.HideButton, this.Appearance] {
            ControlSetStyle((ControlGetStyle(button.Hwnd) & ~0xF) | 0xB, button.Hwnd)
            DllCall("uxtheme\SetWindowTheme", "ptr", button.Hwnd, "str", "", "str", "")
        }
        this.Back.OnEvent("Click", ObjBindMethod(this, "Perform", "back"))
        this.Replay.OnEvent("Click", ObjBindMethod(this, "Perform", "replay"))
        this.Skip.OnEvent("Click", ObjBindMethod(this, "Perform", "skip"))
        this.New.OnEvent("Click", ObjBindMethod(this, "Perform", "new"))
        this.Type.OnEvent("Click", ObjBindMethod(this, "Perform", "type"))
        this.HideButton.OnEvent("Click", (*) => this.Hide())
        this.Appearance.OnEvent("Click", ObjBindMethod(this, "OpenSettings"))
        this.Footer := this.Gui.AddText("Center BackgroundTrans c526681", "拖动标题移动 · 右键调整外观")
        this.Gui.OnEvent("Close", (*) => this.Hide())
        this.Gui.OnEvent("ContextMenu", ObjBindMethod(this, "OpenSettings"))
        this.ActivationCallback := ObjBindMethod(this, "NoActivate")
        this.PaintCallback := ObjBindMethod(this, "PaintBackground")
        this.ButtonCallback := ObjBindMethod(this, "PaintButton")
        this.DragCallback := ObjBindMethod(this, "Drag")
        this.HoverCallback := ObjBindMethod(this, "Hover")
        this.LeaveCallback := ObjBindMethod(this, "Leave")
        this.RefreshCallback := ObjBindMethod(this, "Refresh")
        this.EnvironmentCallback := ObjBindMethod(this, "EnvironmentTick")
        this.DisplayCallback := ObjBindMethod(this, "DisplayChanged")
        this.MoveCallback := ObjBindMethod(this, "MoveChanged")
        OnMessage(0x21, this.ActivationCallback)
        OnMessage(0x14, this.PaintCallback)
        OnMessage(0x2B, this.ButtonCallback)
        OnMessage(0x201, this.DragCallback)
        OnMessage(0x200, this.HoverCallback)
        OnMessage(0x2A3, this.LeaveCallback)
        OnMessage(0x7E, this.DisplayCallback) ; resolution / monitor topology
        OnMessage(0x1A, this.DisplayCallback) ; taskbar / work area / settings
        OnMessage(0x2E0, this.DisplayCallback) ; per-monitor DPI
        OnMessage(0x231, this.MoveCallback)
        OnMessage(0x232, this.MoveCallback)
        this.Layout()
        SetTimer(this.EnvironmentCallback, 100)
        SetTimer(this.RefreshCallback, 250)
        this.Refresh()
        visible := 1
        try visible := Integer(IniRead(owner.ConfigPath, "Panel", "Visible", "1"))
        if visible
            this.Show()
    }
    ReadSetting(key, fallback, low, high) {
        try return Max(low, Min(high, Integer(IniRead(this.Owner.ConfigPath, "Panel", key, fallback))))
        return fallback
    }
    FontOptions(points, style := "Norm") => "s" (points * this.Dpi / A_ScreenDPI) " " style
    Layout() {
        this.LayoutBusy := true
        try {
            s := this.Diameter, scale := s / 460
            this.Compact := s < 320, this.ShowMini := s >= 240, this.ShowDevice := s >= 180
            this.DeviceNX := this.ShowMini ? .405 : .46, this.DeviceNY := this.ShowMini ? .329 : .35
            this.DotNX := this.ShowMini ? .468 : (this.ShowDevice ? .55 : .5)
            this.DotNY := this.ShowMini ? .33 : .35
            this.Gui.SetFont(this.FontOptions(Max(8, 10 * scale)), "Microsoft YaHei UI")
            for control in [this.Title, this.Connection, this.Mode, this.Preview, this.Last, this.CenterLabel,
                this.Back, this.Replay, this.Skip, this.New, this.Type, this.Appearance, this.HideButton]
                control.SetFont(this.FontOptions(Max(8, 10 * scale)), "Microsoft YaHei UI")
            this.Title.SetFont(this.FontOptions(Max(8, 10 * scale), "Bold"), "Microsoft YaHei UI")
            this.Position.SetFont(this.FontOptions(Max(10, 13 * scale), "Bold"), "Microsoft YaHei UI")
            this.Place(this.Appearance, .515, .298, .064, .064)
            this.Place(this.HideButton, .59, .298, .064, .064)
            for button in [this.Appearance, this.HideButton] {
                rect := Buffer(16)
                DllCall("GetClientRect", "ptr", button.Hwnd, "ptr", rect)
                region := DllCall("CreateEllipticRgn", "int", 0, "int", 0,
                    "int", NumGet(rect, 8, "int"), "int", NumGet(rect, 12, "int"), "ptr")
                if !DllCall("SetWindowRgn", "ptr", button.Hwnd, "ptr", region, "int", true)
                    DllCall("DeleteObject", "ptr", region)
            }
            this.Appearance.SetFont(this.FontOptions(Max(7, 8 * scale)), "Microsoft YaHei UI")
            this.HideButton.SetFont(this.FontOptions(Max(7, 8 * scale)), "Microsoft YaHei UI")
            this.Place(this.Position, .285, .406, .43, .07)
            this.Place(this.Mode, .31, .50, .38, .065)
            this.Place(this.Preview, .325, .575, .35, .09)
            this.Place(this.Last, .36, .683, .28, .04)
            this.CenterLabel.SetFont(this.FontOptions(Max(7, 8 * scale)), "Microsoft YaHei UI")
            this.Mode.SetFont(this.FontOptions(Max(8, 9 * scale)), "Microsoft YaHei UI")
            this.Preview.SetFont(this.FontOptions(Max(8, 9 * scale)), "Microsoft YaHei UI")
            this.Last.SetFont(this.FontOptions(Max(7, 8 * scale)), "Microsoft YaHei UI")
            this.Mode.Visible := !this.Compact, this.Preview.Visible := !this.Compact, this.Last.Visible := !this.Compact
            this.Appearance.Visible := this.ShowMini, this.HideButton.Visible := this.ShowMini
            if this.Compact {
                this.Place(this.Position, .28, .48, .44, .14)
                this.Position.SetFont(this.FontOptions(Max(7, Min(13, s * .04)), "Bold"), "Microsoft YaHei UI")
            }
            this.Bar.Visible := false, this.Footer.Visible := false
            this.Title.Visible := false, this.Connection.Visible := false, this.CenterLabel.Visible := false
            this.ClearSectorPaths()
            for item in [[this.Back, "back", -90], [this.Replay, "replay", -18],
                [this.New, "new", 54], [this.Skip, "skip", 126], [this.Type, "type", 198]] {
                pixels := Round(s * this.Dpi / 96)
                item[1].Move(0, 0, pixels, pixels)
                item[1].SetFont(this.FontOptions(Max(8, 9.5 * scale)), "Microsoft YaHei UI")
                sector := {Control: item[1], Action: item[2], Start: item[3], Path: 0}
                this.BuildSector(sector)
                this.Sectors.Push(sector)
            }
            this.HoverHwnd := 0
        } finally {
            this.LayoutBusy := false
        }
        DllCall("RedrawWindow", "ptr", this.Gui.Hwnd, "ptr", 0, "ptr", 0, "uint", 0x85)
    }
    Place(control, x, y, width, height) {
        s := this.Diameter * this.Dpi / 96
        control.Move(Round(x * s), Round(y * s), Round(width * s), Round(height * s))
    }
    ApplyRegion() {
        ; The window itself is circular; invisible corners never intercept clicks.
        WinGetClientPos(, , &width, &height, this.Gui.Hwnd)
        region := DllCall("CreateEllipticRgn", "int", 0, "int", 0, "int", width, "int", height, "ptr")
        if !DllCall("SetWindowRgn", "ptr", this.Gui.Hwnd, "ptr", region, "int", true)
            DllCall("DeleteObject", "ptr", region)
    }
    ClearSectorPaths() {
        for sector in this.Sectors {
            if sector.Path
                DllCall("gdiplus\GdipDeletePath", "ptr", sector.Path)
        }
        this.Sectors := []
    }
    BuildSector(sector) {
        rect := Buffer(16, 0)
        DllCall("GetClientRect", "ptr", sector.Control.Hwnd, "ptr", rect)
        w := NumGet(rect, 8, "int"), h := NumGet(rect, 12, "int")
        points := [], first := sector.Start + 1.1, sweep := 72 - 2.2
        Loop 37 {
            angle := (first + sweep * (A_Index - 1) / 36) * 0.0174532925199433
            points.Push([w * (.5 + .47 * Cos(angle)), h * (.5 + .47 * Sin(angle))])
        }
        Loop 37 {
            angle := (first + sweep * (37 - A_Index) / 36) * 0.0174532925199433
            points.Push([w * (.5 + .279 * Cos(angle)), h * (.5 + .279 * Sin(angle))])
        }
        regionPoints := Buffer(points.Length * 8), pathPoints := Buffer(points.Length * 8)
        for index, point in points {
            NumPut("int", Round(point[1]), "int", Round(point[2]), regionPoints, (index - 1) * 8)
            NumPut("float", point[1], "float", point[2], pathPoints, (index - 1) * 8)
        }
        DllCall("gdiplus\GdipCreatePath", "int", 0, "ptr*", &path := 0)
        DllCall("gdiplus\GdipAddPathPolygon", "ptr", path, "ptr", pathPoints, "int", points.Length)
        sector.Path := path
        angle := (sector.Start + 36) * 0.0174532925199433
        sector.X := w * (.5 + .38 * Cos(angle))
        sector.Y := h * (.5 + .38 * Sin(angle))
        iconRadius := this.Compact ? .3745 : .397
        sector.IconX := w * (.5 + iconRadius * Cos(angle))
        sector.IconY := h * (.5 + iconRadius * Sin(angle))
        sector.CX := w * .5, sector.CY := h * .5, sector.LabelRadius := w * .32
        sector.Width := w
        region := DllCall("CreatePolygonRgn", "ptr", regionPoints, "int", points.Length, "int", 1, "ptr")
        if !DllCall("SetWindowRgn", "ptr", sector.Control.Hwnd, "ptr", region, "int", true)
            DllCall("DeleteObject", "ptr", region)
    }
    Graphics(dc) {
        DllCall("gdiplus\GdipCreateFromHDC", "ptr", dc, "ptr*", &g := 0)
        DllCall("gdiplus\GdipGraphicsClear", "ptr", g, "uint", 0xFFF0F6FF)
        DllCall("gdiplus\GdipSetSmoothingMode", "ptr", g, "int", 4)
        return g
    }
    Canvas(dc, width, height) {
        memory := DllCall("CreateCompatibleDC", "ptr", dc, "ptr")
        bitmap := DllCall("CreateCompatibleBitmap", "ptr", dc, "int", width, "int", height, "ptr")
        old := DllCall("SelectObject", "ptr", memory, "ptr", bitmap, "ptr")
        return {DC: memory, Bitmap: bitmap, Old: old, Width: width, Height: height}
    }
    FinishCanvas(dc, canvas, hwnd) {
        ; GDI blitting respects native clipping, including shaped child buttons.
        saved := DllCall("SaveDC", "ptr", dc)
        region := DllCall("CreateRectRgn", "int", 0, "int", 0, "int", 0, "int", 0, "ptr")
        if DllCall("GetWindowRgn", "ptr", hwnd, "ptr", region) != 0
            DllCall("ExtSelectClipRgn", "ptr", dc, "ptr", region, "int", 1)
        DllCall("BitBlt", "ptr", dc, "int", 0, "int", 0, "int", canvas.Width, "int", canvas.Height,
            "ptr", canvas.DC, "int", 0, "int", 0, "uint", 0xCC0020)
        DllCall("RestoreDC", "ptr", dc, "int", saved)
        DllCall("DeleteObject", "ptr", region)
        DllCall("SelectObject", "ptr", canvas.DC, "ptr", canvas.Old)
        DllCall("DeleteObject", "ptr", canvas.Bitmap)
        DllCall("DeleteDC", "ptr", canvas.DC)
    }
    Solid(color) {
        DllCall("gdiplus\GdipCreateSolidFill", "uint", 0xFF000000 | color, "ptr*", &brush := 0)
        return brush
    }
    Gradient(x, y, width, height, top, bottom) {
        rect := Buffer(16)
        NumPut("float", x, "float", y, "float", width, "float", height, rect)
        DllCall("gdiplus\GdipCreateLineBrushFromRect", "ptr", rect, "uint", 0xFF000000 | top,
            "uint", 0xFF000000 | bottom, "int", 1, "int", 1, "ptr*", &brush := 0)
        return brush
    }
    Pen(color, width) {
        DllCall("gdiplus\GdipCreatePen1", "uint", 0xFF000000 | color, "float", width, "int", 2, "ptr*", &pen := 0)
        DllCall("gdiplus\GdipSetPenStartCap", "ptr", pen, "int", 2)
        DllCall("gdiplus\GdipSetPenEndCap", "ptr", pen, "int", 2)
        return pen
    }
    FillCircle(g, brush, cx, cy, radius) {
        DllCall("gdiplus\GdipFillEllipse", "ptr", g, "ptr", brush, "float", cx - radius,
            "float", cy - radius, "float", radius * 2, "float", radius * 2)
    }
    PaintBackground(dc, lParam, msg, hwnd) {
        if this.LayoutBusy
            return 1
        if IsObject(this.FindSector(hwnd))
            return 1
        if hwnd != this.Gui.Hwnd
            return
        WinGetClientPos(, , &w, &h, this.Gui.Hwnd)
        canvas := this.Canvas(dc, w, h)
        g := this.Graphics(canvas.DC)
        for ring in [[.5, 0xD2E2FA], [.49, 0xFFFFFF], [.478, 0xE8F0FE], [.463, 0xF0F6FF]] {
            brush := this.Solid(ring[2])
            this.FillCircle(g, brush, w * .5, h * .5, w * ring[1])
            DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        }
        brush := this.Gradient(0, h * .242, w, h * .48, 0xFFFFFF, 0xDFEBFF)
        this.FillCircle(g, brush, w * .5, h * .5, w * .258)
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        pen := this.Pen(0xD5E3FA, w * .009)
        DllCall("gdiplus\GdipDrawEllipse", "ptr", g, "ptr", pen, "float", w * .234,
            "float", h * .234, "float", w * .532, "float", h * .532)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        if this.LastProgress > 0 {
            pen := this.Pen(0x548BFF, w * .009)
            DllCall("gdiplus\GdipDrawArc", "ptr", g, "ptr", pen, "float", w * .234,
                "float", h * .234, "float", w * .532, "float", h * .532,
                "float", -90, "float", this.LastProgress * 3.6)
            DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        }
        this.DrawIndicators(g, w)
        DllCall("gdiplus\GdipDeleteGraphics", "ptr", g)
        this.FinishCanvas(dc, canvas, hwnd)
        return 1
    }
    BGR(rgb) => ((rgb & 255) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 255)
    FindSector(hwnd) {
        for sector in this.Sectors {
            if sector.Control.Hwnd = hwnd
                return sector
        }
        return 0
    }
    PaintButton(wParam, data, msg, hwnd) {
        if hwnd != this.Gui.Hwnd || NumGet(data, 0, "uint") != 4
            return
        controlHwnd := NumGet(data, A_PtrSize = 8 ? 24 : 20, "ptr")
        sector := this.FindSector(controlHwnd)
        if !IsObject(sector)
            return this.PaintTopButton(wParam, data, msg, hwnd)
        dc := NumGet(data, A_PtrSize = 8 ? 32 : 24, "ptr")
        return this.PaintSector(dc, sector, NumGet(data, 16, "uint"))
    }
    SectorMessage(hwnd, msg, wParam, lParam, subclassId, reference) {
        if this.LayoutBusy {
            if msg = 0xF {
                DllCall("ValidateRect", "ptr", hwnd, "ptr", 0)
                return 0
            }
            if msg = 0x14 || msg = 0x317 || msg = 0x318
                return 1
        }
        sector := this.FindSector(hwnd), mini := this.IsMini(hwnd)
        if IsObject(sector) || mini {
            if msg = 0x14
                return 1
            if msg = 0x200
                this.Hover(wParam, lParam, msg, hwnd)
            else if msg = 0x2A3
                this.Leave(wParam, lParam, msg, hwnd)
            else if msg = 0xF || msg = 0x317 || msg = 0x318 {
                state := (SendMessage(0xF2, 0, 0, hwnd) & 4 ? 1 : 0) | (DllCall("IsWindowEnabled", "ptr", hwnd) ? 0 : 4)
                if msg = 0xF {
                    paint := Buffer(A_PtrSize = 8 ? 72 : 64, 0)
                    dc := DllCall("BeginPaint", "ptr", hwnd, "ptr", paint, "ptr")
                    if mini
                        this.PaintMini(dc, hwnd, state)
                    else
                        this.PaintSector(dc, sector, state)
                    DllCall("EndPaint", "ptr", hwnd, "ptr", paint)
                } else {
                    if mini
                        this.PaintMini(wParam, hwnd, state)
                    else
                        this.PaintSector(wParam, sector, state)
                }
                return 0
            }
        }
        return DllCall("comctl32\DefSubclassProc", "ptr", hwnd, "uint", msg, "uptr", wParam, "ptr", lParam, "ptr")
    }
    PaintSector(dc, sector, state) {
        controlHwnd := sector.Control.Hwnd
        disabled := state & 4, pressed := state & 1
        primary := sector.Action = "new", hover := this.HoverHwnd = controlHwnd && !disabled
        top := primary ? (pressed ? 0x2458CD : 0x568FFF) : (disabled ? 0xF0F4FA : (hover ? 0xE8F3FF : 0xFFFFFF))
        bottom := primary ? (pressed ? 0x1D47AE : 0x2861F0) : (disabled ? 0xE6EDF7 : (hover ? 0xCDDEFF : 0xE5EFFF))
        ink := disabled ? 0x8291A8 : (primary ? 0xFFFFFF : 0x25446D)
        canvas := this.Canvas(dc, sector.Width, sector.Width)
        g := this.Graphics(canvas.DC)
        brush := this.Gradient(0, 0, sector.Width, sector.Width, top, bottom)
        DllCall("gdiplus\GdipFillPath", "ptr", g, "ptr", brush, "ptr", sector.Path)
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        pen := this.Pen(primary ? 0x679AFF : (hover ? 0x8AB4FA : 0xC1D6F5), Max(1, sector.Width / 400))
        DllCall("gdiplus\GdipDrawPath", "ptr", g, "ptr", pen, "ptr", sector.Path)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        this.DrawIcon(g, sector.Action, sector.IconX, sector.IconY, sector.Width * (this.Compact ? .052 : .029),
            disabled ? ink : (primary ? 0xFFFFFF : 0x3B72DD))
        if !this.Compact
            this.DrawArcLabel(g, sector, ink)
        DllCall("gdiplus\GdipDeleteGraphics", "ptr", g)
        this.FinishCanvas(dc, canvas, controlHwnd)
        return true
    }
    DrawArcLabel(g, sector, color) {
        chars := StrSplit(ControlGetText(sector.Control.Hwnd)), fontSize := sector.Width * .030
        center := sector.Start + 36, centerPhase := Mod(center + 360, 180)
        sector.AvailableTextDegrees := Min(60, 2 * Min(centerPhase, 180 - centerPhase) - 4)
        DllCall("gdiplus\GdipCreateFontFamilyFromName", "wstr", "Microsoft YaHei UI", "ptr", 0, "ptr*", &family := 0)
        DllCall("gdiplus\GdipStringFormatGetGenericTypographic", "ptr*", &arcFormat := 0)
        DllCall("gdiplus\GdipSetStringFormatAlign", "ptr", arcFormat, "int", 1)
        DllCall("gdiplus\GdipSetStringFormatLineAlign", "ptr", arcFormat, "int", 1)
        DllCall("gdiplus\GdipSetTextRenderingHint", "ptr", g, "int", 4)
        measureRect := Buffer(16), bounds := Buffer(16)
        NumPut("float", 0, "float", 0, "float", 10000, "float", 10000, measureRect)
        ; All five labels share the same base face/size. Shrink only if its inner arc requires it.
        Loop 2 {
            DllCall("gdiplus\GdipCreateFont", "ptr", family, "float", fontSize, "int", 0, "int", 2, "ptr*", &font := 0)
            widths := [], length := 0
            for char in chars {
                DllCall("gdiplus\GdipMeasureString", "ptr", g, "wstr", char, "int", StrLen(char), "ptr", font,
                    "ptr", measureRect, "ptr", arcFormat, "ptr", bounds, "ptr", 0, "ptr", 0)
                width := Max(fontSize * .4, NumGet(bounds, 8, "float"))
                widths.Push(width), length += width
            }
            spacing := fontSize * .08
            length += Max(0, chars.Length - 1) * spacing
            available := sector.LabelRadius * sector.AvailableTextDegrees * 0.0174532925199433
            if length <= available || A_Index = 2
                break
            DllCall("gdiplus\GdipDeleteFont", "ptr", font)
            fontSize *= available / length
        }
        brush := this.Solid(color), cursor := -length / 2
        direction := Sin(center * 0.0174532925199433) > 0 ? -1 : 1
        glyphRect := Buffer(16)
        NumPut("float", -fontSize, "float", -fontSize, "float", fontSize * 2, "float", fontSize * 2, glyphRect)
        sector.LabelFontSize := fontSize, sector.LabelSpan := length / sector.LabelRadius, sector.Glyphs := []
        for index, char in chars {
            angle := center + direction * (cursor + widths[index] / 2) / sector.LabelRadius / 0.0174532925199433
            radians := angle * 0.0174532925199433
            x := sector.CX + sector.LabelRadius * Cos(radians), y := sector.CY + sector.LabelRadius * Sin(radians)
            rotation := Mod(angle + (direction = 1 ? 90 : -90) + 540, 360) - 180
            sector.Glyphs.Push({X: x, Y: y, Rotation: rotation})
            DllCall("gdiplus\GdipSaveGraphics", "ptr", g, "uint*", &saved := 0)
            DllCall("gdiplus\GdipTranslateWorldTransform", "ptr", g, "float", x, "float", y, "int", 0)
            DllCall("gdiplus\GdipRotateWorldTransform", "ptr", g, "float", rotation, "int", 0)
            DllCall("gdiplus\GdipDrawString", "ptr", g, "wstr", char, "int", StrLen(char), "ptr", font,
                "ptr", glyphRect, "ptr", arcFormat, "ptr", brush)
            DllCall("gdiplus\GdipRestoreGraphics", "ptr", g, "uint", saved)
            cursor += widths[index] + spacing
        }
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        DllCall("gdiplus\GdipDeleteFont", "ptr", font)
        DllCall("gdiplus\GdipDeleteFontFamily", "ptr", family)
        DllCall("gdiplus\GdipDeleteStringFormat", "ptr", arcFormat)
    }
    DrawIndicators(g, width) {
        x := width * this.DeviceNX, y := width * this.DeviceNY, k := width * .022
        if this.ShowDevice {
            pen := this.Pen(0x4D6B97, Max(1.3, width * .0025))
            DllCall("gdiplus\GdipDrawRectangle", "ptr", g, "ptr", pen, "float", x - k,
                "float", y - k * .8, "float", k * 2, "float", k * 1.35)
            this.Line(g, pen, x, y + k * .55, x, y + k * .95)
            this.Line(g, pen, x - k * .55, y + k * .95, x + k * .55, y + k * .95)
            directions := this.Owner.Shared ? [-1, 1] : [this.Owner.Role = "receiver" ? 1 : -1]
            for direction in directions {
                ax := x + (this.Owner.Shared ? direction * k * .38 : 0)
                this.Line(g, pen, ax, y - direction * k * .35, ax, y + direction * k * .25)
                this.Line(g, pen, ax, y + direction * k * .25, ax - k * .22, y - direction * k * .04)
                this.Line(g, pen, ax, y + direction * k * .25, ax + k * .22, y - direction * k * .04)
            }
            DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        }
        brush := this.Solid(this.Connected ? 0xD3F6E3 : 0xFFE0E6)
        this.FillCircle(g, brush, width * this.DotNX, width * this.DotNY, width * (this.ShowDevice ? .016 : .026))
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        brush := this.Solid(this.Connected ? 0x20AC70 : 0xE64B5D)
        this.FillCircle(g, brush, width * this.DotNX, width * this.DotNY, width * (this.ShowDevice ? .010 : .017))
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
    }
    Line(g, pen, x1, y1, x2, y2) {
        DllCall("gdiplus\GdipDrawLine", "ptr", g, "ptr", pen, "float", x1, "float", y1, "float", x2, "float", y2)
    }
    Triangle(g, brush, points) {
        data := Buffer(24)
        for index, point in points
            NumPut("float", point[1], "float", point[2], data, (index - 1) * 8)
        DllCall("gdiplus\GdipFillPolygon", "ptr", g, "ptr", brush, "ptr", data, "int", 3, "int", 0)
    }
    DrawIcon(g, action, x, y, k, color) {
        pen := this.Pen(color, Max(1.5, k * .15)), brush := this.Solid(color)
        switch action {
            case "back":
                this.Line(g, pen, x - k, y - k * .5, x + k * .2, y - k * .5)
                this.Line(g, pen, x - k, y - k * .5, x - k * .42, y - k)
                this.Line(g, pen, x - k, y - k * .5, x - k * .42, y + k * .05)
                DllCall("gdiplus\GdipDrawArc", "ptr", g, "ptr", pen, "float", x - k * .5,
                    "float", y - k * .5, "float", k * 1.5, "float", k * 1.4, "float", 270, "float", 250)
            case "replay":
                DllCall("gdiplus\GdipDrawRectangle", "ptr", g, "ptr", pen, "float", x - k * .45,
                    "float", y - k, "float", k * 1.3, "float", k * 1.4)
                DllCall("gdiplus\GdipDrawRectangle", "ptr", g, "ptr", pen, "float", x - k,
                    "float", y - k * .45, "float", k * 1.3, "float", k * 1.4)
            case "skip":
                this.Triangle(g, brush, [[x - k, y - k * .8], [x - k, y + k * .8], [x, y]])
                this.Triangle(g, brush, [[x, y - k * .8], [x, y + k * .8], [x + k, y]])
            case "new":
                this.Triangle(g, brush, [[x - k * .65, y - k], [x - k * .65, y + k], [x + k, y]])
            case "type":
                DllCall("gdiplus\GdipDrawRectangle", "ptr", g, "ptr", pen, "float", x - k * 1.15,
                    "float", y - k * .8, "float", k * 2.3, "float", k * 1.6)
                Loop 4 {
                    dx := x + (A_Index - 2.5) * k * .47
                    this.Line(g, pen, dx, y - k * .35, dx, y - k * .25)
                }
                this.Line(g, pen, x - k * .65, y + k * .3, x + k * .65, y + k * .3)
        }
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
    }
    Hover(wParam, lParam, msg, hwnd) {
        sector := this.FindSector(hwnd)
        next := (IsObject(sector) && sector.Control.Enabled) || this.IsMini(hwnd) ? hwnd : 0
        if this.IsMini(hwnd)
            this.ShowTooltip(hwnd = this.Appearance.Hwnd ? "外观：悬停展开、双尺寸与不透明度" : "最小化浮窗 · 托盘菜单可恢复")
        else if IsObject(sector) && this.Compact
            this.ShowTooltip(sector.Control.Text)
        else if hwnd = this.Gui.Hwnd {
            x := lParam & 0xFFFF, y := (lParam >> 16) & 0xFFFF
            WinGetClientPos(, , &width, , this.Gui.Hwnd)
            if Abs(x / width - this.DotNX) < .04 && Abs(y / width - this.DotNY) < .04
                || (this.ShowDevice && Abs(x / width - this.DeviceNX) < .04 && Abs(y / width - this.DeviceNY) < .04)
                this.ShowTooltip((this.Owner.Shared ? "双向共享队列" : (this.Owner.Role = "receiver" ? "接收端" : (this.Owner.Role = "sender" ? "发送端" : "本机"))) " · " this.LastStatus)
            else
                this.ClearTooltip()
        } else
            this.ClearTooltip()
        if next = this.HoverHwnd
            return
        old := this.HoverHwnd, this.HoverHwnd := next
        if old
            DllCall("InvalidateRect", "ptr", old, "ptr", 0, "int", false)
        if next {
            DllCall("InvalidateRect", "ptr", next, "ptr", 0, "int", false)
            track := Buffer(A_PtrSize = 8 ? 24 : 16, 0)
            NumPut("uint", track.Size, "uint", 2, "ptr", next, track)
            DllCall("TrackMouseEvent", "ptr", track)
        }
    }
    Leave(wParam, lParam, msg, hwnd) {
        if this.IsMini(hwnd) || IsObject(this.FindSector(hwnd))
            this.ClearTooltip()
        if hwnd = this.HoverHwnd {
            this.HoverHwnd := 0
            DllCall("InvalidateRect", "ptr", hwnd, "ptr", 0, "int", false)
        }
    }
    IsMini(hwnd) => hwnd = this.Appearance.Hwnd || hwnd = this.HideButton.Hwnd
    PaintTopButton(wParam, data, msg, hwnd) {
        control := NumGet(data, A_PtrSize = 8 ? 24 : 20, "ptr")
        if this.IsMini(control)
            return this.PaintMini(NumGet(data, A_PtrSize = 8 ? 32 : 24, "ptr"), control, NumGet(data, 16, "uint"))
    }
    PaintMini(dc, hwnd, state) {
        rect := Buffer(16)
        DllCall("GetClientRect", "ptr", hwnd, "ptr", rect)
        w := NumGet(rect, 8, "int"), h := NumGet(rect, 12, "int")
        canvas := this.Canvas(dc, w, h), g := this.Graphics(canvas.DC)
        fill := state & 1 ? 0xCADCF9 : (this.HoverHwnd = hwnd ? 0xE2EDFF : 0xFAFCFF)
        brush := this.Solid(fill)
        this.FillCircle(g, brush, w / 2, h / 2, w * .485)
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
        pen := this.Pen(0xBBD0F0, Max(1, w * .025))
        DllCall("gdiplus\GdipDrawEllipse", "ptr", g, "ptr", pen,
            "float", w * .03, "float", h * .03, "float", w * .94, "float", h * .94)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        x := w / 2, y := h / 2, k := w * .255
        pen := this.Pen(0x4A6A96, Max(1.2, w * .045))
        if hwnd = this.HideButton.Hwnd
            this.Line(g, pen, x - k * .72, y + k * .1, x + k * .72, y + k * .1)
        else {
            DllCall("gdiplus\GdipDrawEllipse", "ptr", g, "ptr", pen,
                "float", x - k, "float", y - k, "float", k * 2, "float", k * 1.8)
            brush := this.Solid(fill)
            this.FillCircle(g, brush, x + k * .65, y + k * .65, k * .44)
            DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
            for dot in [[-.48, -.3, 0xE8719A], [0, -.55, 0xEDB04C], [.48, -.25, 0x49B99D], [-.4, .3, 0x6593EB]] {
                brush := this.Solid(dot[3])
                this.FillCircle(g, brush, x + k * dot[1], y + k * dot[2], k * .15)
                DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
            }
        }
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
        DllCall("gdiplus\GdipDeleteGraphics", "ptr", g)
        this.FinishCanvas(dc, canvas, hwnd)
        return true
    }
    ShowTooltip(text) {
        if text = this.TooltipText
            return
        this.TooltipText := text
        ToolTip(text, , , 2)
        SetTimer(this.TooltipCallback, text = "" ? 0 : -2500)
    }
    ClearTooltip(*) {
        if this.TooltipText = ""
            return
        this.TooltipText := ""
        ToolTip(, , , 2)
        SetTimer(this.TooltipCallback, 0)
    }
    Drag(wParam, lParam, msg, hwnd) {
        if hwnd != this.Gui.Hwnd && hwnd != this.Position.Hwnd && hwnd != this.Mode.Hwnd
            && hwnd != this.Preview.Hwnd && hwnd != this.Last.Hwnd
            return
        DllCall("ReleaseCapture")
        PostMessage(0xA1, 2, 0, this.Gui.Hwnd)
    }
    OpenSettings(*) {
        this.Owner.OpenSettings(4)
    }
    CreateSettings(showWindow := true) {
        if IsObject(this.Settings) {
            if showWindow
                this.Settings.Show()
            return
        }
        this.Settings := Gui("+AlwaysOnTop +ToolWindow +Owner" this.Gui.Hwnd, "浮窗外观 · v2.3.4")
        this.Settings.MarginX := 20, this.Settings.MarginY := 12
        this.Settings.SetFont("s10", "Microsoft YaHei UI")
        this.AutoCheck := this.Settings.AddCheckbox("w330", "鼠标悬停展开，移开自动缩回")
        this.AutoCheck.Value := this.AutoExpand
        this.CollapsedLabel := this.Settings.AddText("xm y+12 w330", "")
        this.CollapsedSlider := this.Settings.AddSlider("xm y+4 w330 Range100-300 ToolTip", this.CollapsedDiameter)
        this.ExpandedLabel := this.Settings.AddText("xm y+10 w330", "")
        this.ExpandedSlider := this.Settings.AddSlider("xm y+4 w330 Range320-640 ToolTip", this.ExpandedDiameter)
        this.SizeLabel := this.Settings.AddText("xm y+10 w330", "")
        this.SizeSlider := this.Settings.AddSlider("xm y+4 w330 Range100-640 ToolTip", this.FixedDiameter)
        this.OpacityLabel := this.Settings.AddText("xm y+10 w330", "")
        this.OpacitySlider := this.Settings.AddSlider("xm y+4 w330 Range35-100 ToolTip", this.Opacity)
        this.Settings.AddText("xm y+10 w330 h64 c526681", "停留约 0.2 秒展开，离开约 0.7 秒缩回。`n拖动内圆移动；展开尺寸至少 320 以显示文字。`n更改立即保存；屏幕空间不足时临时缩小。")
        reset := this.Settings.AddButton("xm y+8 w155 h32", "恢复默认外观")
        done := this.Settings.AddButton("x+20 yp w155 h32 Default", "完成")
        for control in [this.AutoCheck, this.CollapsedSlider, this.ExpandedSlider, this.SizeSlider, this.OpacitySlider]
            control.OnEvent(control = this.AutoCheck ? "Click" : "Change", ObjBindMethod(this, "SettingsChanged"))
        reset.OnEvent("Click", ObjBindMethod(this, "ResetAppearance"))
        done.OnEvent("Click", ObjBindMethod(this, "CloseSettings"))
        this.Settings.OnEvent("Close", ObjBindMethod(this, "CloseSettings"))
        this.Settings.OnEvent("Escape", ObjBindMethod(this, "CloseSettings"))
        this.UpdateSettingLabels()
        if showWindow {
            this.Settings.Show("AutoSize")
            this.ClampSettings()
        }
    }
    SettingsChanged(control := 0, *) {
        this.AutoExpand := !!this.AutoCheck.Value
        this.CollapsedDiameter := this.CollapsedSlider.Value
        this.ExpandedDiameter := this.ExpandedSlider.Value
        ; Preview the size being adjusted. Settings keep the preview stable.
        if control = this.CollapsedSlider
            this.Expanded := false
        else if control = this.ExpandedSlider
            this.Expanded := true
        this.PointerSince := 0, this.LeaveSince := 0
        this.ApplyAppearance(this.SizeSlider.Value, this.OpacitySlider.Value)
        this.UpdateSettingLabels()
    }
    ResetAppearance(*) {
        this.AutoCheck.Value := 1, this.CollapsedSlider.Value := 120, this.ExpandedSlider.Value := 420
        this.SizeSlider.Value := 460, this.OpacitySlider.Value := 95
        this.Expanded := false
        this.SettingsChanged()
    }
    UpdateSettingLabels() {
        this.CollapsedLabel.Text := "收起直径：" this.CollapsedDiameter "（100–300）"
        this.ExpandedLabel.Text := "展开直径：" this.ExpandedDiameter "（320–640）"
        this.SizeLabel.Text := "关闭自动展开时的直径：" this.FixedDiameter
        this.OpacityLabel.Text := "不透明度：" this.Opacity "%（35–100%）"
        this.SizeSlider.Enabled := !this.AutoExpand
        this.CollapsedSlider.Enabled := this.AutoExpand, this.ExpandedSlider.Enabled := this.AutoExpand
    }
    ApplyAppearance(diameter, opacity) {
        this.FixedDiameter := Max(100, Min(640, Round(diameter)))
        this.Opacity := Max(35, Min(100, Round(opacity)))
        this.Reflow()
        if this.Owner.ConfigPath != "" {
            try {
                IniWrite(this.FixedDiameter, this.Owner.ConfigPath, "Panel", "Diameter")
                IniWrite(this.Opacity, this.Owner.ConfigPath, "Panel", "Opacity")
                IniWrite(this.AutoExpand, this.Owner.ConfigPath, "Panel", "AutoExpand")
                IniWrite(this.CollapsedDiameter, this.Owner.ConfigPath, "Panel", "CollapsedDiameter")
                IniWrite(this.ExpandedDiameter, this.Owner.ConfigPath, "Panel", "ExpandedDiameter")
            }
        }
    }
    DesiredDiameter() => this.AutoExpand ? (this.Expanded ? this.ExpandedDiameter : this.CollapsedDiameter) : this.FixedDiameter
    SetExpanded(expanded) {
        if !this.AutoExpand || this.Expanded = expanded
            return
        if expanded {
            WinGetPos(&x, &y, &w, &h, this.Gui.Hwnd)
            this.HoverOrigin := {X: x + w / 2, Y: y + h / 2, Radius: w / 2}
        } else
            this.HoverOrigin := 0
        this.Expanded := expanded
        this.PointerSince := 0, this.LeaveSince := 0
        this.ClearTooltip()
        this.Reflow()
    }
    WorkArea(x, y) {
        rect := Buffer(16, 0)
        NumPut("int", Round(x), "int", Round(y), "int", Round(x) + 1, "int", Round(y) + 1, rect)
        monitor := DllCall("MonitorFromRect", "ptr", rect, "uint", 2, "ptr")
        info := Buffer(40, 0)
        NumPut("uint", 40, info)
        if !DllCall("GetMonitorInfo", "ptr", monitor, "ptr", info)
            throw Error("无法读取显示器工作区")
        return {L: NumGet(info, 20, "int"), T: NumGet(info, 24, "int"),
            R: NumGet(info, 28, "int"), B: NumGet(info, 32, "int"), Monitor: monitor}
    }
    FitGeometry(area, diameter, dpi, cx, cy) {
        margin := 8
        available := Max(1, Min(area.R - area.L, area.B - area.T) - margin * 2)
        logical := Min(diameter, Max(1, Floor(available * 96 / dpi)))
        pixels := Round(logical * dpi / 96)
        x := Max(area.L + margin, Min(Round(cx - pixels / 2), area.R - margin - pixels))
        y := Max(area.T + margin, Min(Round(cy - pixels / 2), area.B - margin - pixels))
        return {Diameter: logical, Pixels: pixels, X: x, Y: y}
    }
    InitializeAnchor() {
        if this.AnchorReady
            return
        MonitorGetWorkArea(MonitorGetPrimary(), &left, &top, &right, &bottom)
        small := (this.AutoExpand ? this.CollapsedDiameter : this.FixedDiameter) * this.Dpi / 96
        this.AnchorX := right - small / 2 - 16, this.AnchorY := bottom - small / 2 - 16
        try {
            sx := IniRead(this.Owner.ConfigPath, "Panel", "X", "")
            sy := IniRead(this.Owner.ConfigPath, "Panel", "Y", "")
            if IsNumber(sx) && IsNumber(sy)
                this.AnchorX := sx + small / 2, this.AnchorY := sy + small / 2
        }
        this.AnchorReady := true
    }
    Reflow(*) {
        if this.Disposed || this.Resizing || this.LayoutBusy
            return
        this.Resizing := true
        try {
            this.InitializeAnchor()
            area := this.WorkArea(this.AnchorX, this.AnchorY)
            ; Repair anchors left behind by unplugged monitors; keep edge anchors
            ; stable while expanding so shrinking returns to the same resting spot.
            resting := this.FitGeometry(area, this.AutoExpand ? this.CollapsedDiameter : this.FixedDiameter,
                this.Dpi, this.AnchorX, this.AnchorY)
            this.AnchorX := resting.X + resting.Pixels / 2
            this.AnchorY := resting.Y + resting.Pixels / 2
            geometry := this.FitGeometry(area, this.DesiredDiameter(), this.Dpi, this.AnchorX, this.AnchorY)
            this.Diameter := geometry.Diameter
            this.Layout()
            this.Gui.Move(geometry.X, geometry.Y, geometry.Pixels, geometry.Pixels)
            this.ApplyRegion()
            WinSetTransparent(Round(this.Opacity * 255 / 100), this.Gui.Hwnd)
            this.EnvironmentDirty := false
        } finally {
            this.Resizing := false
        }
        this.Refresh()
    }
    PointerInside() {
        point := Buffer(8, 0)
        DllCall("GetCursorPos", "ptr", point)
        hwnd := DllCall("WindowFromPoint", "int64", NumGet(point, 0, "int64"), "ptr")
        if hwnd = this.Gui.Hwnd || DllCall("IsChild", "ptr", this.Gui.Hwnd, "ptr", hwnd)
            return true
        ; At a screen corner, fitting the expanded circle can move it away from
        ; the pointer. Keep the original resting circle in the hover group.
        if this.Expanded && IsObject(this.HoverOrigin) {
            dx := NumGet(point, 0, "int") - this.HoverOrigin.X
            dy := NumGet(point, 4, "int") - this.HoverOrigin.Y
            return dx * dx + dy * dy <= this.HoverOrigin.Radius ** 2
        }
        return false
    }
    HoverStep(inside, now, frozen := false) {
        if !this.AutoExpand || !this.Visible || frozen {
            this.PointerSince := 0, this.LeaveSince := 0
            return
        }
        if inside {
            this.LeaveSince := 0
            if !this.PointerSince
                this.PointerSince := now
            if !this.Expanded && now - this.PointerSince >= 180
                this.SetExpanded(true)
        } else {
            this.PointerSince := 0
            if !this.LeaveSince
                this.LeaveSince := now
            if this.Expanded && now - this.LeaveSince >= 650
                this.SetExpanded(false)
        }
    }
    EnvironmentTick(*) {
        if this.Disposed || !this.Visible || this.LayoutBusy || this.Resizing
            return
        frozen := this.Dragging || this.Owner.Busy || IsObject(this.Settings)
            || (DllCall("GetAsyncKeyState", "int", 1, "short") & 0x8000)
            || (DllCall("GetAsyncKeyState", "int", 2, "short") & 0x8000)
        if !frozen && (this.EnvironmentDirty || A_TickCount - this.LastEnvironmentCheck >= 1000) {
            this.LastEnvironmentCheck := A_TickCount
            area := this.WorkArea(this.AnchorX, this.AnchorY)
            dpi := DllCall("GetDpiForWindow", "ptr", this.Gui.Hwnd, "uint")
            if dpi
                this.Dpi := dpi
            key := area.Monitor "|" area.L "|" area.T "|" area.R "|" area.B "|" this.Dpi
            if this.EnvironmentDirty || key != this.EnvironmentKey {
                this.EnvironmentKey := key
                this.Reflow()
            }
        }
        this.HoverStep(this.PointerInside(), A_TickCount, frozen)
    }
    DisplayChanged(wParam, lParam, msg, hwnd) {
        if this.Disposed
            return
        if msg = 0x2E0 {
            if hwnd != this.Gui.Hwnd
                return
            this.Dpi := wParam & 0xFFFF
            this.EnvironmentDirty := true
            return 0
        }
        this.EnvironmentDirty := true
        if IsObject(this.Settings)
            this.ClampSettings()
    }
    MoveChanged(wParam, lParam, msg, hwnd) {
        if hwnd != this.Gui.Hwnd
            return
        this.Dragging := msg = 0x231
        this.PointerSince := 0, this.LeaveSince := 0
        if !this.Dragging {
            WinGetPos(&x, &y, &w, &h, this.Gui.Hwnd)
            this.AnchorX := x + w / 2, this.AnchorY := y + h / 2
            this.AnchorReady := true, this.EnvironmentDirty := true
            this.SavePosition()
        }
    }
    ClampSettings() {
        if !IsObject(this.Settings)
            return
        WinGetPos(&x, &y, &w, &h, this.Settings.Hwnd)
        area := this.WorkArea(x + w / 2, y + h / 2)
        this.Settings.Move(Max(area.L, Min(x, area.R - w)), Max(area.T, Min(y, area.B - h)))
    }
    CloseSettings(*) {
        if !IsObject(this.Settings)
            return
        settings := this.Settings
        this.Settings := 0
        wasActive := WinActive("ahk_id " settings.Hwnd)
        settings.Destroy()
        if wasActive && this.LastTarget && WinExist("ahk_id " this.LastTarget)
            try WinActivate("ahk_id " this.LastTarget)
    }
    NoActivate(wParam, lParam, msg, hwnd) {
        if hwnd = this.Gui.Hwnd || DllCall("IsChild", "ptr", this.Gui.Hwnd, "ptr", hwnd)
            return 3  ; MA_NOACTIVATE: keep the business application's caret active.
    }
    Show(*) {
        this.Expanded := false
        this.HoverOrigin := 0
        this.PointerSince := 0, this.LeaveSince := 0
        this.Reflow()
        pixels := Round(this.Diameter * this.Dpi / 96)
        this.Gui.Show("NA w" pixels " h" pixels)
        this.Visible := true
        this.EnvironmentDirty := true
        this.Refresh()
    }
    Hide(*) {
        this.ClearTooltip()
        this.SavePosition()
        this.Gui.Hide()
        this.Visible := false
        this.SaveVisible()
    }
    Toggle(*) {
        if this.Visible
            this.Hide()
        else {
            this.Show()
            this.SaveVisible()
        }
    }
    SaveVisible() {
        if this.Owner.ConfigPath = ""
            return
        try IniWrite(this.Visible ? 1 : 0, this.Owner.ConfigPath, "Panel", "Visible")
    }
    SavePosition() {
        if !this.Visible || this.Owner.ConfigPath = ""
            return
        try {
            this.InitializeAnchor()
            small := (this.AutoExpand ? this.CollapsedDiameter : this.FixedDiameter) * this.Dpi / 96
            x := Round(this.AnchorX - small / 2), y := Round(this.AnchorY - small / 2)
            IniWrite(x, this.Owner.ConfigPath, "Panel", "X")
            IniWrite(y, this.Owner.ConfigPath, "Panel", "Y")
        }
    }
    PreviewText(text, length := 92) {
        text := StrReplace(StrReplace(StrReplace(text, "`r", ""), "`n", " ↵ "), "`t", " ⇥ ")
        return StrLen(text) > length ? SubStr(text, 1, length) "…" : text
    }
    SetText(control, text) {
        if control.Text !== text
            control.Text := text
    }
    Refresh(*) {
        if this.Disposed || this.LayoutBusy
            return
        owner := this.Owner
        active := WinExist("A")
        if active && active != this.Gui.Hwnd && (!IsObject(this.Settings) || active != this.Settings.Hwnd) && !this.Owner.IsSettingsWindow(active) {
            this.LastTarget := active
            info := Buffer(A_PtrSize = 8 ? 72 : 48, 0)
            NumPut("uint", info.Size, info)
            if DllCall("GetGUIThreadInfo", "uint", 0, "ptr", info)
                this.LastControl := NumGet(info, 8 + A_PtrSize, "ptr")
        }
        count := owner.Queue.Length
        if !owner.Enabled {
            position := "顺序功能已关闭"
            mode := "Ctrl+V 普通粘贴"
            preview := "仍可手动逐字输入`nCtrl+Alt+S 开启队列"
        } else if owner.Shared && SQ.NativeMode {
            position := "旧队列已暂停"
            mode := "Ctrl+V 普通粘贴新内容"
            preview := "图片、文件、表格保留原格式`n重新复制文本开始新批次"
        } else if count = 0 {
            position := owner.Shared ? "等待两端复制内容" : (owner.Role = "receiver" ? "等待接收新队列" : "等待复制内容")
            mode := "连续复制两份启用队列"
            preview := "≤" (owner.AutoNumber?owner.NumericTypingMaxDigits:0) "位数字自动输入`n表格整块粘贴"
        } else if owner.Index > count {
            position := "已完成 " count " 条"
            mode := "Ctrl+V 已恢复普通处理"
            preview := "可回退或重贴`n新批次请重新复制"
        } else {
            position := "下一条 " owner.Index " / " count
            mode := owner.IsImage(owner.Index) ? (owner.AdvancesAutomatically()?"图片 · 发送后推进":"图片 · 手动推进") : count = 1 ? "单条 · 当前剪贴板"
                : (owner.IsShortNumber(owner.Queue[owner.Index]) ? "短数字 · 逐字输入" : "整条直接粘贴")
            preview := owner.IsImage(owner.Index) ? "图片 · Ctrl+V 发送`n可跨电脑接着粘贴" : this.PreviewText(owner.Queue[owner.Index], this.Diameter // 17)
        }

        if owner.Enabled && owner.HasPending() && !owner.AdvancesAutomatically()
            mode := "手动推进 · 点跳过前进"
        if !owner.QueuePaste
            mode := "本机 Ctrl+V 设为普通粘贴"
        if this.Compact {
            shortCount := count < 1000 ? count : Round(count / 1000, 1) "k"
            shortIndex := owner.Index < 1000 ? owner.Index : Round(owner.Index / 1000, 1) "k"
            position := !owner.Enabled ? "已关闭" : (count = 0 ? "等待中" : (owner.Index > count ? "完成" : shortIndex "/" shortCount))
            if owner.Shared && owner.Enabled && SQ.NativeMode
                position := "普通粘贴"
        }
        if owner.Shared {
            if SQ.LeaseToken != "" {
                mode := SQ.LeaseOwner = SQ.Node ? (owner.Busy ? "正在输出并同步进度" : "待确认上次输出 · 托盘菜单") : "另一台正在输出 / 待确认"
                if this.Compact && !owner.Busy
                    position := SQ.LeaseOwner = SQ.Node ? "待确认" : "占用中"
            } else if SQ.PendingCopies > 0
                mode := "待同步复制：" SQ.PendingCopies " 条"
        }
        this.SetText(this.Position, position)
        this.SetText(this.Mode, mode)
        this.SetText(this.Preview, preview)
        last := IsObject(owner.LastOutput) ? "上次" (owner.LastOutput.HasOwnProp("Image") && owner.LastOutput.Image ? "图片" : "输出") " #" owner.LastOutput.ItemIndex
            : "暂无输出记录"
        this.SetText(this.Last, last)
        this.Bar.Value := count ? Min(100, Max(0, (owner.Index - 1) * 100 // count)) : 0
        if this.LastProgress != this.Bar.Value {
            this.LastProgress := this.Bar.Value
            DllCall("InvalidateRect", "ptr", this.Gui.Hwnd, "ptr", 0, "int", true)
        }
        this.Back.Enabled := owner.Enabled && (!owner.Shared || !SQ.NativeMode) && !owner.Busy && count > 0 && owner.Index > 1
        this.Replay.Enabled := owner.CanReplay()
        this.Skip.Enabled := !owner.Busy && owner.HasPending()
        this.New.Enabled := !owner.Busy
        this.Type.Enabled := !owner.Busy
        if owner.Shared && SQ.LeaseToken != "" {
            for control in [this.Back, this.Replay, this.Skip, this.New]
                control.Enabled := false
            if owner.Enabled
                this.Type.Enabled := false
        }
        status := owner.Role = "local" ? "本机模式" : "连接助手启动中"
        color := "64748B", connected := owner.Role = "local"
        if owner.Role != "local" && owner.StateDir != "" {
            try {
                raw := FileRead(owner.StateDir "\bridge-status.txt", "UTF-8")
                if RegExMatch(raw, "^CONNECTED(?:\s|$)") || InStr(raw, "DELIVERED")
                    status := "连接正常", color := "16704A", connected := true
                else if InStr(raw, "LISTENING") || InStr(raw, "WAIT_PEER")
                    status := owner.Shared ? "等待另一台连接" : "等待发送端", color := "365B8C"
                else if InStr(raw, "VERSION")
                    status := "请更新另一台至 v2.3.4 / 检查连接", color := "B42318"
                else if InStr(raw, "AUTH_FAILED")
                    status := "配对错误", color := "B42318"
                else if InStr(raw, "NOT_CONFIGURED")
                    status := "未配置地址", color := "9A6700"
                else
                    status := "连接重试中", color := "9A6700"
            }
        }
        if owner.Role = "sender" && owner.StateDir != "" && !owner.Shared {
            try {
                f := StrSplit(Trim(FileRead(owner.StateDir "\peer-receipt.txt", "UTF-8"), "`r`n"), "`n", "`r")
                if f.Length >= 7 && f[2] = owner.Session && f[3] = owner.Batch
                    status .= " · 对端进度 " Min(Integer(f[5]) - 1, Integer(f[6])) "/" f[6]
            }
        }
        if owner.Shared && connected && !SQ.Connected {
            connected := false
            status := "共享连接待确认"
        }
        if status != this.LastStatus || connected != this.Connected {
            this.Connection.SetFont("c" color)
            this.SetText(this.Connection, "● " status)
            this.LastStatus := status
            this.Connected := connected
            DllCall("InvalidateRect", "ptr", this.Gui.Hwnd, "ptr", 0, "int", true)
        }
    }
    EnsureInputTarget() {
        active := WinExist("A")
        if active = this.Gui.Hwnd || (IsObject(this.Settings) && active = this.Settings.Hwnd) || this.Owner.IsSettingsWindow(active) {
            if !this.LastTarget || !WinExist("ahk_id " this.LastTarget)
                return false
            try {
                WinActivate("ahk_id " this.LastTarget)
                if !WinWaitActive("ahk_id " this.LastTarget, , 1)
                    return false
                if this.LastControl && DllCall("IsWindow", "ptr", this.LastControl)
                    && (this.LastControl = this.LastTarget || DllCall("IsChild", "ptr", this.LastTarget, "ptr", this.LastControl))
                    ControlFocus(this.LastControl)
                active := this.LastTarget
            } catch {
                return false
            }
        }
        if !active
            return false
        ; Do not type into this script's diagnostic window or modal status dialog.
        if WinGetPID("ahk_id " active) = DllCall("GetCurrentProcessId", "uint")
            && (WinGetClass("ahk_id " active) = "AutoHotkey" || WinGetClass("ahk_id " active) = "#32770")
            return false
        return true
    }
    Perform(action, *) {
        ; A click on the resting widget opens it first; it cannot clear a batch
        ; accidentally during the dwell interval or after a drag.
        if this.AutoExpand && !this.Expanded {
            this.SetExpanded(true)
            return
        }
        if this.Owner.Busy
            return
        switch action {
            case "back": this.Owner.BackOne()
            case "skip": this.Owner.SkipOne()
            case "new": this.Owner.NewBatch()
            case "type":
                if !this.EnsureInputTarget() {
                    this.Owner.Tip("请先点击目标输入框，再点逐字输入", 3500)
                    return
                }
                this.Owner.Type()
            case "replay":
                if !this.EnsureInputTarget() {
                    this.Owner.Tip("请先点击要接收内容的输入框，再点重贴上一条", 3500)
                    return
                }
                this.Owner.ReplayLast()
        }
        this.Refresh()
    }
    Dispose() {
        if this.Disposed
            return
        this.Disposed := true
        this.ClearTooltip()
        SetTimer(this.RefreshCallback, 0)
        SetTimer(this.EnvironmentCallback, 0)
        OnMessage(0x7E, this.DisplayCallback, 0)
        OnMessage(0x1A, this.DisplayCallback, 0)
        OnMessage(0x2E0, this.DisplayCallback, 0)
        OnMessage(0x231, this.MoveCallback, 0)
        OnMessage(0x232, this.MoveCallback, 0)
        OnMessage(0x21, this.ActivationCallback, 0)
        OnMessage(0x14, this.PaintCallback, 0)
        OnMessage(0x2B, this.ButtonCallback, 0)
        OnMessage(0x201, this.DragCallback, 0)
        OnMessage(0x200, this.HoverCallback, 0)
        OnMessage(0x2A3, this.LeaveCallback, 0)
        if IsObject(this.Settings)
            this.Settings.Destroy()
        this.SavePosition()
        this.SaveVisible()
        for button in [this.Back, this.Replay, this.Skip, this.New, this.Type, this.Appearance, this.HideButton]
            DllCall("comctl32\RemoveWindowSubclass", "ptr", button.Hwnd, "ptr", this.SubclassProc, "uptr", 1)
        CallbackFree(this.SubclassProc)
        this.ClearSectorPaths()
        this.Gui.Destroy()
        if this.GdipToken {
            DllCall("gdiplus\GdiplusShutdown", "ptr", this.GdipToken)
            this.GdipToken := 0
        }
        if this.GdipLibrary {
            DllCall("FreeLibrary", "ptr", this.GdipLibrary)
            this.GdipLibrary := 0
        }
    }
}
