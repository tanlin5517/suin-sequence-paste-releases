﻿#Requires AutoHotkey v2.0
; Shared desktop adapter. Only an explicit hotkey/button may emit text;
; receipt polling and restart recovery NEVER emit output.
class SQ {
    static Owner := 0, Epoch := "", Revision := 0, Node := "", Sequence := 0
    static LeaseToken := "", LeaseOwner := "", LeaseKind := "", LeaseText := "", LeaseTyped := false
    static Pending := Map(), LastView := "", PendingCopies := 0, Connected := false
    static BatchContinue := false, AutoAdvance := true, IdleSeconds := 300
    static NativeMode := false
    static LeaseImage := false, PendingImages := Map()
    static Init(owner) {
        this.Owner := owner
        for name in ["shared-requests", "shared-results", "shared-rejected"]
            DirCreate(owner.StateDir "\" name)
        nodePath := owner.StateDir "\shared-node.txt"
        if !FileExist(nodePath)
            owner.AtomicWrite(nodePath, StrLower(Trim(owner.Guid(), "{}")))
        this.Node := Trim(FileRead(nodePath, "UTF-8"))
        try this.Sequence := Integer(FileRead(owner.StateDir "\shared-counter.txt", "UTF-8"))
        for folder in ["shared-requests", "shared-results"] {
            Loop Files owner.StateDir "\" folder "\*.*" {
                if !RegExMatch(A_LoopFileName, "^(\d+)\.(req|res)$", &match)
                    continue
                id := Integer(match[1])
                this.Sequence := Max(this.Sequence, id)
                kind := "RECOVERED"
                if folder = "shared-requests" {
                    try {
                        raw := FileRead(A_LoopFileFullPath,"UTF-8"), fields := StrSplit(raw,"`n","`r")
                        if fields.Length = 10 && RegExMatch(fields[1],"^SQCMD[234]$")
                            owner.AtomicWrite(A_LoopFileFullPath,RegExReplace(raw,"^SQCMD[234]","SQCMD5"))
                        kind := fields[3]
                    }
                }
                this.Pending[id] := kind
            }
        }
        this.CountPending()
        this.Poll()
    }
    static ResponsePath(id) => this.Owner.StateDir "\shared-results\" Format("{:020}", id) ".res"
    static Decode(value) => value = "" ? "" : this.Owner.Decode(value)
    static Submit(kind, text := "", token := "", typed := false) {
        this.Sequence++
        id := this.Sequence
        this.Owner.AtomicWrite(this.Owner.StateDir "\shared-counter.txt", id)
        deadline := (kind = "APPEND" || kind = "APPEND_IMAGE" || kind = "NATIVE" || kind = "COMMIT" || kind = "ABORT" || kind = "RESOLVE" || kind = "POLL")
            ? 0 : DateDiff(A_NowUTC, "19700101000000", "Seconds") + 5
        command := "SQCMD5`n" id "`n" kind "`n" this.Epoch "`n" this.Owner.Batch "`n" this.Revision
            . "`n" token "`n" (typed ? 1 : 0) "`n" this.Owner.Encode(text) "`n" deadline
        this.Owner.AtomicWrite(this.Owner.StateDir "\shared-requests\" Format("{:020}", id) ".req", command)
        this.Pending[id] := kind
        this.CountPending()
        return id
    }
    static ReadResult(id) {
        path := this.ResponsePath(id)
        if !FileExist(path)
            return 0
        fields := StrSplit(FileRead(path, "UTF-8"), "`n", "`r")
        if fields.Length != 4 || !RegExMatch(fields[1],"^SQRES[2345]$") || Integer(fields[2]) != id
            throw Error("共享操作回执无效")
        this.Apply(this.Owner.Decode(fields[4]))
        FileDelete(path)
        if this.Pending.Has(id)
            this.Pending.Delete(id)
        this.CountPending()
        return {Code: fields[3]}
    }
    static Request(kind, text := "", token := "", typed := false) {
        id := this.Submit(kind, text, token, typed)
        started := A_TickCount
        while A_TickCount - started < 3800 {
            if IsObject(result := this.ReadResult(id))
                return result
            Sleep(20)
        }
        return {Code: "PENDING"}
    }
    static CountPending() {
        this.PendingCopies := 0, this.PendingImages := Map()
        for id, kind in this.Pending {
            if kind = "APPEND" || kind = "APPEND_IMAGE"
                this.PendingCopies++
            if kind = "APPEND_IMAGE" {
                try {
                    f := StrSplit(FileRead(this.Owner.StateDir "\shared-requests\" Format("{:020}",id) ".req","UTF-8"),"`n","`r")
                    this.PendingImages[this.Owner.Decode(f[9])] := true
                }
            }
        }
    }
    static Apply(snapshot) {
        ; On-disk v2/v3 recovery only; the network itself refuses old protocols.
        old := StrSplit(snapshot,"`n","`r")
        if old.Length >= 15 && (old[1] = "SQSTATE2" || old[1] = "SQSTATE3") {
            oldCount := Integer(old[6])
            if oldCount < 0 || oldCount > 500 || old.Length != oldCount + (old[1]="SQSTATE2"?15:17)
                throw Error("旧共享状态长度无效")
            migrated := "SQSTATE4"
            Loop oldCount + 14
                migrated .= "`n" old[A_Index+1]
            migrated .= "`n" this.Owner.Encode(";0;0") "`n" (old[1]="SQSTATE2"?"1`n0":old[oldCount+16] "`n" old[oldCount+17])
            snapshot := migrated
        }
        old := StrSplit(snapshot,"`n","`r")
        if old[1]="SQSTATE4" && old.Length>=18 {
            oldCount := Integer(old[6])
            if oldCount<0 || oldCount>500 || old.Length!=oldCount+18
                throw Error("旧共享状态长度无效")
            old[1] := "SQSTATE5"
            old[oldCount+16] := this.Owner.Encode(this.Owner.Decode(old[oldCount+16]) ";0;1;" this.Owner.TimeoutMs//1000)
            snapshot := ""
            for part in old
                snapshot .= (A_Index=1?"":"`n") part
        }
        f := StrSplit(snapshot, "`n", "`r")
        if f.Length < 15 || f[1] != "SQSTATE5"
            throw Error("共享状态格式无效")
        revision := Integer(f[3]), index := Integer(f[5]), count := Integer(f[6])
        if count < 0 || count > 500 || f.Length != count + 18 || index < 1 || index > count + 1
            throw Error("共享状态条数无效")
        if !RegExMatch(f[count + 17] f[count + 18], "^[01]{2}$")
            throw Error("共享开关状态无效")
        if f[2] = this.Epoch && revision < this.Revision
            return
        queue := [], total := 0
        Loop count {
            value := this.Owner.Decode(f[A_Index + 15])
            total += StrLen(value)
            if value = "" || StrLen(value) > 100000 || total > 500000
                throw Error("共享条目无效")
            queue.Push(value)
        }
        meta := StrSplit(this.Owner.Decode(f[count+16]),";")
        if meta.Length != 6 || !RegExMatch(meta[2] meta[3] meta[4] meta[5],"^[01]{4}$") || !RegExMatch(meta[6],"^\d+$") || Integer(meta[6])>86400
            throw Error("图文类型状态无效")
        images := Map()
        if meta[1] != "" {
            for value in StrSplit(meta[1],",") {
                if !RegExMatch(value,"^[0-9]+$") || Integer(value)<1 || Integer(value)>count || images.Has(Integer(value))
                    throw Error("图片条目编号无效")
                images[Integer(value)] := true
                ImageClipboard.Path(this.Owner.StateDir,queue[Integer(value)])
            }
        }
        last := this.Decode(f[9]), leaseText := this.Decode(f[15])
        if meta[2] = "1"
            ImageClipboard.Path(this.Owner.StateDir,last)
        if meta[3] = "1"
            ImageClipboard.Path(this.Owner.StateDir,leaseText)
        this.BatchContinue := meta[4]="1", this.AutoAdvance := meta[5]="1", this.IdleSeconds := Integer(meta[6])
        this.Epoch := f[2], this.Revision := revision
        this.Owner.Batch := f[4], this.Owner.Queue := queue, this.Owner.Index := index
        this.Owner.ImageIndexes := images, this.LeaseImage := meta[3] = "1"
        this.Owner.Enabled := f[count + 17] = "1", this.NativeMode := f[count + 18] = "1"
        this.LeaseToken := f[10], this.LeaseOwner := f[11], this.LeaseKind := f[12]
        this.LeaseText := leaseText, this.LeaseTyped := f[14] = "1"
        this.Owner.LastOutput := last = "" ? 0 : {Text: last, Typed: f[8] = "1", Image:meta[2]="1",
            ItemIndex: Integer(f[7]), BatchKey: this.Epoch "|" this.Owner.Batch}
    }
    static Poll() {
        try {
            path := this.Owner.StateDir "\shared-view.txt"
            if FileExist(path) {
                snapshot := FileRead(path, "UTF-8")
                if snapshot !== this.LastView {
                    this.Apply(snapshot)
                    this.LastView := snapshot
                }
            }
            for id, kind in this.Pending.Clone() {
                result := this.ReadResult(id)
                if !IsObject(result)
                    continue
                if result.Code = "GRANTED"
                    this.Owner.Tip("上次未完成输出的条目仍被保留，请从托盘选择“确认未完成的粘贴”", 6000)
                else if result.Code = "OK" && (kind = "COMMIT" || kind = "RESOLVE") {
                    this.Owner.LastError := ""
                    try FileDelete(this.Owner.StateDir "\shared-output-journal.txt")
                }
                else if result.Code != "OK" && result.Code != "STATE"
                    this.Warn(result.Code)
            }
        } catch as err {
            this.Owner.LastError := "共享状态读取失败：" err.Message
        }
        this.Connected := false
        try this.Connected := RegExMatch(FileRead(this.Owner.StateDir "\bridge-status.txt", "UTF-8"), "^CONNECTED(?:\s|$)") > 0
        if !SP_TestMode && this.Owner.BridgePid && !ProcessExist(this.Owner.BridgePid) {
            this.Connected := false
            this.Owner.LastError := "共享助手已退出，请查看状态目录中的 bridge-error.txt"
        }
    }
    static CopyText(text) {
        if StrLen(text) > 100000
            throw Error("每条最多 10 万字符")
        pendingChars := StrLen(text), pendingCount := 0
        Loop Files this.Owner.StateDir "\shared-requests\*.req" {
            f := StrSplit(FileRead(A_LoopFileFullPath, "UTF-8"), "`n", "`r")
            if f.Length = 10 && f[3] = "APPEND"
                pendingCount++, pendingChars += StrLen(this.Owner.Decode(f[9]))
        }
        if pendingCount >= 500 || pendingChars > 500000
            throw Error("待同步复制已达 500 条 / 50 万字符，请先恢复连接")
        this.Submit("APPEND", text)
        this.Owner.Tip(this.Connected ? "已采集，正在同步共享队列" : "已暂存复制，恢复连接后按顺序同步")
    }
    static CopyImage(reference) {
        ImageClipboard.Path(this.Owner.StateDir,reference)
        if this.PendingCopies >= 500
            throw Error("待同步条目已满，请先恢复连接")
        this.Submit("APPEND_IMAGE",reference)
    }
    static Warn(code) {
        switch code {
            case "STALE": message := "另一台刚更新了队列，已刷新状态；请确认后再操作"
            case "BUSY": message := "当前条目正在输出或等待确认；请稍后，勿重复粘贴"
            case "OWNER_OUTPUT_PENDING": message := "请先确认上次粘贴；这次复制原文已保存在状态目录 shared-rejected"
            case "OFFLINE": message := "对端未连接，共享进度暂停；Ctrl+V 可普通粘贴当前剪贴板"
            case "PENDING": message := "操作结果尚未确认，请勿重复操作；恢复连接后会同步，绝不自动重贴"
            case "EXPIRED": message := "操作等待过久已取消，请恢复连接后重新操作"
            case "EPOCH_CHANGED": message := "协调端状态已更换，旧操作未执行；请核对队列后重新复制"
            case "QUEUE_LIMIT": message := "共享队列已满；本次原文已保存在状态目录 shared-rejected"
            case "NOT_OWNER": message := "此输出已处理或需要在发起粘贴的电脑上确认"
            case "OLD_OPERATION", "SEQUENCE_REUSE": message := "操作编号异常，已阻止重复执行；请查看共享状态"
            case "EMPTY": message := "没有可操作的共享队列条目"
            case "DISABLED": message := "两端顺序增强已关闭，使用普通复制粘贴"
            case "NATIVE": message := "新复制内容优先，旧队列暂停；请重新复制文本开始新批次"
            case "IMAGE_NOT_TEXT": message := "下一条是图片，请用 Ctrl+V；图片不能逐字输入"
            case "INVALID_IMAGE": message := "图片数据无效，未加入队列"
            case "IMAGE_UNAVAILABLE": message := "图片缺失或校验失败，未发送动作；可重新复制或跳过该条"
            default: message := "共享操作未完成：" code
        }
        this.Owner.LastError := message
        this.Owner.Tip(message, 6000)
    }
    static Control(kind) {
        owner := this.Owner
        if owner.Busy
            return false
        this.Poll()
        owner.Busy := true
        try {
            result := this.Request(kind)
            if result.Code != "OK" {
                this.Warn(result.Code)
                return false
            }
            owner.HistoryBypass := false
            owner.Tip("共享队列已同步：" (kind = "CLEAR" ? "新批次" : "下一条 " owner.Index))
            return true
        } catch as err {
            owner.LastError := err.Message
            owner.Tip("共享操作未确认：" err.Message, 5000)
            return false
        } finally {
            owner.Busy := false
        }
    }
    static SetPolicy(values) {
        SPPreferences.Validate(values)
        owner := this.Owner
        this.Poll()
        if !this.Connected {
            owner.LastError := "尚未连接，规则未修改；请连接后再同步。"
            return false
        }
        if owner.Busy
            return false
        owner.Busy := true
        try {
            result := this.Request("SETTINGS",values["BatchContinue"] ";" values["AutoAdvance"] ";" values["IdleSeconds"])
            if result.Code!="OK" {
                this.Warn(result.Code)
                return false
            }
            owner.LastError := ""
            return true
        } finally owner.Busy := false
    }
    static SetEnabled() {
        owner := this.Owner
        this.Poll()
        if !this.Connected {
            owner.Tip("尚未连接，无法切换两端开关；Ctrl+V 仍可普通粘贴", 4000)
            return false
        }
        if owner.Busy
            return false
        owner.Busy := true
        try {
            result := this.Request("ENABLE", owner.Enabled ? "off" : "on")
            if result.Code != "OK" {
                this.Warn(result.Code)
                return false
            }
            owner.Tip(owner.Enabled ? "两端顺序增强已开启，请复制新批次" : "两端顺序增强已关闭，普通复制粘贴继续可用")
            return true
        } catch as err {
            owner.LastError := "统一开关未确认：" err.Message
            return false
        } finally owner.Busy := false
    }
    static CaptureTarget() {
        if SP_TestMode
            return {Window: 1, Control: 1}
        info := Buffer(A_PtrSize = 8 ? 72 : 48, 0)
        NumPut("uint", info.Size, info)
        DllCall("GetGUIThreadInfo", "uint", 0, "ptr", info)
        return {Window: WinExist("A"), Control: NumGet(info, 8 + A_PtrSize, "ptr")}
    }
    static CheckTarget(saved) {
        current := this.CaptureTarget()
        if !saved.Window || current.Window != saved.Window || current.Control != saved.Control
            throw Error("等待同步期间输入焦点已变化，本次未输出")
    }
    static Journal(token, typed, stage) {
        this.Owner.AtomicWrite(this.Owner.StateDir "\shared-output-journal.txt", "SQOUTPUT2`n" token "`n" (typed ? 1 : 0) "`n" stage)
    }
    static OfflinePaste(mode, target) {
        ; Only a fresh ordinary paste may fall back. Never read/replace the clipboard,
        ; consume a cached queue item, release a lease, or retry uncertain output.
        if mode != "paste" {
            this.Warn("OFFLINE")
            return false
        }
        this.CheckTarget(target)
        this.Owner.NativePaste()
        this.Owner.Tip("未连接：已普通粘贴当前剪贴板，共享进度保持不变")
        return true
    }
    static ClipboardOutput(mode, target) {
        if mode = "replay" {
            this.Warn("DISABLED")
            return false
        }
        if mode = "type" {
            text := this.Owner.ReadClipboardText()
            if text = ""
                return false
            this.Owner.ExpectedTypingTarget := target
            this.Owner.WaitTypingKeys()
            this.CheckTarget(target)
            this.Owner.EmitText(text)
        } else {
            this.CheckTarget(target)
            this.Owner.NativePaste()
        }
        return true
    }
    static Output(mode := "paste") {
        owner := this.Owner
        if owner.Busy
            return false
        this.Poll()
        owner.Busy := true,owner.StopTyping := false
        token := "", attempted := false, typed := false
        target := this.CaptureTarget()
        try {
            if !this.Connected {
                return this.OfflinePaste(mode, target)
            }
            if mode != "replay" && owner.PreferNativeClipboard()
                return this.ClipboardOutput(mode, target)
            ; A rapid copy-copy-paste must wait for its own ordered copies to
            ; be acknowledged before choosing a revision for the reservation.
            waiting := A_TickCount
            while this.PendingCopies > 0 && A_TickCount - waiting < 2800 {
                Sleep(20)
                this.Poll()
                if !this.Connected
                    return this.OfflinePaste(mode, target)
            }
            if this.PendingCopies > 0 {
                this.Warn("PENDING")
                return false
            }
            result := this.Request("CLAIM", mode)
            ; An explicit refusal means no reservation/output was granted. A
            ; timeout or unknown result must NOT fall back: it may own a lease.
            if result.Code = "OFFLINE"
                return this.OfflinePaste(mode, target)
            if result.Code = "NATIVE" || result.Code = "DISABLED"
                return this.ClipboardOutput(mode, target)
            if result.Code = "EMPTY" {
                if mode = "replay" {
                    this.Warn("EMPTY")
                    return false
                }
                text := owner.ReadClipboardText()
                typed := mode = "type" || owner.IsShortNumber(text)
                if typed {
                    if text = ""
                        return false
                    owner.ExpectedTypingTarget := target
                    owner.WaitTypingKeys()
                    this.CheckTarget(target)
                    owner.EmitText(text)
                } else {
                    this.CheckTarget(target)
                    owner.NativePaste()
                }
                return true
            }
            if result.Code != "GRANTED" {
                this.Warn(result.Code)
                return false
            }
            if this.LeaseOwner != this.Node || this.LeaseToken = "" || this.LeaseKind != mode
                throw Error("共享输出占用已改变，未执行输出")
            token := this.LeaseToken, text := this.LeaseText
            if mode != "replay" && owner.PreferNativeClipboard() {
                cancelled := this.Request("ABORT", "", token)
                if cancelled.Code != "OK" {
                    this.Warn(cancelled.Code)
                    return false
                }
                token := ""
                return this.ClipboardOutput(mode, target)
            }
            image := this.LeaseImage
            typed := !image && (mode = "replay" ? this.LeaseTyped : (mode = "type" || owner.IsShortNumber(text)))
            if typed {
                owner.ExpectedTypingTarget := target
                owner.WaitTypingKeys()
            }
            this.CheckTarget(target)
            if image {
                data := owner.PrepareImage(text)
                owner.StageImage(data)
                this.CheckTarget(target)
            }
            this.Journal(token, typed, "attempting")
            attempted := true
            if image
                owner.SendImagePaste(text)
            else if typed
                owner.EmitText(text)
            else if mode = "paste" && owner.Queue.Length = 1 && owner.ReadClipboardText() == text
                owner.NativePaste() ; preserve native formats for an ordinary matching single copy
            else
                owner.ClipboardPaste(text)
            this.Journal(token, typed, "emitted")
            result := this.Request("COMMIT", "", token, typed)
            if result.Code != "OK" {
                this.Warn(result.Code)
                return false
            }
            try FileDelete(owner.StateDir "\shared-output-journal.txt")
            owner.LastError := ""
            owner.Tip(mode = "replay" ? "已重贴上一条，共享进度不变" : (this.AutoAdvance?"已发送粘贴动作，下一条 ":"动作已发出，仍停在第 ") owner.Index)
            return true
        } catch as err {
            owner.LastError := err.Message
            if token!="" && (!attempted || (err is SPInputFailure && err.AcceptedEvents=0)) {
                try {
                    cancelled := this.Request("ABORT","",token)
                    if cancelled.Code="OK" {
                        attempted := false
                        try FileDelete(owner.StateDir "\shared-output-journal.txt")
                    }
                }
            }
            owner.Tip(attempted ? "输出结果未确认，请核对目标内容，再从托盘确认。不会自动重贴。"
                : "本次未输出：" err.Message, 6500)
            return false
        } finally {
            owner.ExpectedTypingTarget := 0
            owner.Busy := false
        }
    }
    static Resolve(*) {
        owner := this.Owner
        if owner.Busy
            return
        this.Poll()
        if this.LeaseToken = "" {
            owner.Tip("没有等待确认的共享输出")
            return
        }
        if this.LeaseOwner != this.Node {
            owner.Tip("请在发起这次粘贴的另一台电脑上确认输出结果", 5000)
            return
        }
        owner.Busy := true
        try {
            token := this.LeaseToken
            typed := this.LeaseKind = "replay" ? this.LeaseTyped
                : (this.LeaseKind = "type" || owner.IsShortNumber(this.LeaseText))
            try {
                f := StrSplit(FileRead(owner.StateDir "\shared-output-journal.txt", "UTF-8"), "`n")
                if f.Length = 4 && f[2] = token
                    typed := f[3] = "1"
            }
            answer := MsgBox("这条粘贴 / 输入动作是否已发出？不要求目标软件确认接收。`n`n"
                "是：确认动作已发出，同步进度；重贴操作不会推进。`n"
                "否：确认未输出，释放占用，保留当前条。`n"
                "取消：继续保留占用。若只输出了一部分，请先清理目标内容，再选否。`n`n"
                SubStr(this.LeaseText, 1, 160), "确认共享粘贴结果", "YesNoCancel Icon?")
            if answer = "Cancel"
                return
            result := this.Request("RESOLVE", answer = "Yes" ? "yes" : "no", token, typed)
            if result.Code = "OK" {
                try FileDelete(owner.StateDir "\shared-output-journal.txt")
                owner.LastError := ""
                owner.Tip("已确认并同步共享状态")
            } else
                this.Warn(result.Code)
        } finally {
            owner.Busy := false
        }
    }
}
