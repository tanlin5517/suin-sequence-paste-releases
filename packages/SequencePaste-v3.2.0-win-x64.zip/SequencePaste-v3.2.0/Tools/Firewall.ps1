﻿$ErrorActionPreference='Stop'
try {
 $admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
 if(-not $admin){Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"'+$PSCommandPath+'"'));exit}
 $app=Join-Path (Split-Path $PSScriptRoot) '顺序粘贴.exe'
 foreach($rule in @(@{Name='SuinSequenceClient-Pair-v3';Protocol='TCP';Port=39880;Program=$app},@{Name='SuinSequenceClient-Discovery-v3';Protocol='UDP';Port=39881;Program=$app},@{Name='SuinSequenceClient-Queue-v3';Protocol='TCP';Port=39882;Program="$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"})){
  Get-NetFirewallRule -Name $rule.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
  New-NetFirewallRule -Name $rule.Name -DisplayName $rule.Name -Direction Inbound -Action Allow -Protocol $rule.Protocol -LocalPort $rule.Port -Program $rule.Program -RemoteAddress LocalSubnet -Profile Private | Out-Null
 }
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show('已允许专用局域网内的设备发现、配对与加密队列连接。','顺序粘贴')|Out-Null
}catch{Add-Type -AssemblyName System.Windows.Forms;[Windows.Forms.MessageBox]::Show($_.Exception.Message,'连接设置失败')|Out-Null;exit 1}
