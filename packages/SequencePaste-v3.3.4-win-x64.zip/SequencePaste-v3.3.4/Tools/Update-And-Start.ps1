﻿param([string]$DestinationRoot,[switch]$PlanOnly,[switch]$NoLaunch,[int]$WaitProcessId=0,[switch]$Notify)
$ErrorActionPreference='Stop'
$sourceRoot=[IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot)).TrimEnd('\')
$changed=New-Object Collections.Generic.List[string]
$backup=$null;$lock=$null;$committed=$false;$wasRunning=$false
$publicFiles=@('顺序粘贴.exe','Main.ahk','Defaults.ini','使用说明.txt','Modules/SequencePaste.ahk','Modules/SharedQueue.ahk','Modules/SharedQueue.cs','Modules/SequenceBridge.cs','Modules/SequenceBridge.ps1','Modules/ClipboardRouting.ahk','Modules/ImageClipboard.ahk','Modules/SettingsCenter.ahk','Modules/InputDispatch.ahk','Modules/FBACargoCleaner.ahk','Runtime/AutoHotkey64.exe','Runtime/license.txt','Tools/Firewall.ps1','Tools/Startup.ps1','Tools/Update-And-Start.ps1')
function Public-Path([string]$name){return $name -ceq 'Update-files.json' -or $publicFiles -ccontains $name}
function Safe-Target([string]$base,[string]$relative){
 if(-not (Public-Path $relative)){throw ('拒绝非程序文件：'+$relative)}
 $target=[IO.Path]::GetFullPath((Join-Path $base $relative))
 if(-not $target.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw '更新文件路径越界'}
 $parent=$target
 while($parent -and $parent.Length -ge 3){if(Test-Path -LiteralPath $parent){if((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw '更新路径不能使用目录链接'}};$parent=Split-Path -Parent $parent}
 return $target
}
try{
 $manifest=Get-Content -LiteralPath (Join-Path $sourceRoot 'Update-files.json') -Raw|ConvertFrom-Json
 $running=@(Get-Process -Name 顺序粘贴 -ErrorAction SilentlyContinue|Where-Object {$_.Path})
 if(-not $DestinationRoot){if($running.Count -gt 1){throw '检测到多个客户端，请指定原来的安装目录'};$DestinationRoot=if($running.Count -eq 1){Split-Path -Parent $running[0].Path}else{$sourceRoot}}
 $DestinationRoot=[IO.Path]::GetFullPath($DestinationRoot).TrimEnd('\')
 $items=@($manifest.PSObject.Properties);if($items.Count -ne $publicFiles.Count -or -not ($items.Name -ccontains '顺序粘贴.exe')){throw '更新清单不完整'}
 $names=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($item in $items){$file=Safe-Target $sourceRoot $item.Name;$null=Safe-Target $DestinationRoot $item.Name;if($item.Name -ceq 'Update-files.json' -or -not $names.Add($item.Name) -or $item.Value -notmatch '^[a-fA-F0-9]{64}$'){throw '更新清单无效'};if((Get-FileHash -LiteralPath $file).Hash -ine $item.Value){throw ('更新文件校验失败：'+$item.Name)}}
 $exe=Join-Path $DestinationRoot '顺序粘贴.exe';$newVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $sourceRoot '顺序粘贴.exe')).FileVersion
 if(Test-Path -LiteralPath $exe){$oldVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo($exe).FileVersion;if($oldVersion -and [version]$newVersion -lt [version]$oldVersion){throw '拒绝用旧版覆盖较新的客户端'}}
 if($PlanOnly){[pscustomobject]@{Source=$sourceRoot;Destination=$DestinationRoot;Files=$items.Count;PreservePairing=$true;PreserveQueue=$true;StopAudio=$false;Rollback=$true}|ConvertTo-Json;exit 0}
 New-Item -ItemType Directory -Path $DestinationRoot -Force|Out-Null
 $lock=[IO.File]::Open((Join-Path $DestinationRoot '.update-lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 if($WaitProcessId -gt 0){$old=Get-Process -Id $WaitProcessId -ErrorAction SilentlyContinue;if($old -and -not $old.WaitForExit(15000)){throw '旧客户端仍在运行，已取消更新'}}
 foreach($process in $running){if([IO.Path]::GetDirectoryName($process.Path) -ieq $DestinationRoot -and -not $process.HasExited){$wasRunning=$true;$exit=Start-Process -FilePath $process.Path -ArgumentList '--quit' -WindowStyle Hidden -PassThru;$null=$exit.Handle;$null=$exit.WaitForExit(3000);if(-not $process.WaitForExit(8000)){throw '请先从托盘退出旧顺序粘贴客户端。普通系统粘贴不受影响。'}}}
 if($sourceRoot -ine $DestinationRoot){
  $backup=Join-Path $DestinationRoot ('Backups\ClientUpdate-'+(Get-Date -Format yyyyMMdd-HHmmss-fff));New-Item -ItemType Directory -Path $backup -Force|Out-Null
  $files=@($items.Name)+@('Update-files.json')
  # Complete backup before modifying the first public file. Private files are never copied.
  foreach($name in $files){$target=Safe-Target $DestinationRoot $name;if(Test-Path -LiteralPath $target){$old=Join-Path $backup $name;New-Item -ItemType Directory -Path (Split-Path -Parent $old) -Force|Out-Null;Copy-Item -LiteralPath $target -Destination $old}}
  foreach($name in $files){$target=Safe-Target $DestinationRoot $name;New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force|Out-Null;$temp=$target+'.update-tmp';Copy-Item -LiteralPath (Join-Path $sourceRoot $name) -Destination $temp -Force;if(Test-Path -LiteralPath $target){[IO.File]::Replace($temp,$target,[NullString]::Value)}else{[IO.File]::Move($temp,$target)};$changed.Add($name)}
  foreach($item in $items){if((Get-FileHash -LiteralPath (Join-Path $DestinationRoot $item.Name)).Hash -ine $item.Value){throw '更新后校验失败'}}
 }
 $committed=$true
 $uninstall='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SuinSequencePaste_is1'
 if(Test-Path $uninstall){$entry=Get-ItemProperty $uninstall;if($entry.InstallLocation -and $entry.InstallLocation.TrimEnd('\') -ieq $DestinationRoot){Set-ItemProperty $uninstall DisplayVersion ($newVersion -replace '\.0$','')}}
 if(-not $NoLaunch){Start-Process -FilePath $exe -WorkingDirectory $DestinationRoot -WindowStyle Hidden}
 Write-Output 'UPDATE_OK: 配对、偏好和队列已保留。'
}catch{
 $message=$_.Exception.Message
 if(-not $committed -and $backup){foreach($name in $changed){$target=Safe-Target $DestinationRoot $name;$old=Join-Path $backup $name;try{if(Test-Path -LiteralPath $old){Copy-Item -LiteralPath $old -Destination $target -Force}else{Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue}}catch{$message+='；部分回退失败，请使用 Backups 恢复。'}}}
 if(($WaitProcessId -gt 0 -or $wasRunning) -and -not $NoLaunch -and (Test-Path -LiteralPath (Join-Path $DestinationRoot '顺序粘贴.exe'))){try{Start-Process -FilePath (Join-Path $DestinationRoot '顺序粘贴.exe') -WorkingDirectory $DestinationRoot -WindowStyle Hidden}catch{}}
 if($Notify){Add-Type -AssemblyName System.Windows.Forms;[Windows.Forms.MessageBox]::Show(('更新未完成，已尝试恢复旧版。'+"`n"+$message),'顺序粘贴更新')|Out-Null}
 Write-Error $message -ErrorAction Continue;exit 1
}finally{if($lock){$lock.Dispose()}}
