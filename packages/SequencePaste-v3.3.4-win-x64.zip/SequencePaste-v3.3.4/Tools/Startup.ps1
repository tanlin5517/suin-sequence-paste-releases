﻿param([switch]$Disable,[switch]$Quiet)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$link=Join-Path ([Environment]::GetFolderPath('Startup')) 'SuinSequencePaste.lnk'
$shell=New-Object -ComObject WScript.Shell
if(Test-Path -LiteralPath $link){$backup=Join-Path $env:LOCALAPPDATA ('SuinSequenceClient\Backups\Startup-'+(Get-Date -Format yyyyMMdd-HHmmss-fff));New-Item -ItemType Directory -Path $backup -Force|Out-Null;Copy-Item -LiteralPath $link -Destination $backup}
if($Disable){if(Test-Path -LiteralPath $link){$current=$shell.CreateShortcut($link);if($current.TargetPath -ne (Join-Path $root '顺序粘贴.exe')){throw '启动项指向其他项目，未删除。'};Remove-Item -LiteralPath $link}}
else{$s=$shell.CreateShortcut($link);$s.TargetPath=Join-Path $root '顺序粘贴.exe';$s.Arguments='--background';$s.WorkingDirectory=$root;$s.WindowStyle=7;$s.Description='顺序粘贴统一客户端';$s.Save();$v=$shell.CreateShortcut($link);if($v.TargetPath -ne $s.TargetPath -or $v.Arguments -ne '--background'){throw '启动项回读校验失败'}}
if(-not $Quiet){Add-Type -AssemblyName System.Windows.Forms;[Windows.Forms.MessageBox]::Show($(if($Disable){'已关闭登录自动启动。'}else{'已开启登录自动启动。'}),'顺序粘贴')|Out-Null}
