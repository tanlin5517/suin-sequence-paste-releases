﻿if !SP_TestMode
    OnClipboardChange(FBACleaner_Monitor)
FBACleaner_Monitor(DataType) {
    FBACleaner.Changed(DataType)
}
; Clipboard notifications can arrive while another app still owns the clipboard.
; Retry only this clipboard generation; never replay a stale cleaning operation.
class FBACleaner {
    static Pending := -1, Attempts := 0, OwnSequence := -1
    static Timer := (*) => FBACleaner.Run()
    static Sequence() => DllCall("GetClipboardSequenceNumber", "UInt")
    static Busy() => SP.Busy
    static Read() => A_Clipboard
    static Schedule(delay) => SetTimer(this.Timer, -delay)
    static Notice() {
        ToolTip("FBA 数据已清洗", , , 13)
        SetTimer(() => ToolTip(, , , 13), -2000)
    }
    static Changed(dataType) {
        this.Pending := -1
        if dataType != 1 || this.Busy()
            return
        seq := this.Sequence()
        if seq = this.OwnSequence
            return
        this.Pending := seq, this.Attempts := 0
        this.Schedule(40)
    }
    static Run() {
        seq := this.Pending
        if seq = -1
            return
        if this.Busy() || this.Sequence() != seq {
            this.Pending := -1
            return
        }
        this.Attempts++
        try {
            if !SP_TestMode && SP.ClipboardInfo().Kind != "text" {
                this.Pending := -1
                return
            }
            original := this.Read()
            ; A read can wait internally. A copy/paste may interrupt that wait.
            if this.Pending != seq
                return
            if this.Busy() || this.Sequence() != seq {
                this.Pending := -1
                return
            }
            cleaned := FBACleaner_CleanText(original)
            if cleaned != original && this.WriteCurrent(cleaned, seq) {
                this.OwnSequence := this.Sequence()
                this.Notice()
            }
            this.Pending := -1
        } catch {
            ; Never let an optional background cleaner open a fatal error dialog.
            if this.Pending != seq
                return
            if this.Attempts < 4 && !this.Busy() && this.Sequence() = seq
                this.Schedule(150)
            else
                this.Pending := -1
        }
    }
    static WriteCurrent(text, expected) {
        ; Check the generation and publish while holding the SAME clipboard lock.
        ; A_Clipboard := text could wait and overwrite a newer external copy.
        wasCritical := A_IsCritical
        Critical("On")
        if !DllCall("OpenClipboard", "Ptr", A_ScriptHwnd) {
            Critical(wasCritical)
            throw OSError()
        }
        memory := 0, locked := 0
        try {
            if this.Busy() || this.Sequence() != expected
                return false
            bytes := StrPut(text, "UTF-16") * 2
            memory := DllCall("GlobalAlloc", "UInt", 0x42, "UPtr", bytes, "Ptr")
            if !memory
                throw OSError()
            locked := DllCall("GlobalLock", "Ptr", memory, "Ptr")
            if !locked
                throw OSError()
            StrPut(text, locked, bytes // 2, "UTF-16")
            DllCall("GlobalUnlock", "Ptr", memory)
            locked := 0
            if !DllCall("EmptyClipboard")
                throw OSError()
            if !DllCall("SetClipboardData", "UInt", 13, "Ptr", memory, "Ptr")
                throw OSError()
            memory := 0 ; The clipboard now owns the allocation.
            return true
        } finally {
            if locked
                DllCall("GlobalUnlock", "Ptr", memory)
            if memory
                DllCall("GlobalFree", "Ptr", memory, "Ptr")
            DllCall("CloseClipboard")
            Critical(wasCritical)
        }
    }
}
FBACleaner_CleanText(text) {
    if !(InStr(text, "创建日期") && InStr(text, "追踪货件FBA"))
        return text
    result := ""
    if RegExMatch(text, "创建日期：[^\r\n]+", &dateMatch)
        result .= dateMatch[0] "`n"
    pos := 1
    while (pos := RegExMatch(text, "FBA[A-Z0-9]+", &match, pos)) {
        result .= match[0] "`n"
        pos += match.Len
    }
    return result = "" ? text : Trim(result, "`r`n")
}
