﻿param([Parameter(Mandatory=$true)][string]$ConfigPath,
      [Parameter(Mandatory=$true)][string]$StateDir,
      [int]$ParentPid = 0,
      [switch]$SessionQueue)
$ErrorActionPreference = 'Stop'
try {
    $settings = @{}
    foreach ($line in [IO.File]::ReadAllLines($ConfigPath)) {
        if ($line -match '^\s*([^;#\[\]=]+?)\s*=\s*(.*?)\s*$') {
            $settings[$matches[1]] = $matches[2]
        }
    }
    Add-Type -Path @((Join-Path $PSScriptRoot 'SequenceBridge.cs'), (Join-Path $PSScriptRoot 'SharedQueue.cs')) -ReferencedAssemblies 'System.dll','System.Core.dll','System.Web.Extensions.dll'
    $bridge = New-Object SuinQueueBridge -ArgumentList @($StateDir, $settings['Role'].ToLowerInvariant(),
        [string]$settings['PeerHost'], [string]$settings['BindAddress'], [int]$settings['Port'],
        [string]$settings['SharedKey'], $ParentPid)
    $bridge.Run([int]$settings['TimeoutSeconds'], [bool]$SessionQueue)
} catch {
    [IO.Directory]::CreateDirectory($StateDir) | Out-Null
    [IO.File]::WriteAllText((Join-Path $StateDir 'bridge-error.txt'), $_.Exception.ToString())
    exit 1
}
