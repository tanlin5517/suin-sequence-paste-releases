﻿#Requires AutoHotkey v2.0
class ImageClipboard {
    static MaxImage := 32 * 1024 * 1024, MaxCache := 256 * 1024 * 1024
    static Hash(data) {
        provider := 0, hash := 0
        if !DllCall("advapi32\CryptAcquireContextW", "ptr*", &provider, "ptr", 0, "ptr", 0, "uint", 24, "uint", 0xF0000000)
            throw OSError()
        try {
            if !DllCall("advapi32\CryptCreateHash", "ptr", provider, "uint", 0x800C, "ptr", 0, "uint", 0, "ptr*", &hash)
                throw OSError()
            if !DllCall("advapi32\CryptHashData", "ptr", hash, "ptr", data, "uint", data.Size, "uint", 0)
                throw OSError()
            digest := Buffer(32), size := 32
            if !DllCall("advapi32\CryptGetHashParam", "ptr", hash, "uint", 2, "ptr", digest, "uint*", &size, "uint", 0)
                throw OSError()
            hex := ""
            Loop 32
                hex .= Format("{:02x}", NumGet(digest, A_Index - 1, "uchar"))
            return hex
        } finally {
            if hash
                DllCall("advapi32\CryptDestroyHash", "ptr", hash)
            DllCall("advapi32\CryptReleaseContext", "ptr", provider, "uint", 0)
        }
    }
    static Path(root, reference) {
        if !RegExMatch(reference, "^[0-9a-f]{64}:[0-9]{1,9}$")
            throw Error("图片引用无效")
        parts := StrSplit(reference, ":")
        if Integer(parts[2]) > this.MaxImage || Integer(parts[2]) < 16
            throw Error("图片大小无效")
        return root "\images\" parts[1] ".img"
    }
    static Validate(data) {
        if data.Size < 16 || data.Size > this.MaxImage || NumGet(data,0,"uint") != 0x344D4953
            throw Error("图片数据格式无效")
        count := NumGet(data,4,"uint"), offset := 8, entries := [], seen := Map()
        if count < 1 || count > 3
            throw Error("图片格式数量无效")
        Loop count {
            if offset + 8 > data.Size
                throw Error("图片数据不完整")
            imageFormat := NumGet(data,offset,"uint"), size := NumGet(data,offset+4,"uint"), offset += 8
            if seen.Has(imageFormat) || (imageFormat != 0 && imageFormat != 8 && imageFormat != 17) || size < 8 || size > data.Size - offset
                throw Error("图片内容边界无效")
            seen[imageFormat] := true
            if imageFormat = 0 {
                if size < 24 || NumGet(data,offset,"uint") != 0x474E5089 || NumGet(data,offset+4,"uint") != 0x0A1A0A0D
                    throw Error("PNG 图片无效")
            } else {
                if size < 40
                    throw Error("位图数据不完整")
                header := NumGet(data,offset,"uint"), width := NumGet(data,offset+4,"int"), height := NumGet(data,offset+8,"int")
                bits := NumGet(data,offset+14,"ushort"), compression := NumGet(data,offset+16,"uint")
                if header < 40 || header > size || width < 1 || width > 32768 || height = 0 || Abs(height) > 32768
                    || width * Abs(height) > 150000000 || !InStr("|1|4|8|16|24|32|", "|" bits "|")
                    || (compression != 0 && compression != 3 && compression != 6)
                    throw Error("位图尺寸或编码不支持")
                if header + ((width * bits + 31) // 32) * 4 * Abs(height) > size
                    throw Error("位图像素不完整")
            }
            entries.Push({Format:imageFormat, Offset:offset, Size:size}), offset += size
        }
        if offset != data.Size
            throw Error("图片数据长度不符")
        return entries
    }
    static Save(root, data) {
        this.Validate(data)
        reference := this.Hash(data) ":" data.Size, path := this.Path(root,reference)
        if FileExist(path) {
            existing := FileRead(path,"RAW")
            if existing.Size = data.Size && this.Hash(existing) = this.Hash(data)
                return reference
            FileDelete(path)
        }
        DirCreate(root "\images")
        total := data.Size
        Loop Files root "\images\*.*"
            total += A_LoopFileSize
        if total > this.MaxCache
            throw Error("图片缓存已达 256MB，请从托盘清理闲置图片缓存")
        temp := path "." DllCall("GetCurrentProcessId", "uint") ".tmp"
        try {
            imageFile := FileOpen(temp,"w")
            imageFile.RawWrite(data), imageFile.Close()
            FileMove(temp,path,1)
        } finally {
            if FileExist(temp)
                FileDelete(temp)
        }
        return reference
    }
    static Capture(root) {
        if !DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            throw Error("剪贴板正在占用，请稍后加入图片")
        try {
            sequence := DllCall("GetClipboardSequenceNumber","uint"), entries := [], total := 8
            png := DllCall("RegisterClipboardFormatW","str","PNG","uint")
            ; Prefer portable DIB pixels, and preserve PNG transparency when it fits.
            for imageFormat in [17,8,png] {
                if imageFormat = 8 && entries.Length && entries[1].Format = 17
                    continue
                if !DllCall("IsClipboardFormatAvailable","uint",imageFormat)
                    continue
                handle := DllCall("GetClipboardData","uint",imageFormat,"ptr")
                if !handle
                    continue
                size := DllCall("GlobalSize","ptr",handle,"uptr")
                if size < 8 || total + 8 + size > this.MaxImage
                    continue
                ptr := DllCall("GlobalLock","ptr",handle,"ptr")
                if !ptr
                    continue
                try {
                    payload := Buffer(size)
                    DllCall("RtlMoveMemory","ptr",payload,"ptr",ptr,"uptr",size)
                    entries.Push({Format:imageFormat=png?0:imageFormat, Data:payload}), total += size + 8
                } finally DllCall("GlobalUnlock","ptr",handle)
            }
            if !entries.Length
                throw Error("当前没有可入队的图片，或图片超过 32MB；仍可普通粘贴")
            data := Buffer(total), offset := 8
            NumPut("uint",0x344D4953,"uint",entries.Length,data)
            for entry in entries {
                NumPut("uint",entry.Format,"uint",entry.Data.Size,data,offset), offset += 8
                DllCall("RtlMoveMemory","ptr",data.Ptr+offset,"ptr",entry.Data,"uptr",entry.Data.Size)
                offset += entry.Data.Size
            }
        } finally DllCall("CloseClipboard")
        return {Reference:this.Save(root,data), Sequence:sequence}
    }
    static Read(root, reference) {
        path := this.Path(root,reference)
        if !FileExist(path)
            throw Error("图片尚未同步完成，请稍后再贴")
        data := FileRead(path,"RAW")
        if data.Size != Integer(StrSplit(reference,":")[2]) || this.Hash(data) != StrSplit(reference,":")[1]
            throw Error("图片校验失败，未执行粘贴")
        this.Validate(data)
        return data
    }
    static Allocate(data) {
        entries := this.Validate(data), allocated := []
        try {
            for entry in entries {
                memory := DllCall("GlobalAlloc","uint",0x42,"uptr",entry.Size,"ptr")
                if !memory
                    throw OSError()
                allocated.Push({Handle:memory, Format:entry.Format})
                ptr := DllCall("GlobalLock","ptr",memory,"ptr")
                if !ptr
                    throw OSError()
                DllCall("RtlMoveMemory","ptr",ptr,"ptr",data.Ptr+entry.Offset,"uptr",entry.Size)
                DllCall("GlobalUnlock","ptr",memory)
            }
            return allocated
        } catch as err {
            for item in allocated
                if item.Handle
                    DllCall("GlobalFree","ptr",item.Handle)
            throw err
        }
    }
    static Publish(data) {
        allocated := this.Allocate(data)
        try {
            if !DllCall("OpenClipboard","ptr",A_ScriptHwnd)
                throw Error("剪贴板正在占用，未发送图片粘贴")
            try {
                if !DllCall("EmptyClipboard")
                    throw OSError()
                for item in allocated {
                    imageFormat := item.Format = 0 ? DllCall("RegisterClipboardFormatW","str","PNG","uint") : item.Format
                    if !DllCall("SetClipboardData","uint",imageFormat,"ptr",item.Handle,"ptr")
                        throw OSError()
                    item.Handle := 0
                }
            } finally DllCall("CloseClipboard")
        } finally {
            for item in allocated
                if item.Handle
                    DllCall("GlobalFree","ptr",item.Handle)
        }
    }
}
