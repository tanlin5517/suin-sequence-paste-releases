﻿#Requires AutoHotkey v2.0
class SPInputFailure extends Error {
    __New(message, accepted:=0, completed:=0, code:="INPUT_FAILED", systemError:=0) {
        super.__New(message)
        this.AcceptedEvents := accepted,this.Completed := completed,this.Code := code,this.SystemError := systemError
    }
}
class SPInput {
    static Capture() {
        info := Buffer(A_PtrSize=8?72:48,0),NumPut("uint",info.Size,info)
        if !DllCall("GetGUIThreadInfo","uint",0,"ptr",info)
            throw SPInputFailure("无法确认输入焦点，本次未发送。",0,0,"NO_TARGET",A_LastError)
        return {Window:DllCall("GetForegroundWindow","ptr"),Control:NumGet(info,8+A_PtrSize,"ptr")}
    }
    static Same(saved) {
        current := this.Capture()
        return saved.Window && current.Window=saved.Window && current.Control=saved.Control
    }
    static Integrity(pid) {
        process := DllCall("OpenProcess","uint",0x1000,"int",false,"uint",pid,"ptr"),token := 0
        if !process
            return -1
        try {
            if !DllCall("advapi32\OpenProcessToken","ptr",process,"uint",8,"ptr*",&token)
                return -1
            size := 0
            DllCall("advapi32\GetTokenInformation","ptr",token,"int",25,"ptr",0,"uint",0,"uint*",&size)
            if !size
                return -1
            label := Buffer(size)
            if !DllCall("advapi32\GetTokenInformation","ptr",token,"int",25,"ptr",label,"uint",size,"uint*",&size)
                return -1
            sid := NumGet(label,0,"ptr"),count := NumGet(DllCall("advapi32\GetSidSubAuthorityCount","ptr",sid,"ptr"),0,"uchar")
            return NumGet(DllCall("advapi32\GetSidSubAuthority","ptr",sid,"uint",count-1,"ptr"),0,"uint")
        } finally {
            if token
                DllCall("CloseHandle","ptr",token)
            DllCall("CloseHandle","ptr",process)
        }
    }
    static CheckPermission(target) {
        pid := 0
        DllCall("GetWindowThreadProcessId","ptr",target.Window,"uint*",&pid)
        if !pid
            throw SPInputFailure("目标窗口已关闭，本次未发送。",0,0,"NO_TARGET")
        current := this.Integrity(DllCall("GetCurrentProcessId","uint")),other := this.Integrity(pid)
        if current>=0 && other>current
            throw SPInputFailure("目标软件的运行权限较高，本次未输入；请以相同权限运行，或使用普通粘贴。",0,0,"HIGHER_INTEGRITY")
    }
    static ModifiersHeld() {
        for vk in [0x11,0x12,0x10,0x5B,0x5C]
            if DllCall("GetAsyncKeyState","int",vk,"short")&0x8000
                return true
        return false
    }
    static Packet(events) {
        size := A_PtrSize=8?40:28,base := A_PtrSize=8?8:4,packet := Buffer(size*events.Length,0)
        for idx,event in events {
            offset := (idx-1)*size
            NumPut("uint",1,packet,offset)
            NumPut("ushort",event[1],"ushort",event[2],"uint",event[3],packet,offset+base)
        }
        return packet
    }
    static KeyPair(vk) => [[vk,0,0],[vk,0,2]]
    static Plan(text,method,target) {
        steps := [],position := 1,layout := 0
        numeric := method=1 && RegExMatch(text,"\A[+-]?(?:(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?|\.[0-9]+)\z")
        if numeric {
            targetThread := DllCall("GetWindowThreadProcessId","ptr",target.Window,"ptr",0,"uint")
            layout := DllCall("GetKeyboardLayout","uint",targetThread,"ptr")
        }
        while position<=StrLen(text) {
            code := Ord(SubStr(text,position,1)),units := 1,tab := false
            if code=13 || code=10 {
                if code=13 && SubStr(text,position+1,1)="`n"
                    units := 2
                events := this.KeyPair(0x0D)
            } else if code=9 {
                events := this.KeyPair(0x09),tab := true
            } else if code=8
                events := this.KeyPair(0x08)
            else if numeric {
                mapping := DllCall("VkKeyScanExW","ushort",code,"ptr",layout,"short")
                if mapping=-1 || ((mapping>>8)&~1)
                    throw SPInputFailure("当前键盘布局不支持兼容数字输入，请切换为标准逐字模式。",0,0,"LAYOUT_UNSUPPORTED")
                vk := mapping&255,shift := (mapping>>8)&1,events := []
                if shift
                    events.Push([0x10,0,0])
                events.Push([vk,0,0],[vk,0,2])
                if shift
                    events.Push([0x10,0,2])
            } else {
                events := [],part := SubStr(text,position,1)
                if code>=0xD800 && code<=0xDBFF && position<StrLen(text) {
                    low := Ord(SubStr(text,position+1,1))
                    if low>=0xDC00 && low<=0xDFFF
                        part .= SubStr(text,position+1,1),units := 2
                }
                encoded := Buffer(StrPut(part,"UTF-16")*2,0),StrPut(part,encoded,"UTF-16")
                Loop StrLen(part) {
                    unit := NumGet(encoded,(A_Index-1)*2,"ushort")
                    events.Push([0,unit,4],[0,unit,6])
                }
            }
            steps.Push({Packet:this.Packet(events),Count:events.Length,Units:units,Tab:tab,Events:events})
            position += units
        }
        return steps
    }
    static NativeSend(packet,count) {
        DllCall("SetLastError","uint",0)
        inserted := DllCall("SendInput","uint",count,"ptr",packet,"int",A_PtrSize=8?40:28,"uint")
        return {Inserted:inserted,Error:A_LastError}
    }
    static ReleasePlan(events,inserted) {
        down := Map()
        Loop Min(inserted,events.Length) {
            event := events[A_Index],key := event[1] ":" event[2]
            if event[3]&2 {
                if down.Has(key)
                    down.Delete(key)
            } else
                down[key] := [event[1],event[2],event[3]|2]
        }
        release := []
        for key,event in down
            release.Push(event)
        return release
    }
    static ReleasePartial(step,inserted) {
        release := this.ReleasePlan(step.Events,inserted)
        if release.Length {
            try this.NativeSend(this.Packet(release),release.Length)
        }
    }
    static Delay(ms) => Sleep(ms>0?ms:-1)
    static Send(text,method:=0,delay:=15,canContinue:=0,expectedTarget:=0) {
        if StrLen(text)>100000
            throw SPInputFailure("逐字输入每条最多10万字符；较长内容请分段或用普通粘贴。",0,0,"TEXT_LIMIT")
        target := this.Capture(),accepted := 0,completed := 0
        if IsObject(expectedTarget) && (target.Window!=expectedTarget.Window || target.Control!=expectedTarget.Control)
            throw SPInputFailure("等待快捷键释放期间焦点已改变，本次未输入。",0,0,"FOCUS_CHANGED")
        this.CheckPermission(target)
        steps := this.Plan(text,method,target)
        for step in steps {
            if IsObject(canContinue) && !canContinue()
                throw SPInputFailure("输入已停止，请核对已输入部分后再操作。",accepted,completed,"CANCELLED")
            if !this.Same(target)
                throw SPInputFailure("输入焦点已变化，已停止；请核对已输入部分后再操作。",accepted,completed,"FOCUS_CHANGED")
            if this.ModifiersHeld()
                throw SPInputFailure("检测到 Ctrl / Alt / Shift / Win 被按住，已停止输入。",accepted,completed,"MODIFIER_HELD")
            result := this.NativeSend(step.Packet,step.Count)
            accepted += result.Inserted
            if result.Inserted!=step.Count {
                if result.Inserted>0
                    this.ReleasePartial(step,result.Inserted)
                throw SPInputFailure(accepted=0?"Windows 未接受输入按键，当前条已保留；可运行输入自检。":"Windows 只接受了部分按键，已停止；请核对后再确认或重贴。",accepted,completed,"INPUT_BLOCKED",result.Error)
            }
            completed += step.Units
            this.Delay(delay)
            if step.Tab {
                current := this.Capture()
                if current.Window!=target.Window
                    throw SPInputFailure("Tab 后离开了原窗口，已停止输入。",accepted,completed,"FOCUS_CHANGED")
                target := current
            }
        }
        return {Code:"DISPATCHED",AcceptedEvents:accepted,Completed:completed,Method:method}
    }
}

class SPInputDiagnostics {
    static Save(owner,standard,compatible,code) {
        if owner.StateDir=""
            return
        ; Fixed metadata only: never serialize samples, clipboard contents or exception messages.
        if !RegExMatch(code,"^[A-Z_]{1,40}$")
            code := "SELFTEST_FAILED"
        try owner.AtomicWrite(owner.StateDir "\input-selftest.txt","SPSELFTEST1`n" SPSettingsWindow.Version "`n" A_Now "`n" standard "`n" compatible "`n" code)
    }
    static Summary(owner) {
        try {
            path := owner.StateDir "\input-selftest.txt"
            if FileGetSize(path)>512
                return "尚无可用自检记录。"
            fields := StrSplit(StrReplace(FileRead(path,"UTF-8"),"`r"),"`n")
            if fields.Length!=6 || fields[1]!="SPSELFTEST1" || !RegExMatch(fields[2],"^\d+\.\d+\.\d+$") || !RegExMatch(fields[3],"^\d{14}$") || !RegExMatch(fields[4],"^[0-4]$") || !RegExMatch(fields[5],"^[0-4]$") || !RegExMatch(fields[6],"^[A-Z_]{1,40}$")
                return "尚无可用自检记录。"
            stamp := FormatTime(fields[3],"MM-dd HH:mm")
            return "上次自检 " stamp " · v" fields[2] " · 标准 " fields[4] "/4，兼容 " fields[5] "/4" (fields[6]="COMPLETE"?" · 通过":" · " fields[6])
        } catch
            return "尚未自检。请在专用测试框中检查两个输入通道。"
    }
}

class SPInputTest {
    __New(owner) {
        this.Owner := owner,this.Busy := false,this.Cancelled := false
        this.Gui := Gui("+AlwaysOnTop -MaximizeBox -MinimizeBox","逐字输入自检 · 不改动队列和剪贴板")
        this.Gui.BackColor := "F5F7FB",this.Gui.MarginX := 0,this.Gui.MarginY := 0
        this.Painter := SPSettingsWindow(owner),this.Painter.Gui := this.Gui
        this.Painter.Dpi := A_ScreenDPI,this.Painter.Scale := 1
        this.Painter.GdipLibrary := DllCall("LoadLibrary","str","gdiplus.dll","ptr")
        input := Buffer(24,0),NumPut("uint",1,input)
        DllCall("gdiplus\GdiplusStartup","ptr*",&token:=0,"ptr",input,"ptr",0),this.Painter.GdipToken := token
        this.DrawCallback := ObjBindMethod(this.Painter,"Draw"),OnMessage(0x2B,this.DrawCallback)
        this.Painter.Text(0,"本机输入自检",28,25,560,38,20,"18253D",true,"F5F7FB")
        this.Painter.Text(0,"只向下面的专用测试框发送固定样例，不消费队列，不读写剪贴板。",30,78,610,26,10,"69758B",false,"F5F7FB")
        this.Painter.Surface(0,26,123,612,143)
        this.Painter.Text(0,"测试输入框",48,141,530,24,10,"69758B")
        this.Gui.SetFont("s13 c18253D Norm","Microsoft YaHei UI")
        this.Field := this.Gui.AddEdit("x48 y181 w566 h62 -E0x200 -Border BackgroundF3F5FA")
        this.Status := this.Painter.Text(0,SPInputDiagnostics.Summary(owner) "`n点击开始检查两个输入通道；测试期间请勿切换窗口，Esc 可停止。",30,288,608,108,10,"536A89",false,"F5F7FB")
        this.CloseButton := this.Painter.Button("关闭",372,415,104,42,(*)=>this.Close(),"secondary")
        this.RunButton := this.Painter.Button("开始自检",492,415,146,42,(*)=>this.Run(),"primary")
        this.Gui.OnEvent("Close",(*)=>this.Close()),this.Gui.OnEvent("Escape",(*)=>this.Close())
        this.Painter.PaintButtons(),this.Gui.Show("w664 h480")
    }
    Run() {
        if this.Busy
            return
        this.Busy := true,this.Cancelled := false,this.RunButton.Enabled := false
        this.Status.Text := "正在检查输入通道，请保持此窗口在前台……"
        results := [],failures := 0,counts := [0,0],code := "COMPLETE"
        try {
            for method in [0,1] {
                passed := 0,total := 0
                for sample in ["00123456789012345678","-1,234.5000","+0123.4500","中文🙂 ^!+#{}"] {
                    if this.Cancelled
                        throw Error("自检已停止。")
                    if !WinActive(this.Gui.Hwnd)
                        throw Error("焦点离开了自检窗口，已停止；未向其他窗口继续输入。")
                    this.Field.Value := "",this.Field.Focus(),Sleep(40)
                    total++
                    try {
                        SPInput.Send(sample,method,this.Owner.TypeDelay,()=>!this.Cancelled)
                        Sleep(40)
                        if this.Field.Value==sample
                            passed++
                        else
                            code := "CONTENT_MISMATCH"
                    } catch as err {
                        code := err is SPInputFailure?err.Code:"SELFTEST_FAILED"
                        results.Push((method=0?"标准逐字":"数字兼容") "：" err.Message)
                        break
                    }
                    counts[method+1] := passed
                }
                label := method=0?"标准逐字":"数字兼容"
                results.Push(label "：" passed "/4 项通过")
                if passed!=4
                    failures++
            }
            details := ""
            for result in results
                details .= result "`n"
            this.Status.Text := details (failures=0?"两个通道均通过。目标软件若忽略标准输入，可在设置中选数字兼容模式。":"部分通道未通过；请检查窗口焦点、权限，或在数字输入页切换兼容模式。")

        } catch as err {
            code := this.Cancelled?"CANCELLED":"FOCUS_CHANGED"
            this.Status.Text := err.Message
        } finally {
            SPInputDiagnostics.Save(this.Owner,counts[1],counts[2],code)
            this.Busy := false,this.RunButton.Enabled := true,this.Painter.PaintButtons()
            if this.Cancelled
                this.Close()
        }
    }
    Close() {
        if !IsObject(this.Gui)
            return
        if this.Busy {
            this.Cancelled := true
            return
        }
        ; Detach before destroying: destruction can trigger hotkey conditions.
        this.Owner.InputTestWindow := 0
        closingGui := this.Gui,this.Gui := 0
        OnMessage(0x2B,this.DrawCallback,0)
        closingGui.Destroy()
        if this.Painter.GdipToken
            DllCall("gdiplus\GdiplusShutdown","ptr",this.Painter.GdipToken)
        if this.Painter.GdipLibrary
            DllCall("FreeLibrary","ptr",this.Painter.GdipLibrary)
        if SP.WindowHandle(this.Owner.SettingsWindow) && this.Owner.SettingsWindow.Page=2 {
            try this.Owner.SettingsWindow.Message(SPInputDiagnostics.Summary(this.Owner))
        }
        this.Painter.Buttons.Clear(),this.Painter.DrawCallback := 0,this.Painter.StatusCallback := 0
        this.Painter.MouseCallback := 0,this.Painter.KeyCallback := 0,this.Painter.Gui := 0,this.Painter.Owner := 0
        this.Owner := 0,this.Painter := 0,this.DrawCallback := 0
    }
}
