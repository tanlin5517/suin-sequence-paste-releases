﻿#Requires AutoHotkey v2.0
; Inspect formats under one clipboard lock. Never empty, rewrite or restore it.
class ClipboardRouting {
    static Describe(formats, text) {
        for name in ["CF_HDROP", "FileGroupDescriptorW", "FileGroupDescriptor", "FileContents"]
            if formats.Has(name)
                return "file"
        if InStr(text, "`t")
            return "table"
        ; A single scalar number keeps the established typing policy, including
        ; numbers copied from Excel. Never parse or normalize its value.
        numeric := RegExMatch(text, "\A[+-]?(?:(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?|\.[0-9]+)\z")
        ; Spreadsheet apps also publish bitmap previews for a single cell.
        if numeric {
            for name in ["Biff8", "Biff12", "XML Spreadsheet", "XML Spreadsheet Format", "HTML Format", "Rich Text Format"]
                if formats.Has(name)
                    return "text"
        }
        for name in ["CF_BITMAP", "CF_DIB", "CF_DIBV5", "PNG", "image/png", "JFIF"]
            if formats.Has(name)
                return "image"
        if !numeric {
            for name in ["HTML Format", "Rich Text Format", "Rich Text Format Without Objects", "Biff8", "Biff12", "XML Spreadsheet", "XML Spreadsheet Format"]
                if formats.Has(name)
                    return "rich"
        }
        return text = "" ? "native" : "text"
    }
    static Inspect() {
        if !DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            return {Kind: "unknown", Text: "", Sequence: -1}
        try {
            seq := DllCall("GetClipboardSequenceNumber", "uint")
            formats := Map(), id := 0
            standard := Map(2, "CF_BITMAP", 8, "CF_DIB", 17, "CF_DIBV5", 15, "CF_HDROP")
            Loop {
                id := DllCall("EnumClipboardFormats", "uint", id, "uint")
                if !id
                    break
                if standard.Has(id)
                    formats[standard[id]] := true
                else if id >= 0xC000 {
                    name := Buffer(512, 0)
                    if DllCall("GetClipboardFormatNameW", "uint", id, "ptr", name, "int", 256)
                        formats[StrGet(name)] := true
                }
            }
            text := ""
            if DllCall("IsClipboardFormatAvailable", "uint", 13) {
                handle := DllCall("GetClipboardData", "uint", 13, "ptr")
                if handle {
                    size := DllCall("GlobalSize", "ptr", handle, "uptr")
                    if size > 2000002
                        return {Kind: "native", Text: "", Sequence: seq}
                    ptr := DllCall("GlobalLock", "ptr", handle, "ptr")
                    if ptr {
                        try text := StrGet(ptr, Max(0, size // 2), "UTF-16")
                        finally DllCall("GlobalUnlock", "ptr", handle)
                    }
                }
            }
            return {Kind: this.Describe(formats, text), Text: text, Sequence: seq}
        } finally DllCall("CloseClipboard")
    }
}
