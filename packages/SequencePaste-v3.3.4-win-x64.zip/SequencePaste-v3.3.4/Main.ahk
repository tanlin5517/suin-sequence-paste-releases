﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#NoTrayIcon
Persistent

; 强制启用 Per-Monitor DPI Aware V2，防止多显示器下的点击偏移
DllCall("SetThreadDpiAwarenessContext", "ptr", -4, "ptr")

; 基础运行环境配置
SetWorkingDir(A_ScriptDir)
SendMode("Event")
SetKeyDelay(30, 30) ; 针对 Parsec 环境增加底层按键延迟

; 加载子模块
#Include "Modules\SequencePaste.ahk"
;#Include "Modules\TaskbarWindowSnap.ahk"
#Include "Modules\FBACargoCleaner.ahk"
#Include *i LocalExtensions.ahk
; #Include "Modules\RescueMouseCursor.ahk"


ToolTip("🚀 Suin 自动化引擎已就绪（双机顺序粘贴：Ctrl+Alt+I）")
SetTimer(() => ToolTip(), -2000)
